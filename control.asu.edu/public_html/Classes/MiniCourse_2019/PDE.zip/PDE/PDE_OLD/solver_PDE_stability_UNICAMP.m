clear all; close all; echo off; 
total=tic;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% DelayTools/Linear v.04 - solver_delay_nd
%
% This program determines stablity of a linear differential equation with 
% delay, where \dot{x}(t)=A0x(t)+A{1}x(t-tau(1))+...+A{K}x(t-tau(K))  
% where A0, A{i}, and tau(i) are user inputs. 
%
% Inputs: A{i} - these can be arbitrary square matrices of arbitrary 
%         dimension. However,  the higher the higher the dimension of A{i},
%         the more time the program will take to run
%         
%         tau(i) - These can be an arbitrary sequence of positive increasing 
%         numbers.
%
%         orderth - This input controls the accuracy of the results. For
%         most problems, orderth=2 should be sufficient to obtain a
%         reasonable degree of accuracy. Note: orderth should be an even
%         integer.
% 
% Requirements: In order to operate, this program requires a working
%               version of SOStools. There are some known compatability 
%               issues with SOStools and Matlab version 7+ due to errors in 
%               the implementation of Maple v8. In addition, it
%               is highly recommended that the user have a compiled version
%               of cdd. Finally the following package of subprograms are
%               required which allows SOStools to handle matrix objects
%               directly:
%               SOStools Matrix Addon package:
%                   sosposmatr.m
%                   sosposmatr.m
%                   sosmatrvar.m
%                   sossymmatrvar.m
%                   sosposmatrvar.m
%  
% version .03   M. Peet, Stanford. mmpeet@stanford.edu
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DelayTools/Linear v.03 - solver_delay_nd
% Release Notes:
% v.03 - Compatibility with MatrixTOOLS v.03
%
% Coming soon - The big change with release v.04 will be the use of semiseparable
% kernel functions. These functions have properties in common with the
% Gaussian and seem to give an order of magnitude increase in Accuracy in
% most problems, expecially ones which were problematic using separable
% kernels. As yet, we have no joint positivity condition for semiseparable
% kernels. Thus the choice was between either joint positivity or
% semiseparable kernels. Since joint positivity demonstrated little or no
% improvement in performance, the choice was relatively simple.
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% System Definition:
% \dot x(t,s)=A0(s)[x_1(t,s)] + A1(s)[x_2s(t,s)] + A2(s)[x_3ss(t,s)]
%                  [x_2(t,s)]        [x_3s(t,s)]
%                  [x_3(t,s)]
% % Boundary conditions are of the form 
% % B[x_2(a)       
% %   x_2(b)
% %   x_3(a)
% %   x_3(b)
% %   x_3s(a)
% %   x_3s(b)]=0

%
% Inputs:
% A0(s)  -  matrix function of s of dimension n1+n2+n3 x n1+n2+n3 
% A1(s)  -  matrix function of s of dimension n1+n2+n3 x n2+n3
% A2(s)  -  matrix function of s of dimension n1+n2+n3 x n3
% B      -  matrix of dimension n2+2*n3 x n1+n2+n3 (must be full row rank)
% a,b    -  \R x \R - interval of the domain - s \in [a,b]
% epsneg (optional) - epsneg >0 for strictness of the negativity of derivative 
%
% here 
% n1 - dimension of x_1 (can be 0)
% n2 - dimension of x_2 (can be 0)
% n3 - dimension of x_3 (can be 0)
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% internal variables:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
pvar s th eta zeta
epspos=.01;           % strictness of lyapunov positivity
epsneg=.0000;           % strictness of derivative negativity
orders = 2;
ordernu=4;

% % % % Gouisbault - coupled Wave
% % % % x(0)
% epsneg=.0000;           % strictness of derivative negativity
% % ne=1; lam=2.46
% c1=1;c2=1;
% A0=zeros(4,4);
% A1=[0 c1^2 0 0;1 0 0 0;0 0 0 1;0 0 c2^2 0];
% A2=zeros(4,0);
% a=0;b=1;g=-1;h=3;
% % x(a)=0, x(L)=0   - Stable for lam<1.2732
% B=[-g 1 0 0 0 0 0 0;
%     0 0 -1 0 1 0 0 0;
%     0 0 0 -1 0 1 0 0;
%     0 0 0 0 0 0 h 1];
% % % x(a)=0, x_s(a)=0   - Not Stable!
% % B=[eye(ne) zeros(ne) zeros(ne) zeros(ne);
% %     zeros(ne) zeros(ne) eye(ne) zeros(ne)];

%--------------------------------------------------------------------
% % Test 1 - Diffusion Equation on [-1,1]
% % x(0)
% ne=1; lam=2.46
% A0=lam*eye(ne);
% A1=0*eye(ne);
% A2=1*eye(ne);
% a=-1;b=1;
% % x(a)=0, x(L)=0   - Stable for lam<1.2732
% B=[eye(ne) zeros(ne) zeros(ne) zeros(ne);
%     zeros(ne) eye(ne) zeros(ne) zeros(ne)];
% % % x(a)=0, x_s(a)=0   - Not Stable!
% % B=[eye(ne) zeros(ne) zeros(ne) zeros(ne);
% %     zeros(ne) zeros(ne) eye(ne) zeros(ne)];
% 

% %--------------------------------------------------------------------
% % Test 1.5 - Diffusion Equation on [0,1] adapted from Ahmadi 2015
% % x(0)
% ne=1; lam=9.8696   %[9.8696 9.8697]
% A0=lam*eye(ne);
% A1=0*eye(ne);
% A2=1*eye(ne);
% a=0;b=1;
% %x(a)=0, x(L)=0   - Stable for lam<pi^2=9.8696
% B=[eye(ne) zeros(ne) zeros(ne) zeros(ne);
%     zeros(ne) eye(ne) zeros(ne) zeros(ne)];
% % % x(a)=0, x_s(a)=0   - Not Stable!
% % B=[eye(ne) zeros(ne) zeros(ne) zeros(ne);
% %     zeros(ne) zeros(ne) eye(ne) zeros(ne)];

% %--------------------------------------------------------------------
% % % Test 2 - Diffusion Equation Problem 1 from Gahlawat_2017
% % % x(0)
% ne=1; lam=2.467
% A0=lam*eye(ne);
% A1=0*eye(ne);
% A2=1*eye(ne);
% a=0;b=1;
% % x(a)=0, x_s(L)=0   - Unstable for \lam>2.467 
% B=[eye(ne) zeros(ne) zeros(ne) zeros(ne);
%     zeros(ne)  zeros(ne) zeros(ne) eye(ne)];
% % % x(a)=0, x_s(a)=0   - Not Stable!
% % B=[eye(ne) zeros(ne) zeros(ne) zeros(ne);
% %     zeros(ne) zeros(ne) eye(ne) zeros(ne)];
% % 

% % --------------------------------------------------------------------
% % Test 3 - Diffusion Equation Problem 2 from Gahlawat_2017
% % x(0)
% ne=1; lam=4.66
% A2=s^3-s^2+2;
% A1=3*s^2-2*s;
% A0=-.5*s^3+1.3*s^2-1.5*s+.7+lam;
% a=0;b=1;
% % x(a)=0, x_s(L)=0   - Unstable for \lam>4.66 
% B=[eye(ne) zeros(ne) zeros(ne) zeros(ne);
%     zeros(ne)  zeros(ne) zeros(ne) eye(ne)];
% % % x(a)=0, x_s(a)=0   - Not Stable!
% % B=[eye(ne) zeros(ne) zeros(ne) zeros(ne);
% %     zeros(ne) zeros(ne) eye(ne) zeros(ne)];

% %--------------------------------------------------------------------
% % % Test 4 - Diffusion Equation
% % % x(0)
% ne=2; 
% A0=[0 .1; 0 -2];
% A1=0*eye(ne);
% A2=[1 0;0 0];
% a=0;b=1;
% % x(a)=0, x(L)=0   - Stable
% B=[eye(ne) zeros(ne) zeros(ne) zeros(ne);
%     zeros(ne) eye(ne) zeros(ne) zeros(ne)];
% % % x(a)=0, x_s(a)=0   - Not Stable!
% % B=[eye(ne) zeros(ne) zeros(ne) zeros(ne);
% %     zeros(ne) zeros(ne) eye(ne) zeros(ne)];

%--------------------------------------------------------------------
% % % Test 5 - from Valmorbida
% ne=3; R=21 
% a=0;b=1;
% A0=[0 0 0;
%     s 0 0
%     s^2 -s^3 0];
% A1=0*eye(ne);
% A2=inv(R)*eye(ne);
% % x(a)=0, x_s(L)=0   - Stable for R<21 
% B=[eye(ne) zeros(ne) zeros(ne) zeros(ne);
%     zeros(ne) eye(ne) zeros(ne) zeros(ne) ];
%--------------------------------------------------------------------

% % % Test 5.5 - from Ahmadi
% ne=2; R=2.93 % [2.93 2.94]
% a=0;b=1;
% A0=[1 1.5;
%     5 .2 ];
% A1=0*eye(ne);
% A2=inv(R)*eye(ne);
% % x(a)=0, x_s(L)=0   - Stable for R<2.7
% B=[eye(ne) zeros(ne) zeros(ne) zeros(ne);
%     zeros(ne) eye(ne) zeros(ne) zeros(ne) ];

%--------------------------------------------------------------------

% % % Test 6 - Transport with Amplification at boundary
% ne=1; K=.5
% a=0;b=1;
% A0=0;
% A1=eye(ne);
% A2=0;
% % x(a)=K*x(L) x_s(a)=Kx_s(L)  - Stable for K<1? 
% B=[eye(ne) -K*eye(ne) zeros(ne) zeros(ne);
%     zeros(ne) zeros(ne) eye(ne) -K*eye(ne) ];
% 
%--------------------------------------------------------------------
% % Test 7 - Wave equation
% ne=2;a=2;mu=.01;
% a=0;b=1;
% A0=[0 1; 0 -mu];
% %A0=[0 1; 0 -4];
% A1=0*eye(ne);
% A2=[0 0; a 0];
% % x(0)=0 x(a)=K*x(L) x_s(a)=Kx_s(L)  - Stable for K<1? 
% B=[eye(ne) zeros(ne) zeros(ne) zeros(ne);
% %    zeros(ne) eye(ne) zeros(ne)  zeros(ne) ];
%     zeros(ne) zeros(ne) eye(ne)  zeros(ne) ];
% %    zeros(ne) [0 1;0 1] zeros(ne)  mu*[1 0;0 1] ];
% 
% % %--------------------------------------------------------------------
% % % % Test 7.5 - Boundary-Damped Wave equation 
% % % ne=2;a=2;mu=.01; u_t(L)=-k u_s(L)
%  a=0;b=1; k=1;
%  A0=[0 0; 1 0];
%  A1=[0 0; 0 0];
%  A2=[1; 0];
% % % x(0)=0 x(a)=K*x(L) x_s(a)=Kx_s(L)  - Stable for K<1? 
%  B=[0 0 1 0 0 0;
%      1 0 0 0 0 0;
%      0 1 0 0 0 k];
% %--------------------------------------------------------------------
% % % % % Test 7.5b - Boundary-Damped Wave equation (Hyperbolic)
% % % % ne=2;a=2;mu=.01; u_t(L)=-k u_s(L)
% epsneg=.01;           % strictness of derivative negativity
%  a=0;b=1; k=1;
%  A0=[0 0; 0 0];
%  A1=[0 1; 1 0];
%  A2=zeros(2,0);
% % % x(0)=0 x(a)=K*x(L) x_s(a)=Kx_s(L)  - Stable for K<1? 
%  B=[0 1 0 0;
%     0 0 k 1];

% % %--------------------------------------------------------------------
% % % % % Test 7.5c - Datko Boundary-Damped Wave equation 
% % % % ne=2;a=2;mu=.01; u_x(L)=-k u_t(L)
% % epsneg=.01;           % strictness of derivative negativity
%  a=0;b=1; k=1;ad=1;
%  A0=[-2*ad -ad^2; 1 0];
%  A1=[0 0; 0 0];
%  A2=[1; 0];
% % % x(0)=0 x(a)=K*x(L) x_s(a)=Kx_s(L)  - Stable for K<1? 
%  B=[0 0 1 0 0 0;
%      1 0 0 0 0 0;
%      0 k 0 0 0 1];
% %  
% % 
% % %--------------------------------------------------------------------
% % % % % Test 7.5d - Datko Boundary-Damped Wave equation (Hyperbolic)
% % % % ne=2;a=2;mu=.01; u_x(L)=-k u_t(L)
%  a=0;b=1; k=1;ad=1;
%  A0=[-2*ad -ad^2 0; 1 0 0;0 0 0];
%  A1=[0 0 1; 0 0 0;1 0 0];
%  A2=zeros(3,0);
% % % x(0)=0 x(a)=K*x(L) x_s(a)=Kx_s(L)  - Stable for K<1? 
%  B=[1 0 0 0 0 0;
%      0 1 0 0 0 0;
%      0 0 0 k 0 1];
% %  
% %--------------------------------------------------------------------
% % % Test 7 - E-B beam equation
ne=2;c=.01;%c=EI/mu
a=0;b=1;
A0=[0 0; 0 0];
A1=[0 0; 0 0];
A2=[0 -c; 1 0];
% x1(0)=0 x2(L)=0 x_1s(0)=0 x_2s(L)=0 
B=[
    1 0 0 0 0 0 0 0;
    0 0 0 1 0 0 0 0;
    0 0 0 0 1 0 0 0;
    0 0 0 0 0 0 0 1];

% % % %--------------------------------------------------------------------
% % % % % Test 9 - Timoschenko beam equation (hyperbolic) 
% % % % The states are u1=wt, u2=wx-phi, u3=phit, u4=phix
% % % % The BCs are u1(0)=0, u3(0)=0 u4(L)=0 u2(L)=0 ;
% k=1;
% aa=1;II=1;
% g=1;
% E=10;%5-30kPa
% r=1;
% ne=2;c=.01;%c=EI/mu
% a=0;b=1;
% A0=[0 0 0 0; 
%     0 0 -k*aa*g 0;
%     0 1/r/II 0 0;
%     0 0 0 0];
% A1=[0 1/r/aa 0 0; 
%     k*aa*g 0 0 0;
%     0 0 0 1/r/II;
%     0 0 E*II 0];
% A2=zeros(4,0);
% % x1(0)=0 x2(L)=0 x_1s(0)=0 x_2s(L)=0 
% B=[
%     1 0 0 0 0 0 0 0;
%     0 0 1 0 0 0 0 0;
%     0 0 0 0 0 0 0 1;
%     0 0 0 0 0 1 0 0];

% 
% % % Timoschenko Beam equation Example (hyperbolic/diffusive) - unstable
% % % The states are u1=wt, u2=wx, u3=phit,u4=phi
% % % The BCs are u4(0)=0, u4x(L)=0, u3(0)=0, u1(0)=0, u2(L)-u4(L)=0;
% % k=1;
% % aa=1;
% % g=1;
% % E=10;%5-30kPa
% % II=1;
% A0=[0 0 0 0;
%     0 0 0 0;
%     0 1 0 -1;
%     0 0 1 0];
% A1=[0 1 0 -1;
%     1 0 0 0;
%     0 0 0 0;
%     0 0 0 0];
% A2=[0;0;1;0];
% a=0; b=1;
% % B has dimension 5 x 10
% %  x1 x2 x3 x4 
% B=[0 0 0 0 0 0 1 0 0 0;
%    0 0 0 0 0 0 0 0 0 1;
%    0 0 1 0 0 0 0 0 0 0;
%    1 0 0 0 0 0 0 0 0 0;
%    0 0 0 0 1 0 0 -1 0 0];
% 
% 
% % % Timoschenko Beam equation Example (hyperbolic/diffusive with damping)
% - stable but not exponentially
% % % The states are u1=wt, u2=wx, u3=phit,u4=phi
% % % The BCs are u4(0)=0, u4x(L)=0, u3(0)=0, u1(0)=0, u2(L)-u4(L)=0;
% % k=1;
% % aa=1;
% % g=1;
% % E=10;%5-30kPa
% % II=1;
% A0=[0 0 0 0;
%     0 0 0 0;
%     0 1 -.1 -1;
%     0 0 1 0];
% A1=[0 1 0 -1;
%     1 0 0 0;
%     0 0 0 0;
%     0 0 0 0];
% A2=[0;0;1;0];
% a=0; b=1;
% % B has dimension 5 x 10
% %  x1 x2 x3 x4 
% B=[0 0 0 0 0 0 1 0 0 0;
%    0 0 0 0 0 0 0 0 0 1;
%    0 0 1 0 0 0 0 0 0 0;
%    1 0 0 0 0 0 0 0 0 0;
%    0 0 0 0 1 0 0 -1 0 0];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% End User Input
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

n_dim=size(A0,1);
n_dim3=size(A2,2);
n_dim2=size(A1,2)-n_dim3;
n_dim1=size(A0,2)-n_dim3-n_dim2;
bexp2=4*n_dim3+2*n_dim2;
if bexp2~=size(B,2)
    disp('B Matrix has incorrect number of columns')
end
bexp1=2*n_dim3+n_dim2;
if bexp1~=rank(B)
    disp('B Matrix has insufficent rank - add more boundary conditions')
end

zz11=zeros(n_dim1);
zz12=zeros(n_dim1,n_dim2);
zz13=zeros(n_dim1,n_dim3);
zz22=zeros(n_dim2);
zz23=zeros(n_dim2,n_dim3);
zz33=zeros(n_dim3);
zz21=zz12.';
zz31=zz13.';
zz32=zz23.';

HH0=blkdiag(eye(n_dim1),zz22,zz33);
HH1=blkdiag(zz11,eye(n_dim2),(s-th)*eye(n_dim3));
K0=[zz12            zz13            zz13 ;
    eye(n_dim2)     zz23            zz23 ;
    zz32            eye(n_dim3)     (s-a)*eye(n_dim3)];
J0=[eye(n_dim2)     zz23            zz23;
    eye(n_dim2)     zz23            zz23;
    zz32            eye(n_dim3)     zz33;
    zz32            eye(n_dim3)     (b-a)*eye(n_dim3);
    zz32            zz33            eye(n_dim3);
    zz32            zz33            eye(n_dim3)];
NN1=[zz21           zz22            zz23;
    zz21            eye(n_dim2)     zz23;
    zz31            zz32            zz33;
    zz31            zz32            (b-th)*eye(n_dim3);
    zz31            zz32            zz33;
    zz31            zz32            eye(n_dim3)];

% This is the map from fundamental state to first-order state
G0=HH0;
Gc=inv(B*J0)*B*NN1;
G2=-K0*Gc;
G1=G2+HH1;

MM0=[zz21 eye(n_dim2) zz23;
     zz31 zz32        zz33];
MM1=[zz21   zz22      zz23;
    zz31    zz32      eye(n_dim3)];
LL0=[zz22  zz23  zz23;
    zz32  zz33  eye(n_dim3)];

% This is the map from fundamental state to hyperbolic state
G3=MM0;
G5=-LL0*Gc;
G4=MM1+G5;

% This is the dynamics expressed in terms of the fundamental state

H0=A0*G0+A1*G3+[zeros(n_dim,n_dim1) zeros(n_dim,n_dim2) A2];
H1=A0*G1+A1*G4;
H2=A0*G2+A1*G5;





% Enter degree of accuracy - must be an even integer
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% internal variables:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% control inputs to SeDuMi 
pars.alg=1;
pars.stepdif=1;
pars.eps=10^(-15);
pars.maxiter=100;
pars.cg.maxiter=200;
pars.cg.qprec=1;
pars.cg.stagtol=1e-22;
pars.cg.restol=5e-5;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% internal processing:


mastervartable=[s,th];
prog = sosprogram(mastervartable);


II=[a b];            % interval [0,L]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% phase 1 - variables %%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% we will need to declare variables:
% M(s),N1(s,th),N_2(s,th)
%
disp('Overhead and Lyapunov Variables, elapsed time:')


tic
disp('creating joint positive operator variable')
[prog, M, N1, N2] = sospos_PL2L_vsym(prog,n_dim,orders/2,ordernu/2,s,th,II);

%[G0s, G1s, G2s] = semisep_MN1N2_transpose(G0,G1,G2,s,th);
%[Meps, N1eps, N2eps] = semisep_MN1N2_compose(G0s,G1s,G2s,G0,G1,G2,s,th,II);
% 
% M=M+epspos*Meps;
% N1=N1+epspos*N1eps;
% N2=N2+epspos*N2eps;

M=M+eps*eye(n_dim);

%N1=N1;
%N2=N2;

% M=eye(n_dim);

% G0t=[1 0;0 0]*G3+[0 0;0 1]+s*0;
% G1t=[1 0;0 0]*G4;
% G2t=[1 0;0 0]*G5;
% [G0ts, G1ts, G2ts] = semisep_MN1N2_transpose(G0t,G1t,G2t,s,th);
% [M, N1, N2] = semisep_MN1N2_compose(G0ts,G1ts,G2ts,G0t,G1t,G2t,s,th,II);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% phase 2 - derivatives %%%%%%%%%%%%%%%%%%%%
%%%%%%% Step1 %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% the derivative matrices are spelled out in the paper, they are 
disp('constructing Derivatives, elapsed time:')

disp('constructing Derivatives, new method:')

tic
[J0, J1, J2] = PL2L_compose(M,N1,N2,G0,G1,G2,s,th,II);

[H0s, H1s, H2s] = PL2L_transpose(H0,H1,H2,s,th);
[K0, K1, K2] = PL2L_compose(H0s,H1s,H2s,J0,J1,J2,s,th,II);
[K0s, K1s, K2s] = PL2L_transpose(K0,K1,K2,s,th);
toc

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Step2 %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Enforce negativity of D 
disp('enforcing negativity of derivative')



disp('creating joint positive operator variable')

%[prog, Teq,Ueq,Weq,Veq] = sosjointpos_mat_ker_ndelay_parallel_R_L2_PQRS_MTNS(prog,w_dim+2*n_dim,n_dim,orderth/2,ordernu/2,th,ksi,II,1);


[prog, N1eq, N2eq] = sospos_PL2L_pure(prog,n_dim,(orders+4)/2,(ordernu+4)/2,s,th,II);
[prog, gN1eq, gN2eq] =  sospos_PL2L_psatz_pure(prog,n_dim,(orders+4)/2,(ordernu+4)/2,s,th,II);

% Option for strict negativity
[G0s, G1s, G2s] = PL2L_transpose(G0,G1,G2,s,th);
[T0eps, T1eps, T2eps] = PL2L_compose(G0s,G1s,G2s,G0,G1,G2,s,th,II);


% Should we make this exact?
disp('running equalities, elapsed time:')
tic


    [prog] = sosmateq(prog,K1+K1s+epsneg*T1eps+N1eq+gN1eq);
%    [prog] = sosmateq(prog,D1+Cst+N1eq+gN1eq);
%    [prog] = sosmateq(prog,D1+Cst+N1eq);
%    [prog] = sosmateq(prog,D2+Cst+N2eq+gN2eq); % this one is not necessary
%    [prog] = sosmateq(prog,D2+Cst+gN2eq); % this one is not necessary
toc
disp('TOTAL POLYNOMIAL TIME:')
toc(total)
disp('Computing Solution')


disp('Computing Solution')
%prog = sossolve(prog);
prog = sossolve_p(prog,pars);
%% Conclusion:
if norm(prog.solinfo.info.feasratio-1)<=.1 && ~prog.solinfo.info.numerr
    disp('The System is Stable.')
elseif norm(prog.solinfo.info.feasratio-1)<=.1 && prog.solinfo.info.numerr
    disp('The System is likely Stable. However, Double-check the precision.')
elseif prog.solinfo.info.pinf || prog.solinfo.info.dinf || norm(prog.solinfo.info.feasratio+1)<=.1
    disp('The System is Probably not Stable.')
else
    disp('Unable to definitively determine feasibility. Numerical errors dominating or at the limit of stability.')
end

