function [P]=LR_mult_n(M,n,L,R)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% LR_mult_n(L,R,M,n)
%
% This function multiplies M on the left by n copies of L and on the right 
% by n copies of R. Sizes must be compatable
% [L   ]^T   [R   ]
% [ L  ]   M [ R  ]
% [  L ]     [  R ]
% [   L]     [   R], Q>0
%
%
% INPUTS: 
%
% M - The matrix in the middle
% n - the number of copies of L and R
% L - The left-side multiplier 
% R - The right-side multiplier - If R is omitted, we take L=R
%
%
%
% NOTES:
% Distributed with DelayTOOLS
% Compatable with MULTIPOLY and SOSTOOLS as of June 2013
% For support, contact M. Peet, Arizona State University at mpeet@asu.edu

% version .03   M. Peet, matthew.peet@inria.fr
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% MatrixTools - sosposmatrvar
% Release Notes:
% v.03 - compatability with sosposmatr
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[nrowL ncolL]=size(L);
[nrowR ncolR]=size(R);
[nrowM ncolM]=size(M);

% L and R should be vectors
if ncolL~=1
    error(['L must be a vector of monomials'])
end
if ncolR~=1
    error(['R must be a vector of monomials'])
end

% number of rows of M should be nrowL*n
if nrowL*n~=nrowM
    error(['The dimensions of M and L do not agree'])
end
% number of cols of M should be nrowR*n
if nrowR*n~=ncolM
    error(['The dimensions of M and R do not agree'])
end


%Z=monomials(vars,0:ceil(d/2));

% I need to creat a map from the variable name index to the position in the matrix
% P. So that the i,j th element of the matrix LLL is the variable with
% index ind(i,j). Since I know how P is constructed, this shouldn't be
% too bad. Assuming I NEVER change how sosposmatr_p works...


if ncase==1
    
% In this routine, we manually calculate M=bZ1th.'*P*bZ1th;
% All variables appear 
Pvarname=[M.varname; R.varname];
% In the final polynomial, there will still be e.g. 7260 terms. 

% For the next part, we just need the degmat part of the block-diagonal
% monomial matrix

bZdegmat=repmat(Z.degmat,n,1);

% fortunately, the index of the elements of P correspond to the power of x
% by which they multiply
[Ilist, Jlist]=find(triu(ones(nZ*n)));
% so we just add those monomials to each term
adegmat = [P.degmat bZdegmat(Ilist,:)+bZdegmat(Jlist,:)];

% but now we have to modify the coefficient matrix. We can group this by
% blocks. For a 2x2 matrix, all the coefficients from block 1 will be [1 0 0 0], all the
% coefficients from block 2 will be [0 1 0 0], all the coefficients from
% block 3 will be [0 0 0 1],

[PIlist, PJlist]=find(P.coefficient); % these will all be ones, but PIlist and Pjlist will be relatively short. 
% Positions in Pjlist from 1:nZ get reassigned to 1, nZ+1:2nZ -> 2, etc
row=mod(PJlist-1,nZ*n)+1; % row number
col=ceil(PJlist/(nZ*n)); % column number
newrow=ceil(row/nZ);
newcol=ceil(col/nZ);
newidx=(newcol-1)*n+newrow;
coeff=sparse(PIlist,newidx,1);
amatdim=[n n];
P=polynomial(coeff,adegmat,avarname,amatdim);
end

if ncase==3
    %%%%%%%%%%%%%%%%%%%%%%%%%
% Construct CA
%CA=bZ2omth.'*LLL((nBZ1+1):(nBZ1+nBZ2),(nBZ1+1):(nBZ1+nBZ2))*bZ2omksi;
% first, lets construct Zomth and Zomksi
avarname=[M.varname; var1.varname; var2.varname; dum.varname{1}];

 if strcmp(var1.varname{1},ZZZthksi.varname{1}) % th is in the first position
         bZdegmat1=repmat([ZZZthksi.degmat(:,2) zeros(nZthksi,1)  ZZZthksi.degmat(:,1)],n,1); %bZomth
         bZdegmat2=repmat([zeros(nZthksi,1) ZZZthksi.degmat(:,2)  ZZZthksi.degmat(:,1)],n,1); %bZomksi
 else
     bZdegmat1=repmat([ZZZthksi.degmat(:,1) zeros(nZthksi,1)  ZZZthksi.degmat(:,2)],n,1); %bZomth
         bZdegmat2=repmat([zeros(nZthksi,1) ZZZthksi.degmat(:,1)  ZZZthksi.degmat(:,2)],n,1); %bZomksi
 end

[PIlist, PJlist]=find(M.coefficient); % This is the list of terms in P, but PIlist and Pjlist will be relatively short. 
[Prowu,Pcolu] = ind2sub([n*nZthksi n*nZthksi],PJlist); % this returns the matrix locations for every term in P
adegmat = [LLL4.degmat(PIlist,:) bZdegmat1(Prowu,:)+bZdegmat2(Pcolu,:)];
% but now we have to modify the coefficient matrix. We can group this by
% blocks. For a 2x2 matrix, all the coefficients from block 1 will be [1 0 0 0], all the
% coefficients from block 2 will be [0 1 0 0], all the coefficients from
% block 3 will be [0 0 0 1],

newrow=ceil(Prowu/nZthksi);
newcol=ceil(Pcolu/nZthksi);

% [row,col] = ind2sub([n*nZthksi n*nZthksi],PJlist);
% newrow=ceil(row/nZthksi);
% newcol=ceil(col/nZthksi);
newidx=sub2ind([n n],newrow, newcol);%(newcol-1)*n+newrow;
nPIlist=(1:length(PIlist))';
coeff=sparse(nPIlist,newidx,1);
amatdim=[n n];
P=polynomial(coeff,adegmat,avarname,amatdim);
end









