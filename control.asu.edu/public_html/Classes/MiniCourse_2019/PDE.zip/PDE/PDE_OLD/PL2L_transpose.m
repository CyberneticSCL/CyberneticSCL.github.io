function [MT, N1T, N2T] = semisep_MN1N2_transpose(M,N1,N2,var1,var2)

%
% SEMISEP_MN1N2_TRANSPOSE(Ma,N1a,N2a,Mb,N1b,N2b) takes a operator of the
% form P_{M,N_1,N_1} and computes the matrices MT,N1T,N2T such that 
% P_{MT,N1T,N2T}=P_{M,N1,N2}^* 
%
% The formulae for {MT,N1T,N2T} are given as 
% MT(s) = M(s)'
% N1T(s,\theta)=N2(\theta,s)'
% N2T(s,\theta)=N1(\theta,s)'
% 
% INPUTS 
%   M: diagonal multiplier
%   N1: subdiagonal kernel
%   N2: superdiagonal kernel
%   var1: Single pvar corresponding to s in the description
%   var2: Single pvar corresponding to t in the description
%
% OUTPUT 
%   MT: diagonal multiplier
%   N1T: subdiagonal kernel
%   N2T: superdiagonal kernel
%
% NOTES:
% Distributed with DelayTOOLS
% Compatable with MULTIPOLY and SOSTOOLS as of June 2013
% For support, contact M. Peet, Arizona State University at mpeet@asu.edu

MT=M.';
N1T=var_swap(N2,var1,var2).';
N2T=var_swap(N1,var1,var2).';

% end code

