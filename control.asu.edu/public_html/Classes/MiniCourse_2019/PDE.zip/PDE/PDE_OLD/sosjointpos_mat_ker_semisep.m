function [prog, M, N1, N2] = sosjointpos_mat_ker_semisep(prog,n,d1,d2,var1,var2,I)
%
% SOSJOINTPOS_MAT_KER_SEMISEP(prog,n,d1,d2,var1,var2,I) declares the multiplier $M(s)$ and
% kernel part $N(s,t)$ of a positive multiplier+integral operator. The
% multiplier and kernel have the form
%
% M(s) = Z(s)^T Q_{11} Z(s)
% N1(s,t) = Z(s)^T Q_{12} Z(s,t) + Z(t,s)^T Q_{31} Z(t) 
%   + \int_{I(1)}^t Z(ss,s)^T Q_{33} Z(ss,t) dss
%       +\int_t^sZ(ss,s)^T Q_{32} Z(ss,t) dss
%       +\int_s^{I(2)}Z(ss,s)^T Q_{22} Z(ss,t) dss
% N2(s,t) = Z(s)^T Q_{13} Z(s,t) + Z(t,s)^T Q_{21} Z(t)
%   + \int_{I(1)}^sZ(ss,s)^T Q_{33} Z(ss,t) dss
%       +\int_s^tZ(ss,s)^T Q_{23} Z(ss,t) dss
%       +\int_t^{I(2)}Z(ss,s)^T Q_{22} Z(ss,t) dss
% Q = [ Q_{11}  Q_{12} Q_{13}]
%     [ Q_{21}  Q_{22} Q_{23}] >0
%     [ Q_{31}  Q_{32} Q_{33}]
%
% 
% where Z(x)= Z_d1(x) \otimes I_n and Z_d(x) is the vector of monomials in
% variables x of degree d1 or less. Z(x,y) = Z_{d1}(x) \otimes Z_{d2}(y)
% \otimes I_n. If the application is stability of time-delay systems, d1
% will eventually be more or less the degree of the multiplier and d2 more
% or less the degree of the kernel function.
% we recommend setting d2 = d1 to keep the polynomial degrees balanced.
%
% N(s,t) = { N1(s,t)        s>t
%          { N2(s,t)        t>s
%
% INPUTS 
%   prog: SOS program to modify.
%   n: dimension of the resulting matrix
%   d1: degree of the multiplier (sort of)
%   d2: degree of the kernel
%   var1: Single pvar corresponding to s in the description
%   var2: Single pvar corresponding to t in the description
%   I = [l u] interval of integration
%
% OUTPUT 
%   N1: subdiagonal function
%   N2: superdiagonal superdiagonal
%
% NOTES:
% Distributed with DelayTOOLS
% Compatable with MULTIPOLY and SOSTOOLS as of June 2013
% For support, contact M. Peet, Arizona State University at mpeet@asu.edu

if ~isvalid(var1) || ~isvalid(var2)
  error(['vars must be a polynomial variable']);
end
dum=polynomial(1,1,{'ss'},[1 1]);

% I'm going to construct Z manually so I know where everything is
nZth=d1+1;
Z1degmat = [0:d1]';
Z1coeff = speye(nZth);
Z1varname = var1.varname;
Z1matdim = [nZth 1];
ZZZth=polynomial(Z1coeff,Z1degmat,Z1varname,Z1matdim);


% There are two configurations for the degree d2. Probably the most logical one is 
% that for TDS applications, 2d1 ends up as the degree of the multiplier and
% 2d2 as the degree of the kernel. This is the following:

Z2degmat = [repmat([0:d1]',d2+1,1),vec(repmat(0:d2,d1+1,1))];
nZthksi=length(Z2degmat);
Z2coeff = speye(nZthksi);
Z2varname = [var1.varname; var2.varname];
Z2matdim = [nZthksi 1];
ZZZthksi=polynomial(Z2coeff,Z2degmat,Z2varname,Z2matdim);

% For other applications, however, we may want 2d2 to represent the
% internal variable of integration, in which case we use the following:
% 
% Z2degmat = [repmat([0:d2]',d1+1,1),vec(repmat(0:d1,d2+1,1))];
% nZthksi=length(Z2degmat);
% Z2coeff = speye(nZthksi);
% Z2varname = [var1.varname; var2.varname];
% Z2matdim = [nZthksi 1];
% ZZZthksi=polynomial(Z2coeff,Z2degmat,Z2varname,Z2matdim);


nBZ1=n*nZth;
nBZ2=n*nZthksi;
[prog,LLL]=sosposmatr(prog,nBZ1+2*nBZ2);


% Lets start by just assuming LLL has been partitioned
% In this case, things are more or less a repeat of the positive matrix
% variable case in sosposmatrvar.m with P replaced by LLL1 and Z with ZZZth
% Note, however that because this rearranges the order of the elements of
% ZZZth, we must alter all the manipulations or the result will be invalid.
ind1=1:nBZ1; ind2=(nBZ1+1):(nBZ1+nBZ2); ind3=(nBZ1+nBZ2+1):(nBZ1+2*nBZ2);
Q11=LLL(ind1,ind1);
Q12=LLL(ind1,ind2);
Q13=LLL(ind1,ind3);
Q22=LLL(ind2,ind2);
Q23=LLL(ind2,ind3);
Q33=LLL(ind3,ind3);
Q21=Q12.';Q31=Q13.';Q32=Q23.';
%%%%%%%%%%%%%%%%%%%%%%%%%
% Construct M

avarname=[Q11.varname; ZZZth.varname];
% For the next part, we just need the degmat part of the block-diagonal
% monomial matrix

bZdegmat=repmat(ZZZth.degmat,n,1);

[PIlist, PJlist]=find(Q11.coefficient); % This is the list of terms in P, but PIlist and Pjlist will be relatively short. 
[PIlist2,ttt]=unique(PIlist);
PJlist2=PJlist(ttt,:);

[Prowu,Pcolu] = ind2sub([n*nZth n*nZth],PJlist2); % this returns the matrix locations for every term in P
adegmat = [Q11.degmat(PIlist2,:) bZdegmat(Prowu,:)+bZdegmat(Pcolu,:)];

% but now we have to modify the coefficient matrix. We can group this by
% blocks. For a 2x2 matrix, all the coefficients from block 1 will be [1 0 0 0], all the
% coefficients from block 2 will be [0 1 0 0], all the coefficients from
% block 3 will be [0 0 0 1],

% Positions in Pjlist from 1:nZ get reassigned to 1, nZ+1:2nZ -> 2, etc
[row,col] = ind2sub([n*nZth n*nZth],PJlist);
newrow=ceil(row/nZth);
newcol=ceil(col/nZth);
newidx=sub2ind([n n],newrow, newcol);

coeff=sparse(PIlist,newidx,1);
amatdim=[n n];
M=polynomial(coeff,adegmat,avarname,amatdim);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% start with N1 - N2 will be similar
%%%%%%%%%%%%%%%%%%%%%%%%%
% Construct Part A1
% A is slightly different because the monomials of the left and the right
% are different, with different sizes. Thus the positions of the
% coefficients will also be different
% A1=bZ1th.'*Q12*bZ2thksi;

avarname=[Q12.varname; ZZZthksi.varname ];
% For the next part, we just need the degmat part of the block-diagonal
% monomial matrix
if strcmp(var1.varname{1},ZZZthksi.varname{1}); % var1 is in the first position
        bZdegmat1=repmat([ZZZth.degmat zeros(nZth,1)],n,1);
else
        bZdegmat1=repmat([zeros(nZth,1) ZZZth.degmat],n,1);
end
    bZdegmat2=repmat(ZZZthksi.degmat,n,1);

[PIlist, PJlist]=find(Q12.coefficient); % This is the list of terms in P, but PIlist and Pjlist will be relatively short. 
[Prowu,Pcolu] = ind2sub([n*nZth n*nZthksi],PJlist); % this returns the matrix locations for every term in P
adegmat = [Q12.degmat(PIlist,:) bZdegmat1(Prowu,:)+bZdegmat2(Pcolu,:)];
  
% 
% but now we have to modify the coefficient matrix. We can group this by
% blocks. For a 2x2 matrix, all the coefficients from block 1 will be [1 0 0 0], all the
% coefficients from block 2 will be [0 1 0 0], all the coefficients from
% block 3 will be [0 0 0 1],

% Positions in Pjlist from 1:nZ get reassigned to 1, nZ+1:2nZ -> 2, etc
[row,col] = ind2sub([n*nZth n*nZthksi],PJlist);
newrow=ceil(row/nZth);
newcol=ceil(col/nZthksi);
newidx=sub2ind([n n],newrow, newcol);%(newcol-1)*n+newrow;

nPIlist=(1:length(PIlist))';
coeff=sparse(nPIlist,newidx,1);
amatdim=[n n];
A1=polynomial(coeff,adegmat,avarname,amatdim);

clear adegmat avarname amatdim bZdegmat1 bZdegmat2 coeff nPIlist newidx newcol newrow row col Prowu Pcolu PIlist PJlist


%%%%%%%%%%%%%%%%%%%%%%%%%
% Construct Part B1
% We use the fact that
% B1=bZ2ksith.'*Q31*bZ1ksi

disp('B1')
% For the next part, we just need the degmat part of the block-diagonal
% monomial matrix
% bZdegmat1 is on the left, bZdegmat2 is on the right
%ZZZthksi.varname

tvarname=[Q31.varname; ZZZthksi.varname{2}; ZZZthksi.varname{1}];
bZdegmat1=repmat(ZZZthksi.degmat,n,1);
bZdegmat2=repmat([ZZZth.degmat zeros(nZth,1)],n,1);

nZ1=nZthksi;nbZ1=n*nZ1;
nZ2=nZth;nbZ2=n*nZ2;


% This part doesn't change except for the Qij term    
[PIlist, PJlist]=find(Q31.coefficient);  
[Prowu,Pcolu] = ind2sub([nbZ1 nbZ2],PJlist); 
tdegmat = [Q31.degmat(PIlist,:) bZdegmat1(Prowu,:)+bZdegmat2(Pcolu,:)];
[row,col] = ind2sub([nbZ1 nbZ2],PJlist);
newrow=ceil(row/nZ1);
newcol=ceil(col/nZ2);
newidx=sub2ind([n n],newrow, newcol);
nPIlist=(1:length(PIlist))';
coeff=sparse(nPIlist,newidx,1);
tmatdim=[n n];
%tdegmat = [tdegmat1(:,1:(size(tdegmat,2)-2)) tdegmat1(:,size(tdegmat,2)) tdegmat1(:,size(tdegmat,2)-1)];
B1=polynomial(coeff,tdegmat,tvarname,tmatdim);
clear tdegmat tvarname tmatdim bZdegmat1 bZdegmat2 coeff nPIlist newidx newcol newrow row col Prowu Pcolu PIlist PJlist

%%%%%%%%%%%%%%%%%%%%%%%%%
% Construct CA1
%CA1=bZ2omth.'*Q33*bZ2omksi;
%   Z(ss,s)^T Q_{33} Z(ss,t)
disp('CA1')

% first, lets construct Zomth and Zomksi
tvarname=[Q33.varname; var1.varname{1}; var2.varname{1}; dum.varname{1}];

 %if strcmp(var1.varname{1},ZZZthksi.varname{1}) % th is in the first position
         bZdegmat1=repmat([ZZZthksi.degmat(:,2) zeros(nZthksi,1)  ZZZthksi.degmat(:,1)],n,1); %bZomth
         bZdegmat2=repmat([zeros(nZthksi,1) ZZZthksi.degmat(:,2)  ZZZthksi.degmat(:,1)],n,1); %bZomksi
 %else
 %    bZdegmat1=repmat([ZZZthksi.degmat(:,1) zeros(nZthksi,1)  ZZZthksi.degmat(:,2)],n,1); %bZomth
 %    bZdegmat2=repmat([zeros(nZthksi,1) ZZZthksi.degmat(:,1)  ZZZthksi.degmat(:,2)],n,1); %bZomksi
 %end
 nZ1=nZthksi;nbZ1=n*nZ1;
 nZ2=nZthksi;nbZ2=n*nZ2;

[PIlist, PJlist]=find(Q33.coefficient); % This is the list of terms in P, but PIlist and Pjlist will be relatively short. 
[Prowu,Pcolu] = ind2sub([nbZ1 nbZ2],PJlist); % this returns the matrix locations for every term in P
tdegmat = [Q33.degmat(PIlist,:) bZdegmat1(Prowu,:)+bZdegmat2(Pcolu,:)];


newrow=ceil(Prowu/nZ1);
newcol=ceil(Pcolu/nZ2);

newidx=sub2ind([n n],newrow, newcol);%(newcol-1)*n+newrow;
nPIlist=(1:length(PIlist))';
coeff=sparse(nPIlist,newidx,1);
tmatdim=[n n];
CA1=polynomial(coeff,tdegmat,tvarname,tmatdim);

clear tdegmat tmatdim coeff nPIlist newidx newcol newrow row col Prowu Pcolu PIlist PJlist

%%%%%%%%%%%%%%%%%%%%%%%%%
% Construct CA2
%CA=bZ2omth.'*Q32*bZ2omksi;
%   Z(ss,s)^T Q_{33} Z(ss,t)
disp('CA2')

% first, lets construct Zomth and Zomksi
tvarname=[Q32.varname; var1.varname{1}; var2.varname{1}; dum.varname{1}];
 nZ1=nZthksi;nbZ1=n*nZ1;
 nZ2=nZthksi;nbZ2=n*nZ2;


 %if strcmp(var1.varname{1},ZZZthksi.varname{1}) % th is in the first position
 %        bZdegmat1=repmat([ZZZthksi.degmat(:,2) zeros(nZthksi,1)  ZZZthksi.degmat(:,1)],n,1); %bZomth
 %        bZdegmat2=repmat([zeros(nZthksi,1) ZZZthksi.degmat(:,2)  ZZZthksi.degmat(:,1)],n,1); %bZomksi
 %else
 %    bZdegmat1=repmat([ZZZthksi.degmat(:,1) zeros(nZthksi,1)  ZZZthksi.degmat(:,2)],n,1); %bZomth
 %    bZdegmat2=repmat([zeros(nZthksi,1) ZZZthksi.degmat(:,1)  ZZZthksi.degmat(:,2)],n,1); %bZomksi
 %end

[PIlist, PJlist]=find(Q32.coefficient); % This is the list of terms in P, but PIlist and Pjlist will be relatively short. 
[Prowu,Pcolu] = ind2sub([nbZ1 nbZ2],PJlist); % this returns the matrix locations for every term in P
tdegmat = [Q32.degmat(PIlist,:) bZdegmat1(Prowu,:)+bZdegmat2(Pcolu,:)];


newrow=ceil(Prowu/nZ1);
newcol=ceil(Pcolu/nZ2);

newidx=sub2ind([n n],newrow, newcol);%(newcol-1)*n+newrow;
nPIlist=(1:length(PIlist))';
coeff=sparse(nPIlist,newidx,1);
tmatdim=[n n];
CA2=polynomial(coeff,tdegmat,tvarname,tmatdim);

clear tdegmat tmatdim coeff nPIlist newidx newcol newrow row col Prowu Pcolu PIlist PJlist

%%%%%%%%%%%%%%%%%%%%%%%%%
% Construct CA3
%CA=bZ2omth.'*Q22*bZ2omksi;
%   Z(ss,s)^T Q_{22} Z(ss,t)

disp('CA3')

nZ1=nZthksi;nbZ1=n*nZ1;
 nZ2=nZthksi;nbZ2=n*nZ2;


tvarname=[Q22.varname; var1.varname{1}; var2.varname{1}; dum.varname{1}];

 %if strcmp(var1.varname{1},ZZZthksi.varname{1}) % th is in the first position
 %        bZdegmat1=repmat([ZZZthksi.degmat(:,2) zeros(nZthksi,1)  ZZZthksi.degmat(:,1)],n,1); %bZomth
 %        bZdegmat2=repmat([zeros(nZthksi,1) ZZZthksi.degmat(:,2)  ZZZthksi.degmat(:,1)],n,1); %bZomksi
 %else
 %    bZdegmat1=repmat([ZZZthksi.degmat(:,1) zeros(nZthksi,1)  ZZZthksi.degmat(:,2)],n,1); %bZomth
 %    bZdegmat2=repmat([zeros(nZthksi,1) ZZZthksi.degmat(:,1)  ZZZthksi.degmat(:,2)],n,1); %bZomksi
 %end

[PIlist, PJlist]=find(Q22.coefficient); % This is the list of terms in P, but PIlist and Pjlist will be relatively short. 
[Prowu,Pcolu] = ind2sub([nbZ1 nbZ2],PJlist); % this returns the matrix locations for every term in P
tdegmat = [Q22.degmat(PIlist,:) bZdegmat1(Prowu,:)+bZdegmat2(Pcolu,:)];


newrow=ceil(Prowu/nZ1);
newcol=ceil(Pcolu/nZ2);

newidx=sub2ind([n n],newrow, newcol);%(newcol-1)*n+newrow;
nPIlist=(1:length(PIlist))';
coeff=sparse(nPIlist,newidx,1);
tmatdim=[n n];
CA3=polynomial(coeff,tdegmat,tvarname,tmatdim);

clear tdegmat tvarname tmatdim bZdegmat1 bZdegmat2 coeff nPIlist newidx newcol newrow row col Prowu Pcolu PIlist PJlist

% N1(s,t) = Z(s)^T Q_{12} Z(s,t) + Z(t,s)^T Q_{31} Z(t) 
%   + \int_{I(1)}^t Z(ss,s)^T Q_{33} Z(ss,t) dss
%       +\int_t^sZ(ss,s)^T Q_{32} Z(ss,t) dss
%       +\int_s^{I(2)}Z(ss,s)^T Q_{22} Z(ss,t) dss
disp('integrating')
N1=A1+B1+int(CA1,dum,I(1),var2)+int(CA2,dum,var2,var1)+int(CA3,dum,var1,I(2));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% start with N1 - N2 will be similar
%%%%%%%%%%%%%%%%%%%%%%%%%
% Construct Part A2
% A2=bZ1th.'*Q13*bZ2thksi;
disp('A2')

nZ1=nZth;nbZ1=n*nZ1;
nZ2=nZthksi;nbZ2=n*nZ2;
avarname=[Q13.varname; ZZZthksi.varname ];
% For the next part, we just need the degmat part of the block-diagonal
% monomial matrix
if strcmp(var1.varname{1},ZZZthksi.varname{1}); % var1 is in the first position
        bZdegmat1=repmat([ZZZth.degmat zeros(nZth,1)],n,1);
else
        bZdegmat1=repmat([zeros(nZth,1) ZZZth.degmat],n,1);
end
    bZdegmat2=repmat(ZZZthksi.degmat,n,1);
[PIlist, PJlist]=find(Q13.coefficient); % This is the list of terms in P, but PIlist and Pjlist will be relatively short. 
[Prowu,Pcolu] = ind2sub([nbZ1 nbZ2],PJlist); % this returns the matrix locations for every term in P
adegmat = [Q13.degmat(PIlist,:) bZdegmat1(Prowu,:)+bZdegmat2(Pcolu,:)];
[row,col] = ind2sub([n*nZth n*nZthksi],PJlist);
newrow=ceil(row/nZ1);
newcol=ceil(col/nZ2);
newidx=sub2ind([n n],newrow, newcol);%(newcol-1)*n+newrow;
nPIlist=(1:length(PIlist))';
coeff=sparse(nPIlist,newidx,1);
amatdim=[n n];
A2=polynomial(coeff,adegmat,avarname,amatdim);

%%%%%%%%%%%%%%%%%%%%%%%%%
% Construct Part B2
% We use the fact that
% B2=bZ2ksith.'*Q21*bZ1ksi
disp('B2')

 nZ1=nZthksi;nbZ1=n*nZ1;
 nZ2=nZth;nbZ2=n*nZ2;

%ZZZthksi.varname
tvarname=[Q21.varname; ZZZthksi.varname{2}; ZZZthksi.varname{1}];
bZdegmat1=repmat(ZZZthksi.degmat,n,1);
bZdegmat2=repmat([ZZZth.degmat zeros(nZth,1)],n,1);

[PIlist, PJlist]=find(Q21.coefficient);  
[Prowu,Pcolu] = ind2sub([nbZ1 nbZ2],PJlist); 
tdegmat = [Q21.degmat(PIlist,:) bZdegmat1(Prowu,:)+bZdegmat2(Pcolu,:)];
[row,col] = ind2sub([nbZ1 nbZ2],PJlist);
newrow=ceil(row/nZ1);
newcol=ceil(col/nZ2);
newidx=sub2ind([n n],newrow, newcol);
nPIlist=(1:length(PIlist))';
coeff=sparse(nPIlist,newidx,1);
tmatdim=[n n];
B2=polynomial(coeff,tdegmat,tvarname,tmatdim);
clear tdegmat tvarname tmatdim coeff nPIlist newidx newcol newrow row col Prowu Pcolu PIlist PJlist


%%%%%%%%%%%%%%%%%%%%%%%%%
% Construct CB2
%CA=bZ2omth.'*Q23*bZ2omksi;
%   Z(ss,s)^T Q_{33} Z(ss,t)
disp('CB2')

nZ1=nZthksi;nbZ1=n*nZ1;
nZ2=nZthksi;nbZ2=n*nZ2;
bZdegmat1=repmat([ZZZthksi.degmat(:,2) zeros(nZthksi,1)  ZZZthksi.degmat(:,1)],n,1); %bZomth
bZdegmat2=repmat([zeros(nZthksi,1) ZZZthksi.degmat(:,2)  ZZZthksi.degmat(:,1)],n,1); %bZomksi


tvarname=[Q23.varname; var1.varname{1}; var2.varname{1}; dum.varname{1}];
[PIlist, PJlist]=find(Q23.coefficient); % This is the list of terms in P, but PIlist and Pjlist will be relatively short. 
[Prowu,Pcolu] = ind2sub([nbZ1 nbZ2],PJlist); % this returns the matrix locations for every term in P
tdegmat = [Q23.degmat(PIlist,:) bZdegmat1(Prowu,:)+bZdegmat2(Pcolu,:)];
newrow=ceil(Prowu/nZ1);
newcol=ceil(Pcolu/nZ2);
newidx=sub2ind([n n],newrow, newcol);%(newcol-1)*n+newrow;
nPIlist=(1:length(PIlist))';
coeff=sparse(nPIlist,newidx,1);
tmatdim=[n n];
CB2=polynomial(coeff,tdegmat,tvarname,tmatdim);
clear tdegmat tmatdim coeff nPIlist newidx newcol newrow row col Prowu Pcolu PIlist PJlist

N2=A2+B2+int(CA1,dum,I(1),var1)+int(CB2,dum,var1,var2)+int(CA3,dum,var2,I(2));

end
