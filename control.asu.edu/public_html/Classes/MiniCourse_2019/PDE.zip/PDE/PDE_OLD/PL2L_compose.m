function [Mnew, N1new, N2new] = semisep_MN1N2_compose(Ma,N1a,N2a,Mb,N1b,N2b,var1,var2,II)
pvar sss
a=II(1);b=II(2);
%
% SEMISEP_MN1N2_COMPOSE(Ma,N1a,N2a,Mb,N1b,N2b) takes two operators of the
% form P_{M,N_1,N_1} and computes the matrices Mn,N1n,N2n such that 
% P_{Mn,N1n,N2n}=P_{Ma,N1a,N2a}P_{Mb,N1b,N2b} 
%
% The formulae for {Mn,N1n,N2n} are given as 
% M(s) = Ma(s)Mb(s)
% N1n(s,\theta)=Ma(s)N_1b(s,\theta)+N_1a(s,\theta)Mb(\theta)
%               +\int_{a}^\theta N_1a(s,\xi) N_2b(\xi,\theta)d \xi 
%               +\int_{\theta}^s N_1a(s,\xi) N_1b(\xi,\theta)d \xi
%               + \int_{s}^b N_2a(s,\xi) N_1b(\xi,\theta)d \xi
% N2n(s,\theta)=Ma(s)N_2b(s,\theta)+N_2a(s,\theta)Mb(\theta)
%               +\int_{a}^s N_1a(s,\xi) N_2b(\xi,\theta)d \xi
%               +\int_{s}^\theta N_2a(s,\xi) N_2b(\xi,\theta)d \xi
%               +\int_{\theta}^b N_2a(s,\xi) N_1b(\xi,\theta)d \xi
% 
% INPUTS 
%   Ma: diagonal multiplier
%   N1a: subdiagonal kernel
%   N2a: superdiagonal kernel
%   Mb: diagonal multiplier
%   N1b: subdiagonal kernel
%   N2b: superdiagonal kernel
%   var1: Single pvar corresponding to s in the description
%   var2: Single pvar corresponding to t in the description
%   II = [a b] interval of integration
%
% OUTPUT 
%   Mnew: diagonal multiplier
%   N1new: subdiagonal kernel
%   N2new: superdiagonal kernel
%
% NOTES:
% Distributed with DelayTOOLS
% Compatable with MULTIPOLY and SOSTOOLS as of June 2013
% For support, contact M. Peet, Arizona State University at mpeet@asu.edu

Mnew=Ma*Mb;
N1na=Ma*N1b+N1a*subs(Mb,var1,var2);
N1nb=int(subs(N1a,var2,sss)*subs(N2b,var1,sss),sss,a,var2);
N1nc=int(subs(N1a,var2,sss)*subs(N1b,var1,sss),sss,var2,var1);
N1nd=int(subs(N2a,var2,sss)*subs(N1b,var1,sss),sss,var1,b);
N1new=N1na+N1nb+N1nc+N1nd;

N2na=Ma*N2b+N2a*subs(Mb,var1,var2);
N2nb=int(subs(N1a,var2,sss)*subs(N2b,var1,sss),sss,a,var1);
N2nc=int(subs(N2a,var2,sss)*subs(N2b,var1,sss),sss,var1,var2);
N2nd=int(subs(N2a,var2,sss)*subs(N1b,var1,sss),sss,var2,b);
N2new=N2na+N2nb+N2nc+N2nd;


% end code

