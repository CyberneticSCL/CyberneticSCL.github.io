function [prog,P,Q,R,S] = sosjointpos_mat_ker_ndelay_PQRS_vZ(prog,n1,n2,d1,d2,var1,var2,delays,override)
%
% SOSJOINTPOS_MAT_KER_NDELAY_R_L2_v2(prog,n,d1,d2,var1,var2,I) creates a
% dilated version of the matrix kernel pair using variable substitution
% The PQRS define a positive operator of the form
%
% P_{PQRS}[x  ] = [Px + \sum_i \int_{I{i}(1)}^0Q_i(s)y_i(s)ds
%         [y_i]   [tauK Q_i(s)^T + tauK S_i(s)y_i(s)+\sum_j \int_{I{j}(1)}^0 R_{ij}(s,t)y_j(t)dt

% INPUTS 
%   prog: SOS program to modify.
%   n: dimension of the resulting matrix
%   d1: degree of the multiplier (sort of)
%   d2: degree of the kernel
%   var1: Single pvar corresponding to s in the description
%   var2: Single pvar corresponding to t in the description
%   delays = a list of delays from smallest to largest
%
% OUTPUT 
%   P: 
%   Q{i}: A cell array of functions of var1 valid on the intervals [-tau_i, 0]
%   S{i}: A cell array of functions of var1 valid on the intervals [-tau_i, 0]
%   R{i,j}: A cell array of kernels valid on the intervals [-tau_i, 0] in variable
%   var1 and intervals [-tau_j, 0] in variable var2 
%
% NOTES:
% Distributed with DelayTOOLS
% Compatable with MULTIPOLY and SOSTOOLS as of June 2013
%
% This is based on Lemma 3 in the notes entitled
% notes_indexed_RL2_ndelay_04_19_2018.pdf
%
% Created 4/20/18        -  sosjointpos_mat_ker_ndelay_PQRS_vZ
%
% For support, contact M. Peet, Arizona State University at mpeet@asu.edu



if ~isvalid(var1) || ~isvalid(var2)
  error(['vars must be a polynomial variable']);
end

switch nargin
    case 7
    error(['Not enough inputs!'])       
    case 8
        override=0;
end

nints=length(delays);
diag=n2;
tauK=delays(nints);
[prog, M1, N1] = sosjointpos_mat_ker_R_L2(prog,n1,n2*nints,d1,d2,var1,var2,[-tauK,0],diag);
[prog, M2, N2] = sosjointpos_mat_ker_R_L2_psatz(prog,n1,n2*nints,d1,d2,var1,var2,[-tauK,0],override,diag);
%M1
%M2=0*M1; N2=0*N1;
M=M1+M2;
N=N1+N2;
for i=1:nints
%    tau(i)=-I{i}(1);
    a(i)=delays(i)/tauK;
    irange=(n1+1+(i-1)*n2):(n1+i*n2);
    Qh{i}=M(1:n1,irange)/tauK;
    Sh{i}=M(irange,irange)/tauK;
    for j=1:nints
        irange2=(1+(i-1)*n2):(i*n2);
        jrange2=(1+(j-1)*n2):(j*n2);
        Rh{i,j}=N(irange2,jrange2);
    end
end
P=M(1:n1,1:n1);
for i=1:nints
    Q{i}=1/sqrt(a(i))*subs(Qh{i},var1,var1/a(i));   
    S{i}=subs(Sh{i},var1,var1/a(i));   
    for j=1:nints
        R{i,j}=1/sqrt(a(i)*a(j))*subs(subs(Rh{i,j},var1,var1/a(i)),var2,var2/a(j));   
    end
end







