clear all; close all; echo off;
total=tic;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% DelayTools/Linear v1.0 - solver_ndelay_opt_estimator
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This program finds a full-state estimator which minimizes an
% H_\infty bound on disturbance to the original system to regulated error. The system has the form
% \dot{x}(t)=A0x(t)+A{1}x(t-tau(1))+...+A{K}x(t-tau(K)) + Bw(t)
% y(t)=C_2x(t) +Dw(t)     - measured output
% z(t)=C10x(t)+C1{1}x(t-tau(1))+...+C1{K}x(t-tau(K))  - regulated output
% where w(t) is the vector of disturbances
%
% The estimator has the form
% \dot \hat x(t)=A0\hat x(t)+A{1}\hat x(t-tau(1))+...+A{K}\hat x(t-tau(K))
%                +L0e0(t)+\sum_i L2{i}ei(-tau(i))+\sum_i \int_{-tau(i)}^0
%                L3{i}(s)ei(t+s)ds
% \dot \phi{i}(t,s)=d/ds \phi{i}(t+s)+L4{i}(s)e0+\sum_j
%                L5{i,j}(s)phi{j}(-tau(j)) + L6{i}(s)ei(t+s)+\sum_j \int_{-tau(j)}^0
%                L7{i,j}(s,th)ei(t+th)d th
% where e0(t)=C2\hat x(t)-y(t), ei(t+s)=C2 \phi{i}(t+s)-y(t+s)
%
%
% where A0, A{i}, B, C10, C2, C1{i} and tau(i) are all user inputs.
%
% Inputs: A0, A{i} - matrices of dimension n x n (n is arbitrary)
%
%         B - a matrix of dimension n x r (r is arbitrary)
%
%         C10, C1{i} - matrices of dimension p x n (p is arbitrary)
%
%         C2 - a matrix of dimension q x n (q is arbitrary)
%
%         tau(i) - These can be an arbitrary sequence of positive increasing
%         numbers.
%
%         orderth/ordernu - This input controls the accuracy of the results. For
%         most problems, orderth=ordernu=4 should be sufficient to obtain a
%         reasonable degree of accuracy. Note: orderth should be an even
%         integer.
%
% Requirements: In order to operate, this program requires a working
%               version of SOStools. There are some known compatability
%               issues with SOStools and Matlab version 7+ due to errors in
%               the implementation of Maple v8. In addition, it
%               is highly recommended that the user have a compiled version
%               of cdd. Finally the following package of subprograms are
%               required which allows SOStools to handle matrix objects
%               directly:
%               SOStools Matrix Addon package:
%                   sosposmatr.m
%                   sosmateq.m
%                   sosjointpos_mat_ker_ndelay_PQRS_vZ
%                   sosjointpos_mat_ker_R_L2
%                   sosjointpos_mat_ker_R_L2_psatz
%
% version .03   M. Peet, Arizona State University. mpeet@asu.edu
%% Initial Coding:
% 8/15/18 - MMP  -  titled solver_ndelay_opt_control.m
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs
%
% Enter degree of accuracy - must be an even integer
orderth = 2;  % this number is twice that listed in the paper as d
ordernu = 4;  % it is recommended to use ordernu = 2*orderth in order to match degrees
override1=0; % if override1=1, the LF will not include psatz terms in the kernel - default=0
override2=0; % if override2=1, the derivative check will not include psatz terms in the kernel - default=0

%%%%%%%%%%%%%%%%%%%
% Simulation Options:
nspans=20; % Length of simulation as measured by a multiple of the max delay
N=50;     % number of discrete states used to represent the history of each delay




% % %
% % % paper by Fattouh, Sename, Dion
% A0=[-10 10; 0 1];
% A{1}=[1 1; 1 1];
% tau(1)=.3;
% C2=[0 10];
% B=[1;1];%B=[1;1];
% C10=eye(2);C1{1}=0*C10;
% % D=0;
% % gam=.004;

% % Example 2 from review paper by Sename (weakly, spectrally, but not
% % strongly observable) page 443,445,446,447
% A0=[-3 4; 2 0];
% A{1}=[0 0; 1 0];
% tau(1)=.3;
% C2=[0 7]; %C
% B=[1;1]; %E
% % We set F=0. Likewise B=0 (no input)
% C10=eye(2); C1{1}=0*C10;
% gam=.001;

% % % Example 2 from review paper by Sename (weakly, spectrally, but not
% % % strongly observable) page 443,445,446,447 %%% MODIFIED
% A0=[-3 4; 2 0];
% A{1}=[0 0; 1 0];
% tau(1)=.3;
% C2=[0 7]; %C
% B=eye(2); %E
% % We set F=0. Likewise B=0 (no input)
% C10=eye(2); C1{1}=0*C10;
% 
% gam=.232;   % Best from Sename is .58 using eps=.001
% % %.2357 using order [4 8], epspos=.01, espneg=.001 new wrapper
% % %.2357 using order [2 4], epspos=.01, espneg=.001 new wrapper
% % 


% %Fridman 2001 example
% A0=[0 0; 0 1];
% A{1}=[-1 -1; 0 -.9];
% tau(1)=.999;
% C2=[0 1]
% B=[1;1];%B=[1;1];
% C1=[1 0];
% gam=.001;

% D=[1];
% %

% % % %Fridman 2001 example modified
% A0=[0 0; 0 1];
% A{1}=[-1 -1; 0 -.9];
% tau(1)=1; 
% C2=[0 1]; %sensed output
% B=[eye(2)];%B=[1;1];
% C10=[1 0];C1{1}=0*C10;C1{2}=0*C10;

% Pade gives 2.327
% %2.3323 using order [2 4], epspos=.1, espneg=.01 old wrapper
% %2.327 using order [4 8], epspos=.1, espneg=.01 new wrapper
% %2.33 using order [4 8], epspos=.01, espneg=.001 new wrapper


% %
% %Fridman 2001 example modified - 2 delay
A0=[0 0; 0 1];
A{1}=[-1 -1; 0 -.9]/2;
A{2}=[-1 -1; 0 -.9]/2;
tau(1)=.5; tau(2)=1;
C2=[0 1]; %sensed output
B=[eye(2) zeros(2,1)];%B=[1;1];
C10=[1 0];C1{1}=0*C10;C1{2}=0*C10;



%
% % % Briat Thesis, also Javad 2007
% A0=[0 1; -2 -3];
% A{1}=[0 0.1; -.2 -.3];
% tau=2.8;
% C2=[0 1;.5 0]; %C
% B=[-.2;-.2]; %E
% C1=eye(2);
% gam=.005;
% D=[0;0];
%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% End User Defined Inputs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\
 padeorder=6;
% norm_est=CL_norm_estimator(tau,A0,A,B1,B2,C0,C,D1,D2,padeorder);
% disp('The minimum estimated CL norm using Pade is ')
% norm_est
tic
norm_est=CL_estimator_norm_pade(tau,A0,A,B,C10,C1,C2,padeorder)
toc
% %====================




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% internal variables:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%fact=1/tau;
fact=1;           % conditioning multiplier
eps1=.00001;           % strictness of LF w/r to norm{x(0)} - must be strictly positive (but can be small)
eps11=0;          % strictness of LF w/r to norm{x_t}_{L2}
eps2=0;%.0001;           % strictness of derivative negativity
%epsbig=1000;

% control inputs to SeDuMi
pars.alg=2;
pars.stepdif=1;
pars.eps=10^(-10);
pars.maxiter=100;
pars.cg.maxiter=200;
pars.cg.qprec=1;
pars.cg.stagtol=1e-22;
pars.cg.restol=5e-5;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% internal processing:
pvar th ksi

n_dim=length(A0);
r_dim=size(B,2); % disturbance size
p_dim=size(C10,1); % regulated output size
q_dim=size(C2,1); % measured output size
n_delay=length(tau);
tauK=tau(n_delay);

n_ins=r_dim;
n_outs=p_dim;
n_sens=q_dim;

mastervartable=[th,ksi];
% prog = sosprogram(mastervartable);

pvar gam
prog = sosprogram(mastervartable,[gam]);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Begin Code
disp('creating joint positive operator variable')


% This is the multiple delay case.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% phase 1 - variables %%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% we will need to declare variables:
% P, Q(th), S(th), R(th,ksi)
%
disp('creating joint positive operator variable')
[prog,P,Q,R,S] = sosjointpos_mat_ker_ndelay_PQRS_vZ(prog,n_dim,n_dim,orderth/2,ordernu/2,th,ksi,tau,override1);

P=P+eps1*eye(n_dim); % making the operator strictly positive


for i=1:n_delay % the latter i define constraints
    S{i}=S{i}+eps11*eye(n_dim);
end


disp('creating Observer Variables')
% Z variables
orderZ=2*orderth;
[prog, Z0]= sosmatrvar(prog,[1],[n_dim,q_dim]);
for i=1:n_delay % the latter i define constraints
    [prog, Z2{i}]= sosmatrvar(prog,[1],[n_dim,q_dim]);
    [prog, Z3{i}]= sosmatrvar(prog,monomials(th,0:orderZ),[n_dim,q_dim]);
    [prog, Z4{i}]= sosmatrvar(prog,monomials(th,0:orderZ),[n_dim,q_dim]);
    [prog, Z6{i}]= sosmatrvar(prog,monomials(th,0:orderZ),[n_dim,q_dim]);
    for j=1:n_delay
        [prog, Z5{i,j}]= sosmatrvar(prog,monomials(th,0:orderZ),[n_dim,q_dim]);
        [prog, Z7{i,j}]= sosmatrvar(prog,monomials([th,ksi],0:orderZ),[n_dim,q_dim]);
    end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% phase 2 - derivatives %%%%%%%%%%%%%%%%%%%%
%%%%%%% Step1 %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% the derivative matrices are spelled out in the paper, they are
disp('constructing Derivatives, elapsed time:')
tic

%%%%%%%%%%%%% First Term %%%%%%%%%%%%%%%%%%%%%%% (recycled)
% This first term is the standard {PA}+{A^TP} part
D11=P*A0+A0.'*P;
D12=[];
D22=[];
for i=1:n_delay
    D11=D11+subs(Q{i}.'+Q{i}+S{i},th,0);
    D12=[D12 P*A{i}-subs(Q{i},th,-tau(i))];
    D22=blkdiag(D22,(subs(-S{i},th,-tau(i))));
end
D21=D12.';

% note the notation is off, zpp should be zpp
zpp=polynomial(zeros(n_outs,n_outs));
zpi=polynomial(zeros(n_outs,n_ins));
zpn=polynomial(zeros(n_outs,n_dim));
zpnk=polynomial(zeros(n_outs,n_dim*n_delay));
zii=polynomial(zeros(n_ins,n_ins));
zip=polynomial(zeros(n_ins,n_outs));
zin=polynomial(zeros(n_ins,n_dim));
zink=polynomial(zeros(n_ins,n_dim*n_delay));
znn=polynomial(zeros(n_dim,n_dim));
znnk=polynomial(zeros(n_dim,n_dim*n_delay));
znknk=polynomial(zeros(n_dim*n_delay,n_dim*n_delay));

D1=[zii    zip    zin  zink;
    zip.'  zpp    zpn  zpnk;
    zin.'  zpn.'  D11  D12;
    zink.' zpnk.' D21  D22];


for i=1:n_delay
    E1{i}=A0.'*Q{i} - diff(Q{i},th);
    for j=1:n_delay
        E1{i}=E1{i}+subs(R{i,j}.',ksi,0)/tauK;
    end
    for j=1:n_delay
        E1{i}=[E1{i}; A{j}.'*Q{i}-subs(R{i,j}.',ksi,-tau(j))/tauK];
    end
    E1{i}=[zin; zpn; E1{i}];
    F1{i}=diff(-S{i},th);
end
for i=1:n_delay
    for j=1:n_delay
        G1{i,j}=-(diff(R{i,j},th)+diff(var_swap(R{j,i}.',th,ksi),ksi));
    end
end

%%%%%%%%%%%%%%%%%%%%% 2nd term %%%%%%%%%%%%%%%%%%% (new)



Z11=Z0*C2+C2.'*Z0.';
Z12=[];
for i=1:n_delay
    Z12=[Z12 Z2{i}*C2];
end
D2=[zii    zip    zin   zink;
    zip.'  zpp    zpn   zpnk;
    zin.'  zpn.'  Z11   Z12;
    zink.' zpnk.' Z12.' znknk];


for i=1:n_delay
    E2{i}=Z3{i}*C2+C2.'*Z4{i}.';
    for j=1:n_delay
        E2{i}=[E2{i}; C2.'*Z5{i,j}.'];
    end
    E2{i}=[zin; zpn; E2{i}];
    F2{i}=Z6{i}*C2+C2.'*Z6{i}.';
end

for i=1:n_delay
    for j=1:n_delay
        G2{i,j}=tauK*(Z7{i,j}*C2+C2.'*var_swap(Z7{j,i}.',th,ksi));
    end
end


%%%%%%%%%%%%%%%%%%%%% 4th term %%%%%%%%%%%%%%%%%%% (recycled)
D4=polynomial(zeros(n_ins+n_outs+n_dim*(n_delay+1)));
D4((n_ins+n_outs+1):(n_ins+n_outs+n_dim),1:n_ins)=P*B;
D4(1:n_ins,(n_ins+n_outs+1):(n_ins+n_outs+n_dim))=B.'*P;

for i=1:n_delay
    E4{i}=[B.'*Q{i}; zpn; znn.'; znnk.'];
    %    D31{i}=D13{i}.';
end

%%%%%%%%%%%%%%%%%%%%% 5th term %%%%%%%%%%%%%%%%%%% (recycled)

D5h=C10;
for i=1:n_delay
    D5h=[D5h C1{i}];
end
D5=1/tauK*[-gam*eye(n_ins) zip              [zin zink];
           zip.'           -gam*eye(n_outs) D5h;
           [zin zink].'    D5h.'            [znn znnk;znnk.' znknk]];
for i=1:n_delay
    F5{i}=polynomial(eps11*eye(n_dim));
end

Df=D1+D2-D4+D5;
for i=1:n_delay
    Ef{i}=E1{i}+E2{i}-E4{i};
    Ff{i}=F1{i}+F2{i}+F5{i};
    for j=1:n_delay
         Gf{i,j}=G1{i,j}+G2{i,j};
    end
end








%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Step2 %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Enforce negativity of D
disp('enforcing negativity of derivative')

disp('Calling for jointly positive Mat/Kernel, elapsed time:')
tic
[prog,P2,Q2,R2,S2] = sosjointpos_mat_ker_ndelay_PQRS_vZ(prog,n_ins+n_outs+(n_delay+1)*n_dim,n_dim,orderth/2,ordernu/2,th,ksi,tau,override2);


toc

disp('Constructing Equality Constraints:')

tic
prog = sosmateq(prog,P2+Df);
for i=1:n_delay
    prog = sosmateq(prog,Q2{i}+Ef{i});
    prog = sosmateq(prog,S2{i}+Ff{i});
    for j=i:n_delay % the latter j>=i define unique constraints
        prog = sosmateq(prog,R2{i,j}+Gf{i,j});
    end
end

disp('TOTAL POLYNOMIAL TIME:')
toc(total)

prog=sossetobj(prog,gam);

disp('Computing Solution')
%prog = sossolve(prog);
prog = sossolve_p(prog,pars);
% %% Conclusion:
% if norm(prog.solinfo.info.feasratio-1)<=.1 && ~prog.solinfo.info.numerr
%     disp('The Observer Design is Feasible.')
% elseif norm(prog.solinfo.info.feasratio-1)<=.1 && prog.solinfo.info.numerr
%     disp('The Observer Design is likely Feasible. However, Double-check the precision.')
% elseif prog.solinfo.info.pinf || prog.solinfo.info.dinf || norm(prog.solinfo.info.feasratio+1)<=.1
%     disp('The Observer Design is Probably not Feasible.')
% else
%     disp('Unable to definitively determine feasibility. Numerical errors dominating or at the limit of stability.')
% end

disp('The Closed-Loop Hinf norm bound obtained was')
ngam=sosgetsol(prog,gam)

% Now extract the solution....

r=tau(n_delay);
tauK=tau(n_delay);
NP = double(sosgetsolmat(prog,P,10));
NZ0 = double(sosgetsolmat(prog,Z0,10));
for i=1:n_delay
    NQ{i} = sosgetsolmat(prog,Q{i},10);
    NS{i} = sosgetsolmat(prog,S{i},10);
    NZ2{i} = sosgetsolmat(prog,Z2{i},10);
    NZ3{i} = sosgetsolmat(prog,Z3{i},10);
    NZ4{i} = sosgetsolmat(prog,Z4{i},10);
    NZ6{i} = sosgetsolmat(prog,Z6{i},10);
    
    for j=1:n_delay
        NR{i,j} = sosgetsolmat(prog,R{i,j},10)/tauK; % the /tau is to match the input format of the inverse function
        NZ5{i,j} = sosgetsolmat(prog,Z5{i},10);
        NZ7{i,j} = sosgetsolmat(prog,Z7{i},10);
        dZ7{i,j}=max(max(NZ7{i,j}.degmat));
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% We now have the variables and the next step is computing the inverse of
% P_{P,Q,S,R}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

tspan=nspans*tau(n_delay);  % length of simulation and number of states representing the delay
% where the states are determined by the values of s in xmesh

[bigZ,P_h,H_h,Gam_h] = P_PQRS_Inverse_joint_sep_ndelay_vtau_alt(NP,NQ,NR,NS,tau);

% % check that this is in the right format!!!!
% for i=1:n_delay
%         H_h{i}=H_h{i}/tauK;
%         S_h{i}=S_h{i}/tauK^2;  % this term needs to be corrected in the formulae below!!!
%     for j=1:n_delay
%         Gam_h{i,j}=Gam_h{i,j}/tauK;
%     end
% end
% For convenience, we would like to represent NZ4, NZ5, NZ6, NZ7 using the
% common basis bigZ

% 

dMaxZ4=max(max(NZ4{1}.degmat));
dMaxZ5=max(max(NZ5{1,1}.degmat));
dMaxZ6=max(max(NZ6{1}.degmat));
dMaxZ7=max(max(NZ7{1,1}.degmat));
dMax=max(max(bigZ.degmat)); % for this implementation, we require the degree of bigZ to be greater than or equal to that of Z4,Z5,Z6 and Z7

if dMax<max([dMaxZ4 dMaxZ5 dMaxZ6 dMaxZ7])
    error('degree of Zi must be less than or equal to that of R')
end


[Z4_mat,Zright] = decomposition_multiplier_v1(NZ4,1,dMax);
[Z5_mat,Zright] = decomposition_multiplier_v1(NZ5,1,dMax);
[Z6_mat,Zright] = decomposition_multiplier_v1(NZ6,1,dMax);
[Zleft,Z7_mat,Zright] = decomposition_kernel_v1(NZ7,th,ksi,dMax);

% NZ5_T = cellfun(@transpose,NZ5,'UniformOutput',false)
% [Z5_mat_T,Zright] = decomposition_multiplier_v1(NZ5_T,'',dMax);
% Z5_mat = cellfun(@transpose,Z5_mat_T,'UniformOutput',false)



for i=1:n_delay
    int_fun_temp = @(sss) double(subs_p(bigZ,th,sss))*inv(double(subs_p(NS{i},th,sss)))*double(subs_p(bigZ,th,sss)).';
    % Uses Matlab internal numerical integration routine.
    TT{i}=integral(int_fun_temp,-tau(i),0,'ArrayValued',true,'AbsTol',1e-12,'RelTol',1e-10);
%    NSi{i}=inv(double(subs_p(NS{i},th,-tau(i))));
    int_fun_V{i} = @(sss) double(subs(bigZ,th,sss))*inv(double(subs(NS,th{i},sss)))*double(subs(bigZ,th,sss)).';
    fun_X{i} = @(sss) inv(double(subs(NS{i},th,sss)))*double(subs(bigZ,th,sss)).';
end

L0=P_h*NZ0;
for i=1:n_delay
    L0=L0+H_h{i}*TT{i}*Z4_mat{i};
end

for i=1:n_delay
    L2{i}=P_h*NZ2{i};
    for j=1:n_delay
       L2{i}=L2{i}+H_h{j}*TT{j}*Z5_mat{j,i};
    end
end


for i=1:n_delay
    clear temp
    temp=H_h{1}*TT{1}*Z7_mat{1,i};
    for j=2:n_delay
       temp=temp+H_h{j}*TT{j}*Z7_mat{j,i};
    end
    temp=double(temp);
    fun_L3{i} = @(sss) double(P_h*subs(NZ3{i},th,sss))+H_h{i}*double(subs(bigZ,th,sss))*inv(double(subs(NS{i},th,sss)))*double(subs(bigZ,th,sss)).'*double(Z6_mat{i})+temp*double(subs(Zright,ksi,sss));
end

for i=1:n_delay
    L4_h{i}=H_h{i}.'*NZ0+Z4_mat{i};
    for j=1:n_delay
       L4_h{i}=L4_h{i}+Gam_h{i,j}*TT{j}*Z4_mat{j};
    end
end

for i=1:n_delay
    for j=1:n_delay
        L5_h{i,j}=H_h{i}.'*NZ2{j}+Z5_mat{i,j};
        for k=1:n_delay
            L5_h{i,j}=L5_h{i,j}+Gam_h{i,k}*TT{k}*Z5_mat{k,j};
        end
    end
end

for i=1:n_delay
    L6_h{i}=Z6_mat{i} ;
end
for i=1:n_delay
    for j=1:n_delay
        temp3=Z7_mat{i,j};
        for k=1:n_delay
            temp3=temp3+Gam_h{i,k}*TT{k}*Z7_mat{k,j};
        end
        temp3=double(temp3);
        fun_L7{j} = @(sss) double(H_h{i}.'*subs(NZ3{j},th,sss))+double(Gam_h{i,j})*double(subs(bigZ,th,sss))*inv(double(subs(NS{j},th,sss)))*double(subs(bigZ,th,sss)).'*double(Z6_mat{j})+temp3*double(subs(Zright,ksi,sss));
    end
end
%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% disturbance version
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% For implementation, we construct the matrix representation of L
%%% In the multi-delay case, we have two options, we can create a separate
%%% set of states for every [-tau_i,0] or for every [-tau_i, -tau_{i-1}]
%%% Naturally, the first option creates significantly more states, but
%%% is more consistent with our state-space representation, wherein
%%% there is a separate pipe for every delay. I am also concerned there
%%% could be losses at the transition between pipes if the
%%% discretization step is different for each section of the pipe.
%%% Obviously, the ideal would be a uniform discretization, but this is
%%% not possible unless the delays are commensurate. Finally, the
%%% separate pipe strategy adapts well to the differential-difference
%%% formulation where the pipes have different sizes.
%%%
%%% For these reasons, we will use a signficantly inflated state-space
%%% corresponding to a separate set of states for each interval of
%%% delay [-tau_i,0]. This will result in N*n_dim*n_delay states in the
%%% ODE representation.
% the tau_i is increasing
% the total number of states is n_dim*((N-1)*n_delay+1)=n_dim*N*n_delay-n_delay*n_dim+ndim because the final n_dim states are common to all (the current state)
% The set of states associated with [-tau_i,0] is (N-1)*n_dim*(i-1)+1:(N-1)*n_dim*i
nstates=n_dim*N*n_delay-n_delay*n_dim+n_dim;
%nstates=n_dim*(N-1)*n_delay+n_dim;
rangef=(n_dim*(N-1)*n_delay+1):n_dim*((N-1)*n_delay+1);
% I think there was an error in rangef in the previous implementation
%rangef=(n_dim*(N*n_delay-1)+1):n_dim*N*n_delay; % this is the Final(f) set of states which define the current time

%%% Unlike in the controller synthesis case, for the observer the observer
%%% maps a distributed error whose size is only partially reduced by the
%%% matrix C2, which is of dimension n_dim x q_dim, where q_dim<n_dim. For
%%% implementation, we may either use the disturbance representation of the
%%% nominal system, where we only have access to the output and the
%%% internal states are not modeled, or we may double the number of states
%%% to create an auxiliary set of states corresponding to the nominal
%%% system. To accomodate both options, we then construct the observer
%%% gains as a matrix of size q_dim*N*n_delay-n_delay*q_dim+q_dim
nstates_out=q_dim*N*n_delay-n_delay*q_dim+q_dim;
rangef_out=(q_dim*(N-1)*n_delay+1):q_dim*((N-1)*n_delay+1);
%rangef_out=(q_dim*(N*n_delay-1)+1):q_dim*N*n_delay; % this is the output of the Final(f) set of states which define the current time




clear L1M L2M L3M L4M L5M L6M L7M L7Mt
L1M=double(L0);
Lpr=zeros(nstates,nstates_out); % this will be the correction to the current state estimate

Lpr(rangef,rangef_out)=L1M;

for i=1:n_delay
    xmesh{i}=linspace(-tau(i),0,N);
    dx(i)=xmesh{i}(2)-xmesh{i}(1);
    
    L2M{i}=double(L2{i});
    ii=0;
    for xi=xmesh{i}
        ii=ii+1; % ii=1 is xi=-tau, ii=N is present (xi=1)
        L3M{i}(:,:,ii)=fun_L3{i}(xi); % evaluates L3 at every point in the mesh
    end
    begin=(N-1)*q_dim*(i-1);        % this is the index for the output for the last state in the previous interval.
    Lpr(rangef,(begin+1):(begin+q_dim))=L2M{i}+L3M{i}(:,:,1)*dx(i);
    for ii=2:N-1
        rangei2=(begin+(ii-1)*q_dim+1):(begin+ii*q_dim);
        Lpr(rangef,rangei2)=L3M{i}(:,:,ii)*dx(i);
    end
    % I have this commented to skip the final period of integration.
    % Alternatively, we could skip the first period, but one should be
    % skipped for each interval
    %        Kprt(1:p_dim,rangef)=Kprt(1:p_dim,rangef)+K2M{i}(:,:,N)*dx(i);
    
end

%%% We have now set up the matrix for corrections to the present state
%%% estimate. We now turn to corrections to the estimate of the state
%%% history
range0=1:size(L4_h{1},1);
for i=1:n_delay % j will index the interval of the history we are correcting
    begini=(N-1)*n_dim*(i-1);        % this is the index for last state in the previous interval to be corrected.
    ii=0;
    for xi_i=xmesh{i}
        ii=ii+1;
        XM{i}(:,:,ii)=double(fun_X{i}(xi_i)); % evaluates L3 at every point in the mesh
%        XM{i}(:,:,ii)=double(tauK*fun_X{i}(xi_i)); % evaluates L3 at every point in the mesh
    end
    for j=1:n_delay % i will index the interval of the error output
        jj=0;
        for xi_j=xmesh{j}
            jj=jj+1;
            L7M{i,j}(:,:,jj)=fun_L7{j}(xi_j); % evaluates L3 at every point in the mesh
        end        
    end
    
    Ltemp(range0,rangef_out)=double(L4_h{i});
    for j=1:n_delay % i will index the interval of the error output
        beginj=(N-1)*q_dim*(j-1);        % this is the index for the output for the last state in the previous interval. ie before y(t-tau_j)
        Ltemp(range0,(begin+1):(begin+q_dim))=L5_h{i,j}+L7M{i,j}(:,:,1)*dx(j);
        for jj=2:N-1 % indices of error states we are weighting
                rangej2=(beginj+(jj-1)*q_dim+1):(beginj+jj*q_dim);
                Ltemp(range0,rangej2)=L7M{i,j}(:,:,jj)*dx(j);
        end   
    end
    % we have now constructed the Right side of the correction term. We now
    % distribute this over the states to be corrected
    for ii=2:N-1 % these are the indices of the state we are correcting
        rangei2=(begini+(ii-1)*n_dim+1):(begini+ii*n_dim); % the range of states to be corrected for this jj s=xmesh{j}(jj)
        Lpr(rangei2,:)=XM{i}(:,:,ii)*Ltemp;
    end
end

%%%%%%%%%%%%%%%% System Matrices %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% We now construct the Nominal derivative matrices for the state

% We are building a representation of the form \dot x = (A+B2K)x + B1 w

% Apr respresents the uncontrolled dynamics after discretization for both
% the estimator and the nominal system
Apr=zeros(nstates,nstates);
% B1pr represents the effect of disturbance on the nominal system
B1pr=zeros(nstates,r_dim);
% Cpr1 is the map from states to the error signal 
Cpr1=zeros(nstates_out,nstates);
% Cpr2 is the map from error states to the regulated output 
Cpr2=zeros(p_dim,nstates);
% Dpr is the map from disturbance to corruption of the error signal 
%Dpr=zeros(nstates_out,r_dim);


for i=1:n_delay
    begin=(N-1)*n_dim*(i-1);        % this is the index for the last state in the previous interval.
    ranges=begin+1:(N-1)*n_dim*i; % this is the range of indices for states in the current interval
    
    % This matrix is of size (N-1)*n_dim x N*n_dim
    Apr_temp=[-eye((N-1)*n_dim)/dx(i) zeros((N-1)*n_dim,n_dim)]+[zeros((N-1)*n_dim,n_dim) eye((N-1)*n_dim)/dx(i)];
    %         ranges=(N-1)*n_dim*(i-1)+1:(N-1)*n_dim*i;
    Apr(ranges,ranges)=Apr_temp(1:(N-1)*n_dim,1:(N-1)*n_dim);
    Apr(ranges,rangef)=Apr_temp(:,(N-1)*n_dim+1:N*n_dim);
    Apr(rangef,begin+1:begin+n_dim)=A{i}; % this picks out the states x(t-\tau_i)
    
    Cpr2(1:p_dim,begin+1:begin+n_dim)=C1{i};   % this picks out the states x(t-\tau_i)    
end

Apr(rangef,rangef)=A0;                    % this picks out the states x(t)
Cpr2(1:p_dim,rangef)=C10;                   % This is the output from the current state
Cpr1=kron(eye((N-1)*n_delay+1),C2);
%Dpr=repmat(D,(N-1)*n_delay+1,1);

%B2pr(rangef,1:p_dim)=B2;                  % the input only affects the dynamics of the current state
B1pr(rangef,1:r_dim)=B;                  % the disturbance only affects the dynamics of the current state


%    Now Construct the closed-loop system matrices
% The system has the form
%      \dot x = Ax + Bw
% \dot \hat x = A \hat x +L (C1 \hat x - C1 x)
% y   =
    Acl=[Apr zeros(size(Apr));
        -Lpr*Cpr1 Apr+Lpr*Cpr1];
%     Bcl=[B1pr;
%         zeros(size(B1pr))];
    Bcl=[B1pr;
        zeros(size(B1pr))];

    Ccl=[-Cpr2 Cpr2];
    Dcl=zeros(p_dim,r_dim);
    sys_cl=ss(Acl,Bcl,Ccl,Dcl);
    nsamples=tspan/dx(n_delay);
    t2=linspace(0,tspan,nsamples);
    u=repmat(sinc((t2-tau(n_delay))).',1,r_dim);
[ys,ts,xs]=lsim(sys_cl,u,t2);
dt=t2(2)-t2(1);
ntemp=0;
ntemp2=0;

for t3=1:nsamples-1
    ntemp=ntemp+u(t3,:)*u(t3,:).'*dt;
    ntemp2=ntemp2+ys(t3,:)*ys(t3,:).'*dt;
end
normu=sqrt(ntemp);
normy=sqrt(ntemp2);
disp('The closed-loop system L_2 gain for the Sinc disturbance is ')
gain_est=normy/normu
disp('This number may be slightly off due to finite time-horizon and discretization errors')
rangef1=n_dim*(N-1)+1:n_dim*N;
errors=xs(:,nstates+rangef)-xs(:,rangef);
figure
plot(ts,errors)
hold on
title('Present State Error History for sinc disturbance')
figure
hold on
plot(ts,u)
plot(ts,ys)
title('Disturbance and Regulated Output for sinc disturbance')

