function norm_est=CL_estimator_norm_pade(tau,A0,A,B,C10,C,C2,padeorder)

ncc=size(C2,1);
ndd=size(B,2);
nrr=size(C10,1);  % number of regulated outputs
D=zeros(nrr+ncc,ndd);

for i=1:length(tau)
    DelayT(i) = struct('delay',tau(i),'a',A{i},'b',0*B,'c',[0*C2;C{i}],'d',0*D);
%    DelayT(i) = struct('delay',tau(i),'a',A{i},'b',0*B,'c',[0*C2;C{i}]);
end


sysdel=delayss(A0,B,[C2;C10],D,DelayT);
sysx=pade(sysdel,padeorder);


[AT,BT,CT,DT] = ssdata(sysx);
range11=1:size(C2,1);
range22=size(C2,1)+1:(size(C2,1)+size(C10,1));
CT2=CT(range11,:);
CT1=CT(range22,:);
DT1=DT(range11,:);
DT2=DT(range22,:);
nss=size(AT,1);


gamma=sdpvar(1);               % represents the bound on the H-infinity norm of the CL system.
P=sdpvar(nss);
Z=sdpvar(nss,ncc,'full');
%W=sdpvar(nrr);

% % declare constraints
% MAT=[AT'*P+P*AT+Z*CT2+CT2'*Z'       -(P*BT+Z*DT1)              ];
% %     -(P*BT+Z*DT)'                  -gamma*eye(ndd)   zeros(nrr,ndd)';
% %     CT1                zeros(nrr,ndd)              -gamma*eye(nrr)];

 MAT=[AT'*P+P*AT+Z*CT2+CT2'*Z'       -(P*BT+Z*DT1)              CT1';
     -(P*BT+Z*DT1)'                  -gamma*eye(ndd)   zeros(nrr,ndd)';
     CT1                zeros(nrr,ndd)              -gamma*eye(nrr)];
F=[MAT<=0];
F=[F;P>=.0001*eye(nss)];

OPTIONS = sdpsettings('solver','sedumi','verbose',0);

% Solve the LMI, minimizing gamma
optimize(F,gamma,OPTIONS);
norm_est=value(gamma);