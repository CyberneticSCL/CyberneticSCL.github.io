function [prog, M, N] = sospos_mat_ker_ndelay(prog,n,d1,d2,var1,var2,I)
%
% SOSJOINTPOS_MAT_KER(prog,n,d1,d2,var1,var2,I) declares the multiplier $M(s)$ and
% kernel part $N(s,t)$ of a positive multiplier+integral operator. The
% multiplier and kernel have the form
%
% M(s) = Z(s)^T Q_1 Z(s)
% N(s,t) = Z(s)^T Q_2 Z(t)
%
% 
% where Z(x)= Z_d1(x) \otimes I_n and Z_d(x) is the vector of monomials in
% variables x of degree d1 or less. Z(x,y) = Z_{d1}(x) \otimes Z_{d2}(x)
% \otimes I_n. If the application is stability of time-delay systems, d1
% will eventually be more or less the degree of the multiplier and d2 more
% or less the degree of the kernel function.
% we recommend setting d2 = d1 to keep the polynomial degrees balanced.

% INPUTS 
%   prog: SOS program to modify.
%   n: dimension of the resulting matrix
%   d1: degree of the multiplier (sort of)
%   d2: degree of the kernel
%   var1: Single pvar corresponding to s in the description
%   var2: Single pvar corresponding to t in the description
%   I = [l u] interval of integration
%
% OUTPUT 
%   N1: subdiagonal function
%   N2: superdiagonal superdiagonal
%
% NOTES:
% Distributed with DelayTOOLS
% Compatable with MULTIPOLY and SOSTOOLS as of June 2013
% For support, contact M. Peet, Arizona State University at mpeet@asu.edu

if ~isvalid(var1) || ~isvalid(var2)
  error(['vars must be a polynomial variable']);
end

nints=length(I);

% I'm going to construct Z manually so I know where everything is
nZth=d2+1;
Z1degmat = [0:d2]';
Z1coeff = speye(nZth);
Z1varname = var1.varname;
Z1matdim = [nZth 1];
ZZZth=polynomial(Z1coeff,Z1degmat,Z1varname,Z1matdim);


% There are two configurations for the degree d2. Probably the most logical one is 
% that for TDS applications, 2d1 ends up as the degree of the multiplier and
% 2d2 as the degree of the kernel. This is the following:


% For other applications, however, we may want 2d2 to represent the
% internal variable of integration, in which case we use the following:
% 
% Z2degmat = [repmat([0:d2]',d1+1,1),vec(repmat(0:d1,d2+1,1))];
% nZthksi=length(Z2degmat);
% Z2coeff = speye(nZthksi);
% Z2varname = [var1.varname; var2.varname];
% Z2matdim = [nZthksi 1];
% ZZZthksi=polynomial(Z2coeff,Z2degmat,Z2varname,Z2matdim);

nBZ1=n*nZth;

%[prog,M]=sosposmatrvar(prog,n,2*d1,[var1]);
for k=1:nints
    [prog,M{k}]=sosposmatrvar(prog,n,2*d1,[var1]);
end
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

bZ1th=[];
for i=1:n
    bZ1th=blkdiag(bZ1th,ZZZth);
end
bZ1ksi=subs(bZ1th,var1,var2);
%size(bZ1ksi)
[prog,LLL]=sosposmatr(prog,nBZ1*nints);

for i=1:nints
    for jj=1:nints
%        i
%        jj
%        size(LLL((1+(i-1)*nBZ1):(nBZ1+(i-1)*nBZ1),(1+(jj-1)*nBZ1):(nBZ1+(jj-1)*nBZ1)))
        N{i,jj}=bZ1th.'*LLL((1+(i-1)*nBZ1):(nBZ1+(i-1)*nBZ1),(1+(jj-1)*nBZ1):(nBZ1+(jj-1)*nBZ1))*bZ1ksi;
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% [prog, Q] = sosposkernelvar(prog,n*nints,d2,[var1],[var2]);  % MMP 5/23/2013 - use new kernel subroutine to create the functions Rij
% %Z=monomials([fact*th],0:orderth);
% %[prog,VAR] = sossosvar(prog,[1]);
% %[prog] = soseq(prog,VAR)
% % Rij is the ijth block of the kernel function N, 
% n_dim=n;
% %delta(1) = -II{1}(1);
% for i=1:nints 
%     delta(i)=I{i}(2)-I{i}(1);
%     tau(i)=-I{i}(1);
% end
% tauK=-I{nints}(1);
% 
% for i=1:nints
%     for j=1:nints
%         temp=Q((i-1)*n_dim+1:i*n_dim,(j-1)*n_dim+1:j*n_dim);
%         if i==1  % case tau(0)=0
%         temp=subs(temp,var1,tauK/delta(i)*var1+0*tauK/delta(i));
%         else
%         temp=subs(temp,var1,tauK/delta(i)*var1+tau(i-1)*tauK/delta(i));
%         end
%         if j==1  % case tau(0)=0
%         temp=subs(temp,var2,tauK/delta(j)*var2+0*tauK/delta(j));
%         else
%         temp=subs(temp,var2,tauK/delta(j)*var2+tau(j-1)*tauK/delta(j));
%         end
%         N{i,j}=temp;
%     end
% end
% 


end









