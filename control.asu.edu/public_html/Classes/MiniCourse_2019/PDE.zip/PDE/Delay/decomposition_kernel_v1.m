function [Zleft,P,Zright] = decomposition_kernel_v1(R,th,ksi,dMax)
%
% decomposition_kernel_v1 decomposes the kernel R(th,ksi) as
%
%  R{i,j}(th,ksi)=Zleft(th).'*P{i,j}*Zright(ksi)
%
% where Zleft and Zright are the matrices consisting of vector-valued
% monomial bases.
% This decomposition is unique
%
%
% INPUTS 
%   R - the polynomial kernel in pvar format
%   th - The first variable in R (must match, order not important)
%   ksi - The second variable in R (must match, order not important)
%
% There must be no additional independent variables in R.
%
% OUTPUT 
%   Zleft -  matrix consisting of vector-valued
% monomial bases in dependent variable th. Dimension: (the row dimension of R) x (the row dimension
% of P)
%   Zright -  matrix consisting of vector-valued
% monomial bases in dependent variable ksi. Dimension: (the column dimension of R) x (the column
% dimension of P)
%   P - cell array of matrices of identical size
%
% NOTES:
% Distributed with DelayTOOLS
% Compatable with MULTIPOLY and SOSTOOLS as of June 2013
% For support, contact M. Peet, Arizona State University at mpeet@asu.edu
%
% Initial Coding:
% 8/29/18 - MMP  -  titled decomposition_kernel_v1




if ~iscell(R)
    error(['M must be cell arrays'])
end

[K1,K2]=size(R); % number of cells
[dim_1,dim_2]=size(R{1,1});

dm=0;
for i=1:K1
     for j=1:K2
        dR=R{i,j}.degmat;
        dmR=max(max(dR));
        dm=max([dm dmR]);
     end
end

switch nargin
    case 4
        if dm>dMax;
            error(['degree of M is greater than specified degree'])
        else
            dm=dMax;
        end
end



ZCth=polynomial(eye(dmR+1),[0:dm]',th.varname,[dm+1 1]); % common vector of monomials
ZCksi=polynomial(eye(dmR+1),[0:dm]',ksi.varname,[dm+1 1]); % common vector of monomials

bigZCth=[];
for i=1:dim_1
    bigZCth=blkdiag(bigZCth,ZCth);
end

bigZCksi=[];
for i=1:dim_2
    bigZCksi=blkdiag(bigZCksi,ZCksi);
end

for ii=1:K1
    for jj=1:K2
        for i=1:dim_1
            for j=1:dim_2 % address the decomposition of each element separately and place in the larger matrix Q
                dmij=R{ii,jj}(i,j).degmat;
                cfij=R{ii,jj}(i,j).coeff;
                CN=zeros(dm+1,dm+1);
                if strcmp(th.varname,R{ii,jj}(i,j).varname(1)) % we don't know the order the variables are listed internally
                    varR1=1;
                    varR2=2;
                elseif strcmp(th.varname,R{ii,jj}(i,j).varname(2))
                    varR1=2;
                    varR2=1;
                else
                    disp('ERROR: variable th does not appear in R')
                end
                
                for k=1:length(cfij) % take each coefficient and put it in its proper place in CN, which is then assembled into CbigN
                    CN(full(dmij(k,varR1))+1,full(dmij(k,varR2))+1)=cfij(k);
                end
                GG{ii,jj}(((dmR+1)*(i-1)+1):((dmR+1)*i),((dmR+1)*(j-1)+1):((dmR+1)*j))=CN;
            end
        end
    end
end



%bigZCth.'*GG{1,1}*bigZCksi-R{1,1} % this should be zero
P=GG;
Zleft=bigZCth;
Zright=bigZCksi;







