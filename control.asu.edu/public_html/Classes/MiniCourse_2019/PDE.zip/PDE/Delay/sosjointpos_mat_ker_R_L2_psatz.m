function [prog, M, N] = sosjointpos_mat_ker_R_L2_psatz(prog,n1,n2,d1,d2,var1,var2,I,override,diag)
%
% SOSJOINTPOS_MAT_KER_NDELAY_R_L2_PSATZ(prog,n,d1,d2,var1,var2,I) declares the multiplier $M(s)$ and
% kernel part $N(s,t)$ of a positive multiplier+integral operator. The
% multiplier and kernel have the form
%
% M(s) = [ Q11 1/tau \int_I g(s)ds        g(s)*Q12*Z(s) + Q13 \int_I g(\eta) Z(eta,s)d eta)]
%          [ *^T        g(s) Z(s)^T Q_22 Z(s)
% N(s,t) = g(s)*Z(s)^T Q_{23} Z(s,t) + g(t)Z(t,s)^T Q_{32} Z(t) + \int_{I} g(\eta) Z(eta,s)^T Q_{33} Z(eta,t) dss
%
% Q = [ Q_{11}  Q_{12} Q_{13}]
%     [ Q_{21}  Q_{22} Q_{23}] >0
%     [ Q_{31}  Q_{32} Q_{33}]
%
%
% where Z(x)= Z_d1(x) \otimes I_n and Z_d(x) is the vector of monomials in
% variables x of degree d1 or less. Z(x,y) = Z_{d1}(x) \otimes Z_{d2}(x)
% \otimes I_n. If the application is stability of time-delay systems, d1
% will eventually be more or less the degree of the multiplier and d2 more
% or less the degree of the kernel function.
% we recommend setting d2 = d1 to keep the polynomial degrees balanced.

% Based on the third representation in the notes entitled:
% notes_indexed_RL2_10_20_2017.pdf

% If the override=1, then Z_3=0 and we have
% M(s) = [ Q11 1/tau \int_I g(s)ds        g(s)*Q12*Z(s)]
%          [ *^T        g(s) Z(s)^T Q_22 Z(s)
% N(s,t) = 0

% INPUTS
%   prog: SOS program to modify.
%   n: dimension of the resulting matrix
%   d1: degree of the multiplier (sort of)
%   d2: degree of the kernel
%   var1: Single pvar corresponding to s in the description
%   var2: Single pvar corresponding to t in the description
%   I = single interval of integration
%   diag = if we want M22 block diagonal, this is the size of desired
%   blocks in Q22. n2 must be divisible by this number.
%
% OUTPUT
%   M: A functions of var1 valid on the interval I
%   N: A kernel valid on the interval I in variable
%   var1 and interval I in variable var2
%
% NOTES:
% Distributed with DelayTOOLS
% Compatable with MULTIPOLY and SOSTOOLS as of June 2013
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Mod history:
% created 4/20/2018             sosjointpos_mat_ker_R_L2_psatz_slim

% For support, contact M. Peet, Arizona State University at mpeet@asu.edu

if ~isvalid(var1) || ~isvalid(var2)
    error(['vars must be a polynomial variable']);
end

switch nargin
    case 7
        error(['Not enough inputs!'])
    case 8
        diag=0;
        override=0;
    case 9
        diag=0;
    case 10
        if ~(floor(n2/diag)==n2/diag)
            error(['n2/diag must be an integer']);
        end
end

n=n2;



ss=polynomial(1,1,{'ss'},[1 1]);

gth=(var1-I(1))*(I(2)-var1);
gksi=(var2-I(1))*(I(2)-var2);
geta=(ss-I(1))*(I(2)-ss);

tau=I(2)-I(1);
% These indices allow for parfor implementation of multi-indexed elements




% I'm going to construct Z manually so I know where everything is
nZth=d1+1;
Z1degmat = [0:d1]';
Z1coeff = speye(nZth);
Z1varname = var1.varname;
Z1matdim = [nZth 1];
Z1th=polynomial(Z1coeff,Z1degmat,Z1varname,Z1matdim);


% There are two configurations for the degree d2. Probably the most logical one is
% that for TDS applications, 2d1 ends up as the degree of the multiplier and
% 2d2 as the degree of the kernel. This is the following:
%Z2degmat = [repmat([0:d2]',d1+1,1),vec(repmat(0:d1,d2+1,1))];
Z2degmat = [repmat([0:d1]',d2+1,1),vec(repmat(0:d2,d1+1,1))];
nZthksi=length(Z2degmat);
Z2coeff = speye(nZthksi);
Z2varname = [var1.varname; var2.varname];
Z2matdim = [nZthksi 1];
Z2thksi=polynomial(Z2coeff,Z2degmat,Z2varname,Z2matdim);

% For other applications, however, we may want 2d2 to represent the
% internal variable of integration, in which case we use the following:
%
% Z2degmat = [repmat([0:d2]',d1+1,1),vec(repmat(0:d1,d2+1,1))];
% % Z2degmat = [repmat([0:d2]',d1+1,1),vec(repmat(0:d1,d2+1,1))];
% nZthksi=length(Z2degmat);
% Z2coeff = speye(nZthksi);
% Z2varname = [var1.varname; var2.varname];
% Z2matdim = [nZthksi 1];
% ZZZthksi=polynomial(Z2coeff,Z2degmat,Z2varname,Z2matdim);


nBZ1=n2*nZth;
nBZ2=n2*nZthksi;


bZ1th=[];
for i=1:n2
    bZ1th=blkdiag(bZ1th,Z1th);
end

if override~=1
    
    bZ2thksi=[];
    for i=1:n2
        bZ2thksi=blkdiag(bZ2thksi,Z2thksi);
    end
    
    
%     % Sparsity Structure - none
%     sp11=ones(n1,n1);
%     sp12=ones(n1,nBZ1);
%     sp13=ones(n1,nBZ2);
%     sp22=ones(nBZ1,nBZ1);
%     sp23=ones(nBZ1,nBZ2);
%     sp33=ones(nBZ2,nBZ2);
%     sp_pat=[sp11 sp12 sp13; sp12.' sp22 sp23; sp13.' sp23.' sp33];
%     
%     [prog,LLL]=sosposmatr_struct(prog,size(sp_pat,2),sp_pat);
    
    [prog,LLL]=sosposmatr(prog,n1+nBZ1+nBZ2);
    % Construct Q11, Q12, Q13, ....
    Q11=LLL(1:n1,1:n1);
    Q12=LLL(1:n1,(n1+1):(n1+nBZ1));
    Q13=LLL(1:n1,(n1+nBZ1+1):(n1+nBZ1+nBZ2));
    Q21=Q12.';
    Q22=LLL((n1+1):(n1+nBZ1),(n1+1):(n1+nBZ1));
    if diag~=0  % if the diagonal override is used, make $Q22$ block diagonal
        Q22temp=Q22; %this is of dimension nBZ1=n2*nZth=K*diag*nZth
        K=n2/diag; % this is the number of blocks
        for i=1:K
            irange=(diag*(i-1)*nZth+1):(i*diag*nZth);    % n2/
            Q22temp(irange,irange)=zeros(diag*nZth);
         end
        prog=sosmateq(prog,Q22temp);
    end
    Q23=LLL((n1+1):(n1+nBZ1),(n1+nBZ1+1):(n1+nBZ1+nBZ2));
    Q31=Q13.';
    Q32=Q23.';
    Q33=LLL((n1+nBZ1+1):(n1+nBZ1+nBZ2),(n1+nBZ1+1):(n1+nBZ1+nBZ2));
    
    
    M11=Q11*int(gth,var1,I(1),I(2))/tau;
    %   M12{i}=Q12i*bZ1th;  % Inefficient multiplication!!!!!!!!!!!!!!
    M12=Q12*bZ1th*gth+Q13*int(gksi*var_swap(bZ2thksi,var1,var2),var2,I(1),I(2)); % this should be optimized for speed!!!.
    
    % we construct M=g(s)*Z(s)^T*Q22*Z(s)
    Ltemp=Q22;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    avarname=[Ltemp.varname; Z1varname]; % This is the list of variable names (coeff_xx) which appear in LLL_11_{i,i}, but appended with s
    % The coefficients of LLL_11_{i,i} are all ones, but which appear in
    % the vectorized form of the canonical basis for matrices.
    %
    % For the next part, we just need the degmat part of the block-diagonal
    % monomial matrix
    
    bZdegmat=repmat(Z1degmat,n,1);
    
    [PIlist, PJlist]=find(Ltemp.coefficient); % This is the list of the position indexes of the terms in P (i.e. LLL_11_{i,i}),
    % but PIlist and Pjlist will be relatively short. They should have n^2
    % entries, whereas Ltemp.coefficient is an n^2 x n^2 matrix
    [PIlist2,ttt]=unique(PIlist); % sorts the list and removes duplicate entries. Not clear why needed... perhaps just to get ttt?
    % ttt gives the the original position of each PIlist2 in the original vector PIlist
    PJlist2=PJlist(ttt,:); % This returns the j positions of each element in the PIlist
    
    [Prowu,Pcolu] = ind2sub([n*nZth n*nZth],PJlist2); % this returns the matrix locations for every term in P
    adegmat = [Ltemp.degmat(PIlist2,:) bZdegmat(Prowu,:)+bZdegmat(Pcolu,:)];
    
    
    % but now we have to modify the coefficient matrix. We can group this by
    % blocks. For a 2x2 matrix, all the coefficients from block 1 will be [1 0 0 0], all the
    % coefficients from block 2 will be [0 1 0 0], all the coefficients from
    % block 3 will be [0 0 0 1],
    
    % Positions in Pjlist from 1:nZ get reassigned to 1, nZ+1:2nZ -> 2, etc
    [row,col] = ind2sub([n*nZth n*nZth],PJlist);
    newrow=ceil(row/nZth);
    newcol=ceil(col/nZth);
    newidx=sub2ind([n n],newrow, newcol);
    
    coeff=sparse(PIlist,newidx,1);
    amatdim=[n n];
    M22=polynomial(coeff,adegmat,avarname,amatdim);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %    M{i}=bZ1th'*LLL(((i-1)*nBZ1+1):i*nBZ1,((i-1)*nBZ1+1):i*nBZ1)*bZ1th;
    M=[M11 M12;M12.' M22*gth];
    
    
    
    
    % Kernal Part I
    % This is the Z(s)^T Q23 Z(s,t) term
    Ltemp=Q23;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    avarname=[Ltemp.varname; Z2varname ];
    % For the next part, we just need the degmat part of the block-diagonal
    % monomial matrix
    if strcmp(var1.varname{1},Z2varname{1}) % var1 is in the first position
        bZdegmat1=repmat([Z1degmat zeros(nZth,1)],n,1);
    else
        bZdegmat1=repmat([zeros(nZth,1) Z1degmat],n,1);
    end
    bZdegmat2=repmat(Z2degmat,n,1);
    
    [PIlist, PJlist]=find(Ltemp.coefficient); % This is the list of terms in P, but PIlist and Pjlist will be relatively short.
    [Prowu,Pcolu] = ind2sub([n*nZth n*nZthksi],PJlist); % this returns the matrix locations for every term in P
    adegmat = [Ltemp.degmat(PIlist,:) bZdegmat1(Prowu,:)+bZdegmat2(Pcolu,:)];
    %
    % but now we have to modify the coefficient matrix. We can group this by
    % blocks. For a 2x2 matrix, all the coefficients from block 1 will be [1 0 0 0], all the
    % coefficients from block 2 will be [0 1 0 0], all the coefficients from
    % block 3 will be [0 0 0 1],
    
    % Positions in Pjlist from 1:nZ get reassigned to 1, nZ+1:2nZ -> 2, etc
    [row,col] = ind2sub([n*nZth n*nZthksi],PJlist);
    newrow=ceil(row/nZth);
    newcol=ceil(col/nZthksi);
    newidx=sub2ind([n n],newrow, newcol);%(newcol-1)*n+newrow;
    
    nPIlist=(1:length(PIlist))';
    coeff=sparse(nPIlist,newidx,1);
    amatdim=[n n];
    A0=polynomial(coeff,adegmat,avarname,amatdim);
    A=gth*A0;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %        clear Ltemp
    %       A=bZ1th.'*Q23*bZ2thksi;
    
    
    
    % Kernal Part II
    % This is the Z(t,s)^T Q21 Z(t) term
    % for i=1:nints
    %     for j=1:nints
    %         B{i,j} = subs(subs(subs(A{j,i}.',var1,ss),var2,var1),ss,var2);
    %     end
    % end
    B = var_swap(A.',var1,var2);
    
    
    % LLL4=LLL(nints*nBZ1+1:end,1:nints*nBZ1);
    % parfor ij=1:niter
    %         i=Ic(ij);j=Jc(ij);
    %         irange=((i-1)*nBZ2+1+(j-1)*nBZ2*nints):(i*nBZ2+(j-1)*nBZ2*nints); % for every increase in i, we shift by an entire set of intervals
    %         jrange=((j-1)*nBZ1+1):j*nBZ1; % standard range
    % %        LLL2(irange,jrange)
    %         B{ij}=var_swap(bZ2thksi,var1,var2).'*LLL4(irange,jrange)*subs(bZ1th,var1,var2);
    % %        A{1,1}(1,1)
    % end
    
    % Kernal Part III
    % This is the int Z(om,s)^T Q22 Z(om,t) term
    % bZ2omksi=subs(bZ2thksi,var1,ss);
    % bZ2omth=subs(bZ2omksi,var2,var1);
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    Ltemp=Q33;
    avarname=[Ltemp.varname; var1.varname; var2.varname; ss.varname{1}];
    %assignin('base',['LLL3',int2str(i),int2str(j),int2str(k)],Ltemp)
    if strcmp(var1.varname{1},Z2varname{1}) % th is in the first position
        bZdegmat1=repmat([Z2degmat(:,2) zeros(nZthksi,1)  Z2degmat(:,1)],n,1); %bZomth
        bZdegmat2=repmat([zeros(nZthksi,1) Z2degmat(:,2)  Z2degmat(:,1)],n,1); %bZomksi
    else
        bZdegmat1=repmat([Z2degmat(:,1) zeros(nZthksi,1)  Z2degmat(:,2)],n,1); %bZomth
        bZdegmat2=repmat([zeros(nZthksi,1) Z2degmat(:,1)  Z2degmat(:,2)],n,1); %bZomksi
    end
    
    [PIlist, PJlist]=find(Ltemp.coefficient); % This is the list of terms in P, but PIlist and Pjlist will be relatively short.
    [Prowu,Pcolu] = ind2sub([n*nZthksi n*nZthksi],PJlist); % this returns the matrix locations for every term in P
    adegmat = [Ltemp.degmat(PIlist,:) bZdegmat1(Prowu,:)+bZdegmat2(Pcolu,:)];
    % but now we have to modify the coefficient matrix. We can group this by
    % blocks. For a 2x2 matrix, all the coefficients from block 1 will be [1 0 0 0], all the
    % coefficients from block 2 will be [0 1 0 0], all the coefficients from
    % block 3 will be [0 0 0 1],
    
    newrow=ceil(Prowu/nZthksi);
    newcol=ceil(Pcolu/nZthksi);
    
    newidx=sub2ind([n n],newrow, newcol);%(newcol-1)*n+newrow;
    nPIlist=(1:length(PIlist))';
    coeff=sparse(nPIlist,newidx,1);
    amatdim=[n n];
    %             size(coeff)
    %             size(adegmat)
    %             size(avarname)
    %             Ltemp
    CA=polynomial(coeff,adegmat,avarname,amatdim);
    %            clear Ltemp
    
    N=A+B+int(CA*geta,ss,I(1),I(2));
else
    
    
    % Sparsity Structure - none
    sp11=ones(n1,n1);
    sp12=ones(n1,nBZ1);
    sp22=ones(nBZ1,nBZ1);
    %size(sp3)
    sp_pat=[sp11 sp12; sp12.' sp22];
    
    %sp_pat=[sp1 sp2;sp2' sp3];
    [prog,LLL]=sosposmatr_struct(prog,size(sp_pat,2),sp_pat);
    %[prog,LLL]=sosposmatr(prog,nBZ1*nints+nBZ2*nints^2);
    
    % Construct Q11, Q12, Q13
    Q11=LLL(1:n1,1:n1);
    Q12=LLL(1:n1,(n1+1):(n1+nBZ1));
    Q21=Q12.';
    Q22=LLL((n1+1):(n1+nBZ1),(n1+1):(n1+nBZ1));
    if diag~=0  % if the diagonal override is used, make $Q22$ block diagonal
        Q22temp=Q22; %this is of dimension nBZ1=n2*nZth=K*diag*nZth
        K=n2/diag; % this is the number of blocks
        for i=1:K
            irange=(diag*(i-1)*nZth+1):(i*diag*nZth);    % n2/
            Q22temp(irange,irange)=zeros(diag*nZth);
         end
        prog=sosmateq(prog,Q22temp);
    end
    
    M11=Q11*int(gth,var1,I(1),I(2))/tau;
    %   M12{i}=Q12i*bZ1th;  % Inefficient multiplication!!!!!!!!!!!!!!
    M12=Q12*bZ1th*gth; % this should be optimized for speed!!!.
    
    % we construct M=g(s)*Z(s)^T*Q22*Z(s)
    Ltemp=Q22;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    avarname=[Ltemp.varname; Z1varname]; % This is the list of variable names (coeff_xx) which appear in LLL_11_{i,i}, but appended with s
    % The coefficients of LLL_11_{i,i} are all ones, but which appear in
    % the vectorized form of the canonical basis for matrices.
    %
    % For the next part, we just need the degmat part of the block-diagonal
    % monomial matrix
    
    bZdegmat=repmat(Z1degmat,n,1);
    
    [PIlist, PJlist]=find(Ltemp.coefficient); % This is the list of the position indexes of the terms in P (i.e. LLL_11_{i,i}),
    % but PIlist and Pjlist will be relatively short. They should have n^2
    % entries, whereas Ltemp.coefficient is an n^2 x n^2 matrix
    [PIlist2,ttt]=unique(PIlist); % sorts the list and removes duplicate entries. Not clear why needed... perhaps just to get ttt?
    % ttt gives the the original position of each PIlist2 in the original vector PIlist
    PJlist2=PJlist(ttt,:); % This returns the j positions of each element in the PIlist
    
    [Prowu,Pcolu] = ind2sub([n*nZth n*nZth],PJlist2); % this returns the matrix locations for every term in P
    adegmat = [Ltemp.degmat(PIlist2,:) bZdegmat(Prowu,:)+bZdegmat(Pcolu,:)];
    
    
    % but now we have to modify the coefficient matrix. We can group this by
    % blocks. For a 2x2 matrix, all the coefficients from block 1 will be [1 0 0 0], all the
    % coefficients from block 2 will be [0 1 0 0], all the coefficients from
    % block 3 will be [0 0 0 1],
    
    % Positions in Pjlist from 1:nZ get reassigned to 1, nZ+1:2nZ -> 2, etc
    [row,col] = ind2sub([n*nZth n*nZth],PJlist);
    newrow=ceil(row/nZth);
    newcol=ceil(col/nZth);
    newidx=sub2ind([n n],newrow, newcol);
    
    coeff=sparse(PIlist,newidx,1);
    amatdim=[n n];
    M22=polynomial(coeff,adegmat,avarname,amatdim);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %    M{i}=bZ1th'*LLL(((i-1)*nBZ1+1):i*nBZ1,((i-1)*nBZ1+1):i*nBZ1)*bZ1th;
    M=[M11 M12;M12.' M22*gth];
    
    N=polynomial(zeros(n,n));
    
end
% M(s) = [ Q11 1/tau \int_I g(s)ds        g(s)*Q12*Z(s) + Q13 \int_I g(\eta) Z(eta,s)d eta)]
%          [ *^T        g(s) Z(s)^T Q_22 Z(s)
% N(s,t) = g(s)*Z(s)^T Q_{23} Z(s,t) + g(t)Z(t,s)^T Q_{32} Z(t) + \int_{I} g(\eta) Z(eta,s)^T Q_{33} Z(eta,t) dss
%

