function [P,Zright] = decomposition_multiplier_v1(M,left,dMax)

%
% decomposition_multiplier_v1 decomposes the matrix-valued function M(th) as
%
%  M(th)=P*Zright(th)
%
% where Zright are the matrices consisting of vector-valued
% monomial bases.
% This decomposition is unique
%
%
% INPUTS
%   M - cell of polynomial kernels in pvar format
%   left - set left=1 if a left-representation is desired
%   dMax - if a representation using a specified degree for Zright is
%   desired.
%
% There must be no additional independent variables in R.
%
% OUTPUT
%   Zright -  matrix consisting of vector-valued
% monomial bases in dependent variable th. Dimension: (the column dimension of M) x (the column
% dimension of P)
%
%
% NOTES:
% Distributed with DelayTOOLS
% Compatable with MULTIPOLY and SOSTOOLS as of June 2013
% For support, contact M. Peet, Arizona State University at mpeet@asu.edu
%
% Initial Coding:
% 8/29/18 - MMP  -  titled decomposition_multiplier_v1

if ~iscell(M)
    error(['M must be cell arrays'])
end

if nargin>1
    if left==1
          M = cellfun(@transpose,M,'UniformOutput',false);
    end
end

[K1,K2]=size(M); % number of cells

dm=0;
for i=1:K1
    for j=1:K2
        dM=M{i,j}.degmat;
        dmM=max(max(dM));
        dm=max([dm dmM]);
        %     for j=1:K
        %         dR{i,j}=NR{i,j}.degmat;
        %         dmR{i,j}=max(max(dR{i,j}));
        %         dm=max([dm dmR{i,j}]);
        %     end
    end
end

switch nargin
    case 3
        if dm>dMax;
            error(['degree of M is greater than specified degree'])
        else
            dm=dMax;
        end
end



[dim_1,dim_2]=size(M{1,1});


var1=M{1,1}.Varname(1);

ZCth=polynomial(eye(dm+1),[0:dm]',var1,[dm+1 1]); % common vector of monomials
bigZCth=[];
for i=1:dim_2
    bigZCth=blkdiag(bigZCth,ZCth);
end

% Now use bigZCth to find H_i!
for ii=1:K1
    for jj=1:K2
        nZ=length(ZCth);
        for i=1:dim_1
            for j=1:dim_2
                [CQij,Ztemp,etemp] = poly2basis(M{ii,jj}(i,j),ZCth); % examine each element of NQ
                bigC{ii,jj}(i,(nZ*(j-1)+1):(nZ*j))=CQij.';
            end
        end
        H{ii,jj}=bigC{ii,jj};
    end
end
P=H;
Zright=bigZCth;

if nargin>1
    if left==1
          P = cellfun(@transpose,P,'UniformOutput',false);
    end
end

%H{1}*bigZCth-M{1}  %uncomment to verify the representation (should be 0)






