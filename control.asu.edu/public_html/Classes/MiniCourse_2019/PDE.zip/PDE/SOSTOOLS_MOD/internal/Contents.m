% SOSTOOLS -- Sum of Squares Toolbox, internal files
% Version 3.01 
% 1st June 2016.