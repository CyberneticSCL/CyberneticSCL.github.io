% SOSTOOLS -- Sum of Squares Toolbox, demo files
% Version 1.00 
% 11 April 2002.
%
%    SOSDEMO1    --- Sum of squares test.
%    SOSDEMO2    --- Lyapunov function search.
%    SOSDEMO3    --- Bound on global extremum.
%    SOSDEMO4    --- Matrix copositivity.
%    SOSDEMO5    --- Upper bound for the structured singular value mu.
%    SOSDEMO6    --- MAX CUT.
%    SOSDEMO7    --- Chebyshev polynomials.
%    SOSDEMO8    --- Bound in probability.
% 

