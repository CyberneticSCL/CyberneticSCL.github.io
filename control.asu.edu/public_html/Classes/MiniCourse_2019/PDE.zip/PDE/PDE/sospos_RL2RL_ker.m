function [prog,Pv] = sospos_RL2RL_ker(prog,n1,n2,d1,d2,var1,var2,I)
% SOSJOINTPOS_MAT_KER_SEMISEP_PQR(prog,n1,n2,d1,d2,var1,var2,I) declares 
% the positive operator from R_n1 x L2_n2 -> R_n1 x L2_n2. 
% P = T11
% Q(s) = int( T12 Z(th,s) dth, s, L) + int( T13 Z(th,s) dth, 0, s)
% R1(s,th) = int(Z(b,s) T22 Z(b,th) db, s, L) + int(Z(b,s) T32 Z(b,th) db, th, s) + 
%            int(Z(b,s) T33 Z(b,th) db, 0, th)
% R2(s,th) = R1(th,s)'
% T = [ T_{11}  T_{12} T_{13}]
%     [ T_{21}  T_{22} T_{23}] >0
%     [ T_{31}  T_{32} T_{33}]
% 
% where Z(x)= Z_d1(x) \otimes I_n and Z_d(x) is the vector of monomials in
% variables x of degree d1 or less. Z(x,y) = Z_{d1}(x) \otimes Z_{d2}(y)
% \otimes I_n. 
%
% INPUTS 
%   prog: SOS program to modify.
%   n1: dimension of real part
%   n2: dimension of L2 part
%   d1: degree of the multiplier (sort of)
%   d2: degree of the kernel
%   var1: Single pvar corresponding to s in the description
%   var2: Single pvar corresponding to t in the description
%   I = [l u] interval of integration
%
% OUTPUT 
%   P: 
%   Q: 
%   R1:
%   R2:

if ~isvalid(var1) || ~isvalid(var2)
  error(['vars must be a polynomial variable']);
end
dum=polynomial(1,1,{'ss'},[1 1]);

% Constructing Z1 and Z2
nZth=d1+1;
Z1degmat = [0:d1]';
Z1coeff = speye(nZth);
Z1varname = var1.varname;
Z1matdim = [nZth 1];
Zs=polynomial(Z1coeff,Z1degmat,Z1varname,Z1matdim);


% There are two configurations for the degree d2. Probably the most logical one is 
% that for TDS applications, 2d1 ends up as the degree of the multiplier and
% 2d2 as the degree of the kernel. This is the following:

Z2degmat = [repmat([0:d1]',d2+1,1),vec(repmat(0:d2,d1+1,1))];
nZthksi=length(Z2degmat);
Z2coeff = speye(nZthksi);
Z2varname = [var1.varname; var2.varname];
Z2matdim = [nZthksi 1];
Zsth=polynomial(Z2coeff,Z2degmat,Z2varname,Z2matdim);

% For other applications, however, we may want 2d2 to represent the
% internal variable of integration, in which case we use the following:
% 
% Z2degmat = [repmat([0:d2]',d1+1,1),vec(repmat(0:d1,d2+1,1))];
% nZthksi=length(Z2degmat);
% Z2coeff = speye(nZthksi);
% Z2varname = [var1.varname; var2.varname];
% Z2matdim = [nZthksi 1];
% ZZZthksi=polynomial(Z2coeff,Z2degmat,Z2varname,Z2matdim);


nBZ1=n2*nZth;
nBZ2=n2*nZthksi;
[prog,LLL]=sosposmatr(prog,n1+2*nBZ2);


% Lets start by just assuming LLL has been partitioned
% In this case, things are more or less a repeat of the positive matrix
% variable case in sosposmatrvar.m with P replaced by LLL1 and Z with ZZZth
% Note, however that because this rearranges the order of the elements of
% ZZZth, we must alter all the manipulations or the result will be invalid.
ind1=1:n1; ind2=(n1+1):(n1+nBZ2);
ind3=(n1+nBZ2+1):(n1+2*nBZ2);
Q11=LLL(ind1,ind1);
Q12=LLL(ind1,ind2);
Q13=LLL(ind1,ind3);
Q22=LLL(ind2,ind2);
Q23=LLL(ind2,ind3);
Q33=LLL(ind3,ind3);
Q21=Q12.';Q31=Q13.';Q32=Q23.';
%%%%%%%%%%%%%%%%%%%%%%%%%
pvar dumbeta;
% Zs = repmat(Zs,1,n2); Zsth = repmat(Zsth,1,n2);
Zs1=[]; Zsth1=[];
for i=1:length(Zs)
    Zs1 = [Zs1; Zs(i)*eye(n2)];
end
for i=1:length(Zsth)
    Zsth1 = [Zsth1; Zsth(i)*eye(n2)];
end
Zs = Zs1; Zsth= Zsth1;
Zth = subs_p(Zs,var1,var2);
Zths = var_swap(Zsth,var1,var2);
Zbth = subs_p(Zsth,var1,dumbeta);
Zbs = subs_p(Zbth,var2,var1);
% Construct P
P=Q11;
% Construct Q
Q=int(Q12*Zths,var2,var1,I(2))+int(Q13*Zths,var2,I(1),var1);
% Construct R1 and R2
Ra=[];
for i=1:length(Q22)
Ra = [Ra; Q22(i,:)*Zbth(:,:)];
end
R11 = int(Zbs'*Ra,dumbeta,var1,I(2)); 
Ra=[];
for i=1:length(Q22)
Ra = [Ra; Q32(i,:)*Zbth(:,:)];
end
R12 = int(Zbs'*Ra,dumbeta,var2,var1);
Ra=[];
for i=1:length(Q22)
Ra = [Ra; Q33(i,:)*Zbth(:,:)];
end
R13 = int(Zbs'*Ra,dumbeta,I(1),var2);
R1 = R11+R12+R13;
R2 = var_swap(R1,var1,var2).';

Pv.P = P;
Pv.Q1 = Q; Pv.Q2 = Q'; Pv.R.R1 = R1; Pv.R.R2 = R2;
Pv.dim = [n1 n1; n2 n2];
end