np = n1+n2+n3;


T = [eye(n2) zeros(n2,n3) zeros(n2,n3);
     eye(n2) zeros(n2,n3) zeros(n2,n3);
     zeros(n3,n2) eye(n3) zeros(n3);
     zeros(n3,n2) eye(n3) (b-a)*eye(n3);
     zeros(n3,n2) zeros(n3) eye(n3);
     zeros(n3,n2) zeros(n3) eye(n3)];
Q = [zeros(n2,n1) zeros(n2) zeros(n2,n3);
     zeros(n2,n1) eye(n2) zeros(n2,n3);
     zeros(n3,n1) zeros(n3,n2) zeros(n3);
     zeros(n3,n1) zeros(n3,n2) (b-theta)*eye(n3);
     zeros(n3,n1) zeros(n3,n2) zeros(n3);
     zeros(n3,n1) zeros(n3,n2) eye(n3)];
K = [zeros(n1,n2) zeros(n1,n3) zeros(n1,n3);
     eye(n2) zeros(n2,n3) zeros(n2,n3);
     zeros(n3,n2) eye(n3) (s-a)*eye(n3)];
L0 = [eye(n1) zeros(n1,n2) zeros(n1,n3);
     zeros(n2,n1) zeros(n2) zeros(n2,n3);
     zeros(n3,n1) zeros(n3,n2) zeros(n3)];
L1 = [zeros(n1) zeros(n1,n2) zeros(n1,n3);
     zeros(n2,n1) eye(n2) zeros(n2,n3);
     zeros(n3,n1) zeros(n3,n2) (s-theta)*eye(n3)];
V = [zeros(n2,n2) zeros(n2,n3) zeros(n2,n3);
     zeros(n3,n2) zeros(n3,n3) eye(n3)];
F0 = [zeros(n2,n1) eye(n2) zeros(n2,n3);
      zeros(n3,n1) zeros(n3,n2) zeros(n3)];
F1 = [zeros(n2,n1) zeros(n2) zeros(n2,n3);
      zeros(n3,n1) zeros(n3,n2) eye(n3)];


%--------------------------------------------------------------------------
disp('Converting all states to fundamental state');
% H maps [z x1 x2s x3ss] to [z x1 x2 x3] 
H.P = eye(no); H.Q1 = zeros(no,np); H.Q2 = K*inv(B*T)*B1;
H.R.R0 = L0;
H.R.R1 = L1 -K*inv(B*T)*B*Q; H.R.R2 = -K*inv(B*T)*B*Q;
H.dim = [no no; np np];

% H2 maps [z x1 x2s x3ss] to [z x2s x3s]
H2.P = eye(no); H2.Q1 = zeros(no,n2+n3); 
H2.Q2 = V*inv(B*T)*B1;
H2.R.R0 = F0; 
H2.R.R1 = F1 - V*inv(B*T)*B*Q; H2.R.R2 = - V*inv(B*T)*B*Q;
H2.dim = [no no; n2+n3 n2+n3];

% convert operator E to fundamental state operator Ef
E31 = -E1*T*inv(B*T)*B*Q+E1*Q;
Pea1.Q1 = subs(Ea,s,theta); 
Pea1.dim = [no 0; 0 np];
Pea2.R.R0=H.R.R0; Pea2.R.R1=H.R.R1; Pea2.R.R2 = H.R.R2;
Pea2.dim = [0 0; np np];
Peb1.Q1 = subs(Eb,s,theta);
Peb1.dim = [no 0; 0 n2+n3];
Peb2.R.R0=H2.R.R0; Peb2.R.R1=H2.R.R1; Peb2.R.R2 = H2.R.R2;
Peb2.dim = [0 0; n2+n3 np];
E32 = compose_p(Pea1,Pea2,s,theta,X);
E33 = compose_p(Peb1,Peb2,s,theta,X);
E3 = E31+E32.Q1+E33.Q1;
E3s = subs(E3,theta,s);
E4 = [E1*T+int(Ea*K,s,a,b)+int(Eb*K,s,a,b)]*inv(B*T)*B1;


%Assemble A operator, that is get Af from A, Ai, Ef and E
PA.P = A+E4; 
PA.Q1 = E3s; 
PA.Q2 = E+(A0*K+A1*V)*inv(B*T)*B1;
PA.R.R0 = A0*H.R.R0+A1*H2.R.R0 + [zeros(n1) zeros(n2) A2]; 
PA.R.R1 = A0*H.R.R1+A1*H2.R.R1 ; 
PA.R.R2 = A0*H.R.R2+A1*H2.R.R2;
PA.dim = [no no; np np];