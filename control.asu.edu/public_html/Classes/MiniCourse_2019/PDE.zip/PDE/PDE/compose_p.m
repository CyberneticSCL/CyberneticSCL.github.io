function [Pcomp] = compose_p(P1,P2,s,theta,I)
% This function performs takes in two operators, 
% P1:R^p x L2^q to R^m x L2^n and P2:R^m x L2^n to R^i x L2^j. 
% It returns the composition P1 o P2: R^p x L2^q to R^i x L2^j
% Version 1.0
% Date: 6/1/19
% INPUTS
% P1 and P2 are two operators with following structure and compatible inner
% dimensions
% P: operator with the matlab structure as below
% P.dim: an 2x2 array with entries [m,p]
%                                  [n,q]
% P.P: a mxp matrix
% P.Q1: a mxq matrix valued polynomial in s
% P.Q2: a nxp matrix valued polynomial in s
% P.R.R0: a nxq matrix valued poynomial in s
% P.R.R1: a nxq matrix valued poynomial in s, theta
% P.R.R2: a nxq matrix valued poynomial in s, theta
% s, theta: polynomial variables 
% I: domain
%
% Output:
% Pcomp: the matlab structure which is the equivalent operator of
% P1 o P2, where 'o' represents
% composition of operators.

if P1.dim(:,2)~=P2.dim(:,1)
    error("Composition requires inner dimensions of the operators to match");
    return
end

a=I(1);
b=I(2);

indim2 = P2.dim(:,2);
innerdim = P2.dim(:,1);
outdim1 = P1.dim(:,1);

if indim2(2)==0 
    if outdim1(2)==0 % operator is from R to R
        if innerdim(1)==0
            Pcomp.P = int(P1.Q1*P2.Q2,s,a,b);
        elseif innerdim(2) ==0
            Pcomp.P = P1.P*P2.P;
        else
            Pcomp.P = P1.P*P2.P + int(P1.Q1*P2.Q2,s,a,b);
        end
    elseif outdim1(1)==0 % operator is from R to L2
        if innerdim(1)==0
            Pcomp.Q2 = P1.R.R0*P2.Q2 + int(P1.R.R1*subs_p(P2.Q2,s,theta),theta,a,s)+...
                            int(P1.R.R2*subs_p(P2.Q2,s,theta),theta,s,b);
        elseif innerdim(2) ==0
            Pcomp.Q2 = P1.Q2*P2.P;
        else
            Pcomp.Q2 = P1.Q2*P2.P + P1.R.R0*P2.Q2 + int(P1.R.R1*subs_p(P2.Q2,s,theta),theta,a,s)+...
                            int(P1.R.R2*subs_p(P2.Q2,s,theta),theta,s,b);
        end
    else %operator is from R to RL2
        if innerdim(1)==0
            Pcomp.P = int(P1.Q1*P2.Q2,s,a,b);
            Pcomp.Q2 = P1.R.R0*P2.Q2 + int(P1.R.R1*subs_p(P2.Q2,s,theta),theta,a,s)+...
                            int(P1.R.R2*subs_p(P2.Q2,s,theta),theta,s,b);
        elseif innerdim(2) ==0
            Pcomp.P = P1.P*P2.P;
            Pcomp.Q2 = P1.Q2*P2.P;
        else
            Pcomp.P = P1.P*P2.P + int(P1.Q1*P2.Q2,s,a,b);
            Pcomp.Q2 = P1.Q2*P2.P + P1.R.R0*P2.Q2 + int(P1.R.R1*subs_p(P2.Q2,s,theta),theta,a,s)+...
                            int(P1.R.R2*subs_p(P2.Q2,s,theta),theta,s,b);
        end
    end
elseif indim2(1)==0
    if outdim1(2)==0 % operator is from L2 to R
        if innerdim(1)==0
            Pcomp.Q1 = P1.Q1*P2.R.R0+ int(var_swap(P1.Q1*P2.R.R1,s,theta),theta,s,b)+...
                    int(var_swap(P1.Q1*P2.R.R2,s,theta),theta,a,s);
        elseif innerdim(2) ==0
            Pcomp.Q1 = P1.P*P2.Q1;
        else
            Pcomp.Q1 = P1.P*P2.Q1 + P1.Q1*P2.R.R0+ int(var_swap(P1.Q1*P2.R.R1,s,theta),theta,s,b)+...
                    int(var_swap(P1.Q1*P2.R.R2,s,theta),theta,a,s);
        end   
    elseif outdim1(1)==0 % operator is from L2 to L2
        if innerdim(1)==0
            Pcomp.R = PL2L_compose(P1.R,P2.R,s,theta,I);
        elseif innerdim(2) ==0
            Pcomp.R.R1 = P1.Q2*subs_p(P2.Q1,s,theta);
            Pcomp.R.R2 = P1.Q2*subs_p(P2.Q1,s,theta);
        else
            Ptemp = PL2L_compose(P1.R,P2.R,s,theta,I);
            Pcomp.R.R0 = Ptemp.R0;
            Pcomp.R.R1 = P1.Q2*subs_p(P2.Q1,s,theta)+Ptemp.R1;
            Pcomp.R.R2 = P1.Q2*subs_p(P2.Q1,s,theta)+Ptemp.R2;
        end
    else % operator is from L2 to RL2
        if innerdim(1)==0
            Pcomp.Q1 = P1.Q1*P2.R.R0+ int(var_swap(P1.Q1*P2.R.R1,s,theta),theta,s,b)+...
                            int(var_swap(P1.Q1*P2.R.R2,s,theta),theta,a,s);
            Pcomp.R = PL2L_compose(P1.R,P2.R,s,theta,I);
        elseif innerdim(2) ==0
            Pcomp.Q1 = P1.P*P2.Q1;
            Pcomp.R.R1 = P1.Q2*subs_p(P2.Q1,s,theta);
            Pcomp.R.R2 = P1.Q2*subs_p(P2.Q1,s,theta);
        else
            Pcomp.Q1 = P1.P*P2.Q1 + P1.Q1*P2.R.R0+ int(var_swap(P1.Q1*P2.R.R1,s,theta),theta,s,b)+...
                            int(var_swap(P1.Q1*P2.R.R2,s,theta),theta,a,s);
            Ptemp = PL2L_compose(P1.R,P2.R,s,theta,I);
            Pcomp.R.R0 = Ptemp.R0;
            Pcomp.R.R1 = P1.Q2*subs_p(P2.Q1,s,theta)+Ptemp.R1;
            Pcomp.R.R2 = P1.Q2*subs_p(P2.Q1,s,theta)+Ptemp.R2;
        end
    end
elseif outdim1(2)==0 %operator is from RL2 to R
    if innerdim(1)==0
        Pcomp.P = int(P1.Q1*P2.Q2,s,a,b);
        Pcomp.Q1 = P1.Q1*P2.R.R0+ int(var_swap(P1.Q1*P2.R.R1,s,theta),theta,s,b)+...
                    int(var_swap(P1.Q1*P2.R.R2,s,theta),theta,a,s);
    elseif innerdim(2) ==0
        Pcomp.P = P1.P*P2.P;
        Pcomp.Q1 = P1.P*P2.Q1;
    else
        Pcomp.P = P1.P*P2.P + int(P1.Q1*P2.Q2,s,a,b);
        Pcomp.Q1 = P1.P*P2.Q1 + P1.Q1*P2.R.R0+ int(var_swap(P1.Q1*P2.R.R1,s,theta),theta,s,b)+...
                    int(var_swap(P1.Q1*P2.R.R2,s,theta),theta,a,s);
    end
elseif outdim1(1)==0 %operator is from RL2 to L2
    if innerdim(1)==0
        Pcomp.Q2 = P1.R.R0*P2.Q2 + int(P1.R.R1*subs_p(P2.Q2,s,theta),theta,a,s)+...
                            int(P1.R.R2*subs_p(P2.Q2,s,theta),theta,s,b);
        Pcomp.R = PL2L_compose(P1.R,P2.R,s,theta,I);
    elseif innerdim(2) ==0
        Pcomp.Q2 = P1.Q2*P2.P;
        Pcomp.R.R1 = P1.Q2*subs_p(P2.Q1,s,theta);
        Pcomp.R.R2 = P1.Q2*subs_p(P2.Q1,s,theta);
    else
        Pcomp.Q2 = P1.Q2*P2.P + P1.R.R0*P2.Q2 + int(P1.R.R1*subs_p(P2.Q2,s,theta),theta,a,s)+...
                            int(P1.R.R2*subs_p(P2.Q2,s,theta),theta,s,b);
        Ptemp = PL2L_compose(P1.R,P2.R,s,theta,I);
        Pcomp.R.R0 = Ptemp.R0;
        Pcomp.R.R1 = P1.Q2*subs_p(P2.Q1,s,theta)+Ptemp.R1;
        Pcomp.R.R2 = P1.Q2*subs_p(P2.Q1,s,theta)+Ptemp.R2;
    end
else %operator is from RL2 to RL2
    if innerdim(1)==0
        Pcomp.P = int(P1.Q1*P2.Q2,s,a,b);
        Pcomp.Q1 = P1.Q1*P2.R.R0+ int(var_swap(P1.Q1*P2.R.R1,s,theta),theta,s,b)+...
                    int(var_swap(P1.Q1*P2.R.R2,s,theta),theta,a,s);
        Pcomp.Q2 = P1.R.R0*P2.Q2 + int(P1.R.R1*subs_p(P2.Q2,s,theta),theta,a,s)+...
                            int(P1.R.R2*subs_p(P2.Q2,s,theta),theta,s,b);
        Pcomp.R = PL2L_compose(P1.R,P2.R,s,theta,I);
    elseif innerdim(2) ==0
        Pcomp.P = P1.P*P2.P;
        Pcomp.Q1 = P1.P*P2.Q1;
        Pcomp.Q2 = P1.Q2*P2.P;
        Pcomp.R.R1 = P1.Q2*subs_p(P2.Q1,s,theta);
        Pcomp.R.R2 = P1.Q2*subs_p(P2.Q1,s,theta);
    else
        Pcomp.P = P1.P*P2.P + int(P1.Q1*P2.Q2,s,a,b);
        Pcomp.Q1 = P1.P*P2.Q1 + P1.Q1*P2.R.R0+ int(var_swap(P1.Q1*P2.R.R1,s,theta),theta,s,b)+...
                    int(var_swap(P1.Q1*P2.R.R2,s,theta),theta,a,s);
        Pcomp.Q2 = P1.Q2*P2.P + P1.R.R0*P2.Q2 + int(P1.R.R1*subs_p(P2.Q2,s,theta),theta,a,s)+...
                            int(P1.R.R2*subs_p(P2.Q2,s,theta),theta,s,b);
        Ptemp = PL2L_compose(P1.R,P2.R,s,theta,I);
        Pcomp.R.R0 = Ptemp.R0;
        Pcomp.R.R1 = P1.Q2*subs_p(P2.Q1,s,theta)+Ptemp.R1;
        Pcomp.R.R2 = P1.Q2*subs_p(P2.Q1,s,theta)+Ptemp.R2;
    end
end
Pcomp.dim(:,1) = P1.dim(:,1);Pcomp.dim(:,2)= P2.dim(:,2);
end
function [Ph] = PL2L_compose(P1,P2,s,theta,I)                                 
% This function performs the composition of two operators on L2 and returns
% an equivalent operator on L2
% Version 1.0
% Date: 6/2/19
% Inputs:
% P1: Matrices and kernel of second operator
% P2: Matrices and kernel of first operator
% I: interval of integration
%
% Output:
% Returns the matrices and kernel of the operator composition 
% P_(A,B1,B2) o P_(M,N1,N2), where 'o' represents
% composition of operators.
a=I(1);
b=I(2);
A = P1.R0; B1 = P1.R1; B2 = P1.R2;
M = P2.R0; N1 = P2.R1; N2 = P2.R2;
Mh = A*M;
pvar dbeta;
B1sb = subs_p(B1,theta,dbeta); B2sb = subs_p(B2,theta,dbeta);
N1bt = subs_p(N1,s,dbeta); N2bt = subs_p(N2,s,dbeta);
N1h = A*N1+B1*subs_p(M,s,theta)+...
                               int(B1sb*N1bt,dbeta,theta,s)+...
                               int(B1sb*N2bt,dbeta,a,theta)+...
                               int(B2sb*N1bt,dbeta,s,b);
N2h = A*N2+B2*subs_p(M,s,theta)+...
                                int(B2sb*N1bt,dbeta,theta,b)+...
                                int(B2sb*N2bt,dbeta,s,theta)+...
                                int(B1sb*N2bt,dbeta,a,s);
Ph.R0 = Mh; Ph.R1 = N1h; Ph.R2 = N2h;
end