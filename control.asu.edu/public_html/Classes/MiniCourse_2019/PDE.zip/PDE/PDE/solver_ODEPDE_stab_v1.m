% date: 6/1/2019
% Test for stability of the lienar coupled ODE-PDE equation 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This program determines Hinf norm of a linear PDE which is defined
% in the format given below.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% System Definition:
% \dot x(t,s)=A0(s)[x_1(t,s)] + A1(s)[x_2s(t,s)] + A2(s)[x_3ss(t,s)]+E(s)z(t)
%                  [x_2(t,s)]        [x_3s(t,s)]
%                  [x_3(t,s)]
% \dot z(t) =  Az(t)+ E1 [x_2(a) + int_a^b Ea(s) [x_1(t,s)]  ds + int_a^b Eb(s) [x_2s(t,s)] ds
%                         x_2(b)                 [x_2(t,s)]                     [x_3s(t,s)]
%                         x_3(a)                 [x_3(t,s)]
%                         x_3(b)
%                         x_3s(a)
%                         x_3s(b)] 
%                                          
%                                          
% % Boundary conditions are of the form 
% % B[x_2(a)       
% %   x_2(b)
% %   x_3(a)
% %   x_3(b)
% %   x_3s(a)
% %   x_3s(b)]=B1 x(t)

% To test for stability, we solve the following feasibility problem
% after rewriting the system in fundamental state form which is
% \dot(x)(t,s) = (Af xf)(t,s) + E(s) z(t)
% \dot(z)(t,s)   = (Ef xf)(t,s) + A z(t)
% % % Find P, such that
% % %  P > 0
% % %  [A  Ef]*  P [I 0]  + [I 0]* P [A Ef] <=0
% % %  [E  Af]     [Q H]    [Q H]    [E Af] 
% % %  

% User Inputs:
% A      -  matrix of dimension no x no
% A0(s)  -  matrix function of s of dimension n1+n2+n3 x n1+n2+n3 
% A1(s)  -  matrix function of s of dimension n1+n2+n3 x n2+n3
% A2(s)  -  matrix function of s of dimension n1+n2+n3 x n3
% B      -  matrix of dimension n2+2*n3 x n1+n2+n3 (must be full row rank)
% E(s)   -  matrix valued polynomial of s of dimension n1+n2+n3 x no
% a,b    -  \R x \R - interval of the domain - s \in [a,b]
% E1     -  matrix of dimension no x 2n2+4n3
% Ea(s)  -  matrix valued function of s of dimension no x n1+n2+n3
% Eb(s)  -  matrix valued function of s of dimension no x n2+n3
% eppos  -  for strict positivity
% epsneg (optional) - epsneg >0 for strictness of the negativity of derivative 
%
% here 
% n1 - dimension of x_1 (can be 0)
% n2 - dimension of x_2 (can be 0)
% n3 - dimension of x_3 (can be 0)
% no - dimension of z   (cant be 0)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% internal variables:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc; clear;
% setup pvars and other internal parameters
pvar s theta;
n_order1 = 1; 
n_order2 = 1;
eppos = 1e-2;
epneg = 1e-3; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%USER INPUT START%%
% % Time delay systems
% % x_t = -x(t-tau)
no = 1; n1=0; n2 =1; n3 =0; np = n1+n2+n3;
A = 0; E = 0;
tau = pi/2 + 1e-2;
A0 = 0; A1 = 1/tau; A2 = zeros(n3);
E1 = -[1 0]; Ea = 0; Eb = 0;
B=[0 1];
B1 = [1];
a = 0; b =1;

% %%USER INPUT END%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% setup an SOS program
varlist = [s; theta];
prog = sosprogram(varlist);

% domain of spatial variables
X = [a b];

% p-compact form of the interval
g1 = (X(2)-s)*(s-X(1));


% setup the variables for lyapunov function candidate
disp('Parameterizing Positive function');
[prog, Pv] = sospos_RL2RL_matker(prog, no, np, n_order1, n_order2, s, theta, X);

% enforce strict positivity on the operator
Pv.R.R0 = Pv.R.R0+eppos*eye(np);
Pv.P = Pv.P + eppos*eye(no);

% setup H,A,Af,E,Ef operators for the system
assemble_operators_stab_odepde;

disp('Computing the derivative');
PhPA = compose_p(transpose_p(H,s,theta),compose_p(Pv,PA,s,theta,X),s,theta,X);

%Assemble the big operator
% Pheq = [A  Ef]*  P [I 0]  + [I 0]* P [A Ef] <=0
%        [E  Af]     [0 H]    [0 H]    [E Af] 

Pheq.P = PhPA.P+PhPA.P';
Pheq.Q1 = PhPA.Q1+PhPA.Q2';
Pheq.R.R0 = PhPA.R.R0+PhPA.R.R0';
Pheq.R.R1 = PhPA.R.R1+var_swap(PhPA.R.R2',s,theta);
Pheq.R.R2 = PhPA.R.R2+var_swap(PhPA.R.R1',s,theta);

%getting multiplier and kernel for derivative lyapunov function
disp('Parameterizing the negative operators');
[prog, Pe] = sospos_RL2RL_ker(prog, no, np, n_order1+3, n_order2+3, s, theta, X);
[prog, Pf] = sospos_RL2RL_ker_psatz(prog, no, np, n_order1+3, n_order2+3, s, theta, X);

% derivative negativity
% constraints
disp('Setting up the equality constraints');
prog = sosmateq(prog, Pe.P+Pf.P+Pheq.P);
prog = sosmateq(prog, Pe.Q2+Pf.Q2+Pheq.Q1');
prog = sosmateq(prog, Pe.R.R1+Pf.R.R1+Pheq.R.R1);
% prog = sosmateq(prog, Se+Sf+Pheq.S+Pheq.S'); %not needed if multiplier of H is zero

% choosing a different solver if needed
% option.solver = 'mosek'; 

%solving the sos program
prog = sossolve(prog); 

% Conclusion:
if norm(prog.solinfo.info.feasratio-1)<=.1 && ~prog.solinfo.info.numerr
    disp('The System is Stable.')
elseif norm(prog.solinfo.info.feasratio-1)<=.1 && prog.solinfo.info.numerr
    disp('The System is likely Stable. However, Double-check the precision.')
elseif prog.solinfo.info.pinf || prog.solinfo.info.dinf || norm(prog.solinfo.info.feasratio+1)<=.1
    disp('The System is Probably not Stable.')
else
    disp('Unable to definitively determine feasibility. Numerical errors dominating or at the limit of stability.')
end

