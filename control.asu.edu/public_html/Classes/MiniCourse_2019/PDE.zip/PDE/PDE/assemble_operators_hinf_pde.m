%total number of states
np = n1+n2+n3;

% setting up functions that are used repetitively 
T = [eye(n2) zeros(n2,n3) zeros(n2,n3);
     eye(n2) zeros(n2,n3) zeros(n2,n3);
     zeros(n3,n2) eye(n3) zeros(n3);
     zeros(n3,n2) eye(n3) (b-a)*eye(n3);
     zeros(n3,n2) zeros(n3) eye(n3);
     zeros(n3,n2) zeros(n3) eye(n3)];
Q = [zeros(n2,n1) zeros(n2) zeros(n2,n3);
     zeros(n2,n1) eye(n2) zeros(n2,n3);
     zeros(n3,n1) zeros(n3,n2) zeros(n3);
     zeros(n3,n1) zeros(n3,n2) (b-theta)*eye(n3);
     zeros(n3,n1) zeros(n3,n2) zeros(n3);
     zeros(n3,n1) zeros(n3,n2) eye(n3)];
K = [zeros(n1,n2) zeros(n1,n3) zeros(n1,n3);
     eye(n2) zeros(n2,n3) zeros(n2,n3);
     zeros(n3,n2) eye(n3) (s-a)*eye(n3)];
L0 = [eye(n1) zeros(n1,n2) zeros(n1,n3);
     zeros(n2,n1) zeros(n2) zeros(n2,n3);
     zeros(n3,n1) zeros(n3,n2) zeros(n3)];
L1 = [zeros(n1) zeros(n1,n2) zeros(n1,n3);
     zeros(n2,n1) eye(n2) zeros(n2,n3);
     zeros(n3,n1) zeros(n3,n2) (s-theta)*eye(n3)];
V = [zeros(n2,n2) zeros(n2,n3) zeros(n2,n3);
     zeros(n3,n2) zeros(n3,n3) eye(n3)];
F0 = [zeros(n2,n1) eye(n2) zeros(n2,n3);
      zeros(n3,n1) zeros(n3,n2) zeros(n3)];
F1 = [zeros(n2,n1) zeros(n2) zeros(n2,n3);
      zeros(n3,n1) zeros(n3,n2) eye(n3)];
  
  
%--------------------------------------------------------------------------
disp('Converting all states to fundamental state');
% H maps [x1 x2s x3ss] to [x1 x2 x3] 
H.R.R0 = L0; H.R.R1 = L1 -K*inv(B*T)*B*Q; H.R.R2 = -K*inv(B*T)*B*Q;
H.dim = [0 0; np np];
 
% H2 maps [x1 x2s x3ss] to [x2s x3s]
H2.R.R0 = F0; H2.R.R1 = F1 - V*inv(B*T)*B*Q; H2.R.R2 = - V*inv(B*T)*B*Q;
H2.dim = [0 0;n2+n3 np];

%Assemble A operator, that is get Af from A0, A1 and A2
PA.R.R0 = A0*H.R.R0+A1*H2.R.R0 + [zeros(np,n1) zeros(np,n2) A2];
PA.R.R1 = A0*H.R.R1+A1*H2.R.R1;
PA.R.R2 = A0*H.R.R2+A1*H2.R.R2;
PA.dim = [0 0;np np];

%Assemble B operator
PB.Q2 = B1;
PB.dim = [0 nw;np 0];

%Assemble C operator
% convert operator C to fundamental state operator
C31 = -C1*T*inv(B*T)*B*Q+C1*Q;
Pea1.Q1 = subs(Ca,s,theta); 
Pea1.dim = [ny 0; 0 np];
Pea2.R.R0=H.R.R0; Pea2.R.R1=H.R.R1; Pea2.R.R2 = H.R.R2;
Pea2.dim = [0 0; np np];
Peb1.Q1 = subs(Cb,s,theta);
Peb1.dim = [ny 0; 0 n2+n3];
Peb2.R.R0=H2.R.R0; Peb2.R.R1=H2.R.R1; Peb2.R.R2 = H2.R.R2;
Peb2.dim = [0 0; n2+n3 np];
C32 = compose_p(Pea1,Pea2,s,theta,X);
C33 = compose_p(Peb1,Peb2,s,theta,X);
C3 = C31+C32.Q1+C33.Q1;
C3s = subs(C3,theta,s);

PC.Q1 = C3s; 
PC.dim = [ny 0;0 np];