function [prog,Pv] = sospos_L2L_ker_psatz(prog,n,d1,d2,var1,var2,I)
%
% SOSJOINTPOS_MAT_KER_SEMISEP(prog,n,d1,d2,var1,var2,I) declares the multiplier $M(s)$ and
% kernel part $N(s,t)$ of a positive multiplier+integral operator. The
% multiplier and kernel have the form
%
% M(s) = Z(s)^T Q_{11} Z(s) g(s)
% N1(s,t) = Z(s)^T Q_{12} Z(s,t) g(s) + Z(t,s)^T Q_{31} Z(t) g(t) 
%   + \int_{I(1)}^t Z(ss,s)^T Q_{33} Z(ss,t) g(ss) dss
%       +\int_t^sZ(ss,s)^T Q_{32} Z(ss,t) g(ss) dss
%       +\int_s^{I(2)}Z(ss,s)^T Q_{22} Z(ss,t) g(ss) dss
% N2(s,t) = Z(s)^T Q_{13} Z(s,t) g(s) + Z(t,s)^T Q_{21} Z(t) g(t)
%   + \int_{I(1)}^sZ(ss,s)^T Q_{33} Z(ss,t) g(ss) dss
%       +\int_s^tZ(ss,s)^T Q_{23} Z(ss,t) g(ss) dss
%       +\int_t^{I(2)}Z(ss,s)^T Q_{22} Z(ss,t) g(ss) dss
% Q = [ Q_{11}  Q_{12} Q_{13}]
%     [ Q_{21}  Q_{22} Q_{23}] >0
%     [ Q_{31}  Q_{32} Q_{33}]
%
% 
% where Z(x)= Z_d1(x) \otimes I_n and Z_d(x) is the vector of monomials in
% variables x of degree d1 or less. Z(x,y) = Z_{d1}(x) \otimes Z_{d2}(y)
% \otimes I_n. If the application is stability of time-delay systems, d1
% will eventually be more or less the degree of the multiplier and d2 more
% or less the degree of the kernel function.
% we recommend setting d2 = d1 to keep the polynomial degrees balanced.
%
% N(s,t) = { N1(s,t)        s>t
%          { N2(s,t)        t>s
%
% INPUTS 
%   prog: SOS program to modify.
%   n: dimension of the resulting matrix
%   d1: degree of the multiplier (sort of)
%   d2: degree of the kernel
%   var1: Single pvar corresponding to s in the description
%   var2: Single pvar corresponding to t in the description
%   I = [l u] interval of integration
%
% OUTPUT 
%   N1: subdiagonal function
%   N2: superdiagonal superdiagonal
%
% NOTES:
% Distributed with DelayTOOLS
% Compatable with MULTIPOLY and SOSTOOLS as of June 2013
% For support, contact M. Peet, Arizona State University at mpeet@asu.edu

if ~isvalid(var1) || ~isvalid(var2)
  error(['vars must be a polynomial variable']);
end
dum=polynomial(1,1,{'ss'},[1 1]);

g=(var1-I(1))*(I(2)-var1);                                  % modified to add the g term - MP 3.24.2015

% I'm going to construct Z manually so I know where everything is
nZth=d1+1;
Z1degmat = [0:d1]';
Z1coeff = speye(nZth);
Z1varname = var1.varname;
Z1matdim = [nZth 1];
ZZZth=polynomial(Z1coeff,Z1degmat,Z1varname,Z1matdim);


% There are two configurations for the degree d2. Probably the most logical one is 
% that for TDS applications, 2d1 ends up as the degree of the multiplier and
% 2d2 as the degree of the kernel. This is the following:

Z2degmat = [repmat([0:d1]',d2+1,1),vec(repmat(0:d2,d1+1,1))];
nZthksi=length(Z2degmat);
Z2coeff = speye(nZthksi);
Z2varname = [var1.varname; var2.varname];
Z2matdim = [nZthksi 1];
ZZZthksi=polynomial(Z2coeff,Z2degmat,Z2varname,Z2matdim);

% For other applications, however, we may want 2d2 to represent the
% internal variable of integration, in which case we use the following:
% 
% Z2degmat = [repmat([0:d2]',d1+1,1),vec(repmat(0:d1,d2+1,1))];
% nZthksi=length(Z2degmat);
% Z2coeff = speye(nZthksi);
% Z2varname = [var1.varname; var2.varname];
% Z2matdim = [nZthksi 1];
% ZZZthksi=polynomial(Z2coeff,Z2degmat,Z2varname,Z2matdim);


%nBZ1=n*nZth;
nBZ2=n*nZthksi;
[prog,LLL]=sosposmatr(prog,2*nBZ2);


% Lets start by just assuming LLL has been partitioned
% In this case, things are more or less a repeat of the positive matrix
% variable case in sosposmatrvar.m with P replaced by LLL1 and Z with ZZZth
% Note, however that because this rearranges the order of the elements of
% ZZZth, we must alter all the manipulations or the result will be invalid.
ind1=1:nBZ2; ind2=(nBZ2+1):(2*nBZ2);
Q22=LLL(ind1,ind1);
Q23=LLL(ind1,ind2);
Q33=LLL(ind2,ind2);
Q32=Q23.';
%%%%%%%%%%%%%%%%%%%%%%%%%
% Construct M


%%%%%%%%%%%%%%%%%%%%%%%%%
% Construct CA1
%CA1=bZ2omth.'*Q33*bZ2omksi;
%   Z(ss,s)^T Q_{33} Z(ss,t)
disp('CA1')

% first, lets construct Zomth and Zomksi
tvarname=[Q33.varname; var1.varname{1}; var2.varname{1}; dum.varname{1}];

 %if strcmp(var1.varname{1},ZZZthksi.varname{1}) % th is in the first position
         bZdegmat1=repmat([ZZZthksi.degmat(:,2) zeros(nZthksi,1)  ZZZthksi.degmat(:,1)],n,1); %bZomth
         bZdegmat2=repmat([zeros(nZthksi,1) ZZZthksi.degmat(:,2)  ZZZthksi.degmat(:,1)],n,1); %bZomksi
 %else
 %    bZdegmat1=repmat([ZZZthksi.degmat(:,1) zeros(nZthksi,1)  ZZZthksi.degmat(:,2)],n,1); %bZomth
 %    bZdegmat2=repmat([zeros(nZthksi,1) ZZZthksi.degmat(:,1)  ZZZthksi.degmat(:,2)],n,1); %bZomksi
 %end
 nZ1=nZthksi;nbZ1=n*nZ1;
 nZ2=nZthksi;nbZ2=n*nZ2;

[PIlist, PJlist]=find(Q33.coefficient); % This is the list of terms in P, but PIlist and Pjlist will be relatively short. 
[Prowu,Pcolu] = ind2sub([nbZ1 nbZ2],PJlist); % this returns the matrix locations for every term in P
tdegmat = [Q33.degmat(PIlist,:) bZdegmat1(Prowu,:)+bZdegmat2(Pcolu,:)];


newrow=ceil(Prowu/nZ1);
newcol=ceil(Pcolu/nZ2);

newidx=sub2ind([n n],newrow, newcol);%(newcol-1)*n+newrow;
nPIlist=(1:length(PIlist))';
coeff=sparse(nPIlist,newidx,1);
tmatdim=[n n];
CA1=polynomial(coeff,tdegmat,tvarname,tmatdim);

clear tdegmat tmatdim coeff nPIlist newidx newcol newrow row col Prowu Pcolu PIlist PJlist

%%%%%%%%%%%%%%%%%%%%%%%%%
% Construct CA2
%CA=bZ2omth.'*Q32*bZ2omksi;
%   Z(ss,s)^T Q_{33} Z(ss,t)
disp('CA2')

% first, lets construct Zomth and Zomksi
tvarname=[Q32.varname; var1.varname{1}; var2.varname{1}; dum.varname{1}];
 nZ1=nZthksi;nbZ1=n*nZ1;
 nZ2=nZthksi;nbZ2=n*nZ2;


 %if strcmp(var1.varname{1},ZZZthksi.varname{1}) % th is in the first position
 %        bZdegmat1=repmat([ZZZthksi.degmat(:,2) zeros(nZthksi,1)  ZZZthksi.degmat(:,1)],n,1); %bZomth
 %        bZdegmat2=repmat([zeros(nZthksi,1) ZZZthksi.degmat(:,2)  ZZZthksi.degmat(:,1)],n,1); %bZomksi
 %else
 %    bZdegmat1=repmat([ZZZthksi.degmat(:,1) zeros(nZthksi,1)  ZZZthksi.degmat(:,2)],n,1); %bZomth
 %    bZdegmat2=repmat([zeros(nZthksi,1) ZZZthksi.degmat(:,1)  ZZZthksi.degmat(:,2)],n,1); %bZomksi
 %end

[PIlist, PJlist]=find(Q32.coefficient); % This is the list of terms in P, but PIlist and Pjlist will be relatively short. 
[Prowu,Pcolu] = ind2sub([nbZ1 nbZ2],PJlist); % this returns the matrix locations for every term in P
tdegmat = [Q32.degmat(PIlist,:) bZdegmat1(Prowu,:)+bZdegmat2(Pcolu,:)];


newrow=ceil(Prowu/nZ1);
newcol=ceil(Pcolu/nZ2);

newidx=sub2ind([n n],newrow, newcol);%(newcol-1)*n+newrow;
nPIlist=(1:length(PIlist))';
coeff=sparse(nPIlist,newidx,1);
tmatdim=[n n];
CA2=polynomial(coeff,tdegmat,tvarname,tmatdim);

clear tdegmat tmatdim coeff nPIlist newidx newcol newrow row col Prowu Pcolu PIlist PJlist

%%%%%%%%%%%%%%%%%%%%%%%%%
% Construct CA3
%CA=bZ2omth.'*Q22*bZ2omksi;
%   Z(ss,s)^T Q_{22} Z(ss,t)

disp('CA3')

nZ1=nZthksi;nbZ1=n*nZ1;
 nZ2=nZthksi;nbZ2=n*nZ2;


tvarname=[Q22.varname; var1.varname{1}; var2.varname{1}; dum.varname{1}];

 %if strcmp(var1.varname{1},ZZZthksi.varname{1}) % th is in the first position
 %        bZdegmat1=repmat([ZZZthksi.degmat(:,2) zeros(nZthksi,1)  ZZZthksi.degmat(:,1)],n,1); %bZomth
 %        bZdegmat2=repmat([zeros(nZthksi,1) ZZZthksi.degmat(:,2)  ZZZthksi.degmat(:,1)],n,1); %bZomksi
 %else
 %    bZdegmat1=repmat([ZZZthksi.degmat(:,1) zeros(nZthksi,1)  ZZZthksi.degmat(:,2)],n,1); %bZomth
 %    bZdegmat2=repmat([zeros(nZthksi,1) ZZZthksi.degmat(:,1)  ZZZthksi.degmat(:,2)],n,1); %bZomksi
 %end

[PIlist, PJlist]=find(Q22.coefficient); % This is the list of terms in P, but PIlist and Pjlist will be relatively short. 
[Prowu,Pcolu] = ind2sub([nbZ1 nbZ2],PJlist); % this returns the matrix locations for every term in P
tdegmat = [Q22.degmat(PIlist,:) bZdegmat1(Prowu,:)+bZdegmat2(Pcolu,:)];


newrow=ceil(Prowu/nZ1);
newcol=ceil(Pcolu/nZ2);

newidx=sub2ind([n n],newrow, newcol);%(newcol-1)*n+newrow;
nPIlist=(1:length(PIlist))';
coeff=sparse(nPIlist,newidx,1);
tmatdim=[n n];
CA3=polynomial(coeff,tdegmat,tvarname,tmatdim);

clear tdegmat tvarname tmatdim bZdegmat1 bZdegmat2 coeff nPIlist newidx newcol newrow row col Prowu Pcolu PIlist PJlist

% N1(s,t) = Z(s)^T Q_{12} Z(s,t) + Z(t,s)^T Q_{31} Z(t) 
%   + \int_{I(1)}^t Z(ss,s)^T Q_{33} Z(ss,t) dss
%       +\int_t^sZ(ss,s)^T Q_{32} Z(ss,t) dss
%       +\int_s^{I(2)}Z(ss,s)^T Q_{22} Z(ss,t) dss
disp('integrating')
N1=int(CA1*subs(g,var1,dum),dum,I(1),var2)+int(CA2*subs(g,var1,dum),dum,var2,var1)+int(CA3*subs(g,var1,dum),dum,var1,I(2));    % modified to add the g term - MP 3.24.2015
N2=var_swap(N1.',var1,var2);

Pv.R.R1 = N1; Pv.R.R2 = N2;
end
