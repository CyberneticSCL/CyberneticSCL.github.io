function [Padj] = transpose_p(P,s,theta)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function transposes an operator P: R^p x L2^q to R^m x L2^n
% Date: 6/1/19
% Version: 1.0
% INPUTS
% P: operator with the matlab structure as below
% P.dim: an 2x2 array with entries [m,p]
%                                  [n,q]
% P.P: a mxp matrix
% P.Q1: a mxq matrix valued polynomial in s
% P.Q2: a nxp matrix valued polynomial in s
% P.R.R0: a nxq matrix valued poynomial in s
% P.R.R1: a nxq matrix valued poynomial in s, theta
% P.R.R2: a nxq matrix valued poynomial in s, theta
% s, theta: polynomial variables 
% 
% OUTPUTS
% Padj: transpose of the input operator with the same matlab structure as P

indim = P.dim(:,2);
outdim = P.dim(:,1);

if indim(2)==0 
    if outdim(2)==0 % operator is from R to R
    Padj.P = P.P';
    elseif outdim(1)==0 % operator is from R to L2
    Padj.Q1 = P.Q2';
    else %operator is from R to RL2
    Padj.P = P.P';
    Padj.Q1 = P.Q2';
    end
elseif indim(1)==0
    if outdim(2)==0 % operator is from L2 to R
    Padj.Q2 = P.Q1';   
    elseif outdim(1)==0 % operator is from L2 to L2
    Padj.R.R0 = P.R.R0';
    Padj.R.R1 = var_swap(P.R.R2',s,theta);
    Padj.R.R2 = var_swap(P.R.R1',s,theta);
    else % operator is from L2 to RL2
    Padj.Q2 = P.Q1';
    Padj.R.R0 = P.R.R0';
    Padj.R.R1 = var_swap(P.R.R2',s,theta);
    Padj.R.R2 = var_swap(P.R.R1',s,theta);
    end
elseif outdim(2)==0 %operator is from RL2 to R
    Padj.P = P.P';
    Padj.Q2 = P.Q1';
elseif outdim(1)==0 %operator is from RL2 to L2
    Padj.Q1 = P.Q2';
    Padj.R.R0 = P.R.R0';
    Padj.R.R1 = var_swap(P.R.R2',s,theta);
    Padj.R.R2 = var_swap(P.R.R1',s,theta);
else %operator is from RL2 to RL2
    Padj.P = P.P';
    Padj.Q1 = P.Q2';
    Padj.Q2 = P.Q1';
    Padj.R.R0 = P.R.R0';
    Padj.R.R1 = var_swap(P.R.R2',s,theta);
    Padj.R.R2 = var_swap(P.R.R1',s,theta);
end
Padj.dim(:,2) = outdim;
Padj.dim(:,1) = indim;
end