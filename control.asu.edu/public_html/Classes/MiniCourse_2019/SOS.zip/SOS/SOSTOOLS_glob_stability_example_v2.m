% SOSTOOLS_glob_stability_example_v2 --- An SOS Program for proving global stability
% of a linear controller (k1,k2,k3) stabilizing attitude dynamics
%
% INPUT: user can modify f, vector field or g, the region of local
% stability.
%
% This file is part of SOS DEMOs - An SOS Demonstration Toolbox.
%
% Copyright (C) 2017  M. Peet (1)
% (1) Arizona State University, Tempe, AZ 85287, USA.
%
% Send feedback to: mpeet@asu.edu
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 2 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
%
% 05/01/17 - MP -- Initial Coding

pvar w1 w2 w3
gam=4.0; %desired decay rate
J1=2;J2=1;J3=1; 
k1=1;k2=1;k3=1;% controller gains
u1=-k1*w1;u2=-k2*w2;u3=-k3*w3; % define feedback controller
f=[(J2-J3)/J1*w2*w3+u1;
    (J3-J1)/J2*w3*w1+u2;
    (J1-J2)/J3*w1*w2+u3];
prog=sosprogram([w1 w2 w3]);
Z=monomials([w1 w2 w3],1:2);
[prog,V]=sossosvar(prog,Z);
V=V+.0001*(w1^4+w2^4+w3^4); % strict positivity condition
%prog=soseq(prog,subs(V,[x; y],[0; 0]))
nablaV=[diff(V,w1);diff(V,w2);diff(V,w3)];
prog=sosineq(prog,-nablaV'*f-gam*V);
prog=sossolve(prog);
Vn=sosgetsol(prog,V)