% SOSTOOLS_glob_control --- An SOS Program for Finding nonlinear
% Controllers using iteration - search for V, then K, then V, then K
%
% INPUT: user can modify f, vector field or g, the region of local
% stability.
%
% This file is part of LMI DEMOs - An LMI Demonstration Toolbox.
%
% Copyright (C) 2017  M. Peet (1)
% (1) Arizona State University, Tempe, AZ 85287, USA.
%
% Send feedback to: mpeet@asu.edu
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 2 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
%
% 05/01/17 - MP -- Initial Coding

pvar x1 x2 x3
u=0;
g=1-x1^2+x2^2+x3^2;
f=[-x1+x2-x3;
    -x1*x3-x2+u;
    -x1+u];
prog=sosprogram([x1 x2 x3]);
Z4=monomials([x1 x2 x3],0:4);
Z2=monomials([x1 x2 x3],0:2);
[prog,V]=sossosvar(prog,Z2);
[prog,t]=sospolyvar(prog,Z4);
prog=sosineq(prog,V+t*g-.01);
%V=V+.0001*(x1^4+x2^4+x3^4);
%prog=soseq(prog,subs(V,[x; y],[0; 0]))
nablaV=[diff(V,x1);diff(V,x2);diff(V,x3)];
prog=sosineq(prog,-nablaV'*f);
prog=sossolve(prog);
Vn=sosgetsol(prog,V)




% Finds a Global Controller using a CLF
% Global Controller Synthesis on $||<1$ with v=x^2+y^2+z^2
pvar x1 x2 x3
prog=sosprogram([x1 x2 x3]);
Z4=monomials([x1 x2 x3],1:1);
Z2=monomials([x1 x2 x3],0:3);
[prog,k1]=sospolyvar(prog,Z4);
[prog,k2]=sospolyvar(prog,Z4);
u1=k1; u2=k2;
f=[-x1+x2-x3;
    -x1*x3-x2+u1;
    -x1+u2];
V=x1^2+x2^2+x3^2;
nablaV=[diff(V,x1);diff(V,x2);diff(V,x3)];
prog=sosineq(prog,-(nablaV'*f));
prog=sossolve(prog);
k1n=sosgetsol(prog,k1)
k2n=sosgetsol(prog,k2)


% Finds a local controller using a CLF
% Local Controller Synthesis on $||<1$ with v=x^2+y^2+z^2
pvar x1 x2 x3
prog=sosprogram([x1 x2 x3]);
r=1; g=r-(x1^2+x2^2+x3^2);
Z4=monomials([x1 x2 x3],0:3);
Z2=monomials([x1 x2 x3],0:3);
[prog,k1]=sospolyvar(prog,Z4);
[prog,k2]=sospolyvar(prog,Z4);
u1=k1; u2=k2;
f=[-x1+x2-x3;
    -x1*x3-x2+u1;
    -x1+u2];
V=x1^2+x2^2+x3^2;
%V=x1^4+x2^4+x3^4;
%V=Vn;
nablaV=[diff(V,x1);diff(V,x2);diff(V,x3)];
[prog,s]=sossosvar(prog,Z2);
%prog=sosineq(prog,-(nablaV'*f)-s*g);
prog=sosineq(prog,-(nablaV'*f));
prog=sossolve(prog);
k1n=sosgetsol(prog,k1)
k2n=sosgetsol(prog,k2)


% % Uses kn from previous run to find best Lyapunov function
% u1=k1n;
% u2=k2n;
% f=[-x1+x2-x3;
%     -x1*x3-x2+u1;
%     -x1+u2];
% prog=sosprogram([x1 x2 x3]);
% Z=monomials([x1 x2 x3],1:2);
% [prog,V]=sossosvar(prog,Z);
% V=V+.0001*(x1^4+x2^4+x3^4);
% %prog=soseq(prog,subs(V,[x; y],[0; 0]))
% nablaV=[diff(V,x1);diff(V,x2);diff(V,x3)];
% prog=sosineq(prog,-nablaV'*f-2*V);
% prog=sossolve(prog);
% Vn=sosgetsol(prog,V)

% Uses kn from previous run to find best Lyapunov function
u1=k1n;
u2=k2n;
f=[-x1+x2-x3;
    -x1*x3-x2+u1;
    -x1+u2];
prog=sosprogram([x1 x2 x3]);
Z4=monomials([x1 x2 x3],0:4);
Z2=monomials([x1 x2 x3],0:2);
[prog,V]=sossosvar(prog,Z2);
[prog,t]=sospolyvar(prog,Z4);
prog=sosineq(prog,V+t*g-.01);
%prog=soseq(prog,subs(V,[x; y],[0; 0]))
nablaV=[diff(V,x1);diff(V,x2);diff(V,x3)];
prog=sosineq(prog,-nablaV'*f-2*V);
prog=sossolve(prog);
Vn=sosgetsol(prog,V)



% Uses Vn from previous run to find controller
prog=sosprogram([x1 x2 x3]);
r=.01;
g=r-(x1^2+x2^2+x3^2);
Z4=monomials([x1 x2 x3],0:4);
Z2=monomials([x1 x2 x3],0:2);
[prog,k1]=sospolyvar(prog,Z4);
%[prog,k2]=sospolyvar(prog,Z4);
u1=k1;
u2=k1;
f=[-x1+x2-x3;
    -x1*x3-x2+u1;
    -x1+u2];
%V=x1^2+x2^2+x3^2;
%V=x1^4+x2^4+x3^4;
V=Vn;
nablaV=[diff(V,x1);diff(V,x2);diff(V,x3)];
[prog,s]=sossosvar(prog,Z2);
prog=sosineq(prog,-(nablaV'*f)-s*g);
%prog=sosineq(prog,-(nablaV'*f));
prog=sossolve(prog);
k1n=sosgetsol(prog,k1)





