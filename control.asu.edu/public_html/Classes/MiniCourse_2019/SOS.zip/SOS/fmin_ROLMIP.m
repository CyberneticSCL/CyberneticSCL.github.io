%pvar s th x y
%hh=(s^5+th^3-x^7*s+y^2)
%rp=pvar2rolmipvar(hh,'bounds',[-2 1;3 4;5 6;-1 1])
pvar s1 s2
del=1;
hh=(s1^2-(2-del)*s1*s2+s2^2)
rp=pvar2rolmipvar(hh)


sdpvar gam
cons=[polya(rp,20)-gam>=0]
optimize(cons,-gam)
double(gam)
subs(subs(subs(subs(hh,s,-1),th,4),x,6),y,0)
