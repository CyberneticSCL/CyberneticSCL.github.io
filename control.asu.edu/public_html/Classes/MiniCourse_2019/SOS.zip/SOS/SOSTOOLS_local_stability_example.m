% SOSTOOLS_local_stability_example --- An SOS Program for verifying
% robust stability of a nonlinear system. First, stability without
% robustness, then stability with robustness.
%
% INPUT: user can modify f, vector field, g - seimalgebraic set. User must
% perform bisection on r and gam manually (will be updated eventually to make this automatic)
%
% This file is part of LMI DEMOs - An LMI Demonstration Toolbox.
%
% Copyright (C) 2017  M. Peet (1)
% (1) Arizona State University, Tempe, AZ 85287, USA.
%
% Send feedback to: mpeet@asu.edu
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 2 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
%
% 05/01/17 - MP -- Initial Coding

% This finds the largest r (bisection) for which we can find a LF decreasing on
% the ball of radius r
pvar x y
mu=1; r=2.8;
g=r-(x^2+y^2);
f=[-y;
    -mu*(1-x^2)*y+x];
prog=sosprogram([x y]);
Z4=monomials([x y],0:4);
Z2=monomials([x y],0:2);
[prog,V]=sossosvar(prog,Z2);
%[prog,t]=sospolyvar(prog,Z4);
%prog=sosineq(prog,V+t*g-.01);
V=V+.0001*(x^4+y^4);
prog=soseq(prog,subs(V,[x; y],[0; 0]))
nablaV=[diff(V,x);diff(V,y)];
[prog,s]=sossosvar(prog,Z2);
prog=sosineq(prog,-nablaV'*f-s*g);
prog=sossolve(prog);
Vn=sosgetsol(prog,V)

% This finds the largest sublevel set of V contained in Br.
% max gamma such that g>0 for all x: v<gamma
gamma=4.3
prog=sosprogram([x y]);
Z4=monomials([x y],0:4);
Z2=monomials([x y],0:2);
[prog,s]=sossosvar(prog,Z2);
Vg=gamma-Vn;
prog=sosineq(prog,g-s*Vg);
prog=sossolve(prog);
