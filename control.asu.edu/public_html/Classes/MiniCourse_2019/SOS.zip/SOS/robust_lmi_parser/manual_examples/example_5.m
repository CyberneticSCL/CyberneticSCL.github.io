clear;

poly_P = rolmipvar(3,3,'P','symmetric',3,2);
