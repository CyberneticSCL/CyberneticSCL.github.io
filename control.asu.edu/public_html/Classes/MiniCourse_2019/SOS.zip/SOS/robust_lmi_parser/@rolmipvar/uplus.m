function Z = uplus(X)
%UPLUS (overloaded)
%
% Author: Cristiano Agulhari
% 2016, Nov, 4
Z = X;

