function rp=pvar2rolmipvar(pp,vartable,varargin)
%   inputs:
%     pp - pvar to be analyzed
%     vartable - {x1,x2,x3,\cdots,xn} ordered list of independent vars in pp 
%   optional parameters: two format are possible. 1) structure; 2) 'property
%   name', value, 'property name', value,...
%     bounds = [x1min x1max;
%             x2min x2max;
%                \vdots
%             xnmin xnmax]; used to inform parameters in a hyperrectangle
%     echo - show some messages on screen.
%          
%   

options = [];
if nargin > 2
    if nargin == 3
        options = varargin{1};
    else
        options = struct(varargin{:});
    end
end

if ~isfield(options,'bounds')
    options.bounds = [];    
end
if ~isfield(options,'echo')
    options.echo = 1;
end

if options.echo & ~isempty(options.bounds)
    fprintf('var name  bounds\n');
    for i=1:size(options.bounds,1)
        fprintf('%s \t [%.2f %.2f]\n',vartable{i}.varname{1},options.bounds(i,1),options.bounds(i,2));
    end
end

if isempty(options.bounds)
    [hp,monHomog] = homogenize(pp,vartable);
    if options.echo & monHomog
        fprintf('%d monomials homogeneized up to degree %d\n',monHomog,pp.maxdeg);
    end
    degmat=full(hp.degmat);
    if isempty(degmat)
        rp=rolmipvar(pp.coefficient','rp');
        return;
    end
    for i=1:hp.nterms        
        c{i}={degmat(i,:),full(reshape(hp.coefficient(i,:),hp.matdim(1),hp.matdim(2)))};
    end
    rp=rolmipvar(c,'rp',hp.nvars,hp.maxdeg);    
else
    degmat=full(pp.degmat);
    for i=1:pp.nterms
        c{i}={degmat(i,:),full(reshape(pp.coefficient(i,:),pp.matdim(1),pp.matdim(2)))};
    end
    rp=rolmipvar(c,'rp',options.bounds);
end
lb = lowerBound(rp);
if options.echo 
    fprintf('lower bound: %.4f\n',lb);
end
%__________________________________________________________________________
function [hp,monHomog] = homogenize(p,vartable)

degmat=full(p.degmat);
if isempty(degmat)
    hp=p;
    return;
end
%creating the unit sum
us = vartable{1};
for i=2:size(vartable,2)    
    us = us +vartable{i};        
end
hp = 0;
monHomog=0;
for i=1:p.nterms
    mon = degmat(i,:);
    coef = full(reshape(p.coefficient(i,:),p.matdim(1),p.matdim(2)));
    term = polynomial(vec(coef)',mon,p.varname,[p.matdim]);
    % if it needs to be homogeneized
    if sum(mon) < p.maxdeg
        updeg = p.maxdeg - sum(mon);
        term = term*us^updeg;        
        monHomog=monHomog+1;
    end
    hp = hp + term;
end

%__________________________________________________________________________
function lb = lowerBound(rp)

N=rp.vertices;
lb=1e10;
for i=1:1000
    for j=1:size(N,2)
        comb=rand(1,N(j));
        comb = comb./sum(comb);
        c{j} = comb;
    end
    v=evalpar(rp,c);
    if max(real(eig(v))) < lb
        lb = max(real(eig(v)));
    end        
end
