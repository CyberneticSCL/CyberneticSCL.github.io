% SOSTOOLS_local_stability_example --- An SOS Program for verifying
% robust stability of parameter-dependent matrix.
%
% INPUT: user can modify Am, or any of the min's or max's - better not
% change the names of the variables...
%
% This file is part of LMI DEMOs - An LMI Demonstration Toolbox.
%
% Copyright (C) 2017  M. Peet (1)
% (1) Arizona State University, Tempe, AZ 85287, USA.
%
% Send feedback to: mpeet@asu.edu
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 2 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
%
% 05/01/17 - MP -- Initial Coding

% This finds the largest r (bisection) for which we can find a LF decreasing on
% the ball of radius r

pvar m c k
Am=[0 m;-c*m -k];
mmin=.1;mmax=1;cmin=.1;cmax=1;kmin=.1;kmax=1;
g1=(mmax-m)*(m-mmin);
g2=(cmax-c)*(c-cmin);
g3=(kmax-k)*(k-kmin);
vartable=[m c k]
prog=sosprogram(vartable);
[prog,S0]=sosposmatrvar(prog,2,4,vartable);
[prog,S1]=sosposmatrvar(prog,2,4,vartable);
[prog,S2]=sosposmatrvar(prog,2,4,vartable);
[prog,S3]=sosposmatrvar(prog,2,4,vartable);
P=S0+g1*S1+g2*S2+g3*S3+.00001*eye(2);
[prog,R0]=sosposmatrvar(prog,2,4,vartable);
[prog,R1]=sosposmatrvar(prog,2,4,vartable);
[prog,R2]=sosposmatrvar(prog,2,4,vartable);
[prog,R3]=sosposmatrvar(prog,2,4,vartable);
Derv=Am'*P+P*Am;
constr=-Derv-m*(R0+R1*g1+R2*g2+R3*g3);
prog=sosmateq_hack(prog,constr);
prog=sossolve(prog);
Pn=sosgetsol(prog,P)