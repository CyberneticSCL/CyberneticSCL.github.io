% SOSTOOLS_glob_stability_example --- An SOS Program for proving global stability
% of a given set of dynamics 
%
% INPUT: user can modify f, the vector field or the positivity condition of the LF.
%
% This file is part of SOS DEMOs - An SOS Demonstration Toolbox.
%
% Copyright (C) 2017  M. Peet (1)
% (1) Arizona State University, Tempe, AZ 85287, USA.
%
% Send feedback to: mpeet@asu.edu
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 2 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
%
% 05/01/17 - MP -- Initial Coding

pvar x y
f=[-y-1.5*x^2-.5*x^3;
    3*x-y];
prog=sosprogram([x y]);
Z=monomials([x,y],1:2);
[prog,V]=sossosvar(prog,Z);
V=V+.0001*(x^4+y^4); % strictness of Lyapunov function
prog=soseq(prog,subs(V,[x; y],[0; 0]))
nablaV=[diff(V,x);diff(V,y)];
prog=sosineq(prog,-nablaV'*f);
prog=sossolve(prog);
Vn=sosgetsol(prog,V)