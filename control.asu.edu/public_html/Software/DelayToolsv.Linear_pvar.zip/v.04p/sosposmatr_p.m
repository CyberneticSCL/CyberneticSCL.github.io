function [prog,P]=sosposmatr_p_temp(prog,n)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MatrixTools v.03 - sosposmatr
% This program declares a symbolic positive scalar semidefinite matrix P of size nxn 
% inputs: 
% prog
% n - size of matrix variable
% th - some random symbolic variable used in prog(doesn't matter which)
%
% version .03   M. Peet, Stanford. matthew.peet@inria.fr
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% MatrixTools - sosposmatr
% Release Notes:
% v.03 - deleted the requirement to pass in a random symbolic
% variable
%
% Other changes with this release are minor.
%
% MMP 6/2/2013 - restructured to reduce overhead. Still requires dual
% assignment of pvars. Still substantial room for improvement, including eliminating the need for Z by direct assignment of variables without call to sossosvar. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% if isempty(prog.vartable{1})
%     disp('error: no symbolic variables have been declared')
%     return
% end
% 
% Z=monomials(pvar(eval(prog.vartable{1})),[1:n]);

pvar(prog.vartable{1});
Z=monomials(eval(prog.vartable{1}),[1:n]);
[prog,VAR] = sossosvar(prog,Z,'wscoeff');
sizett=prog.var.idx{length(prog.var.idx)}-prog.var.idx{length(prog.var.idx)-1}; % the number of new decision variables which have been added.
begin_n=prog.var.idx{length(prog.var.idx)-1};
nTT=sqrt(sizett);
nn=begin_n;
%prog.decvartable
% decstr=prog.decvartable{begin_n};
% for jt=1:sizett-1
%     decstr=[decstr,', ', prog.decvartable{begin_n+jt} ];
%     pvar()
% end
%decstr='';
varname=cell(sizett,1);
for jt=0:sizett-1
%    decstr=[decstr,' ', prog.decvartable{begin_n+jt} ];
    varname{jt+1}=prog.decvartable{begin_n+jt};
%    pvar([prog.decvartable{begin_n+jt}]);
end
%eval(['cccc = [ ',decstr,' ];']);
%P=reshape(cccc,nTT,nTT);



% Lets try and create this directly
coeff=speye(nTT^2);
degmat=speye(nTT^2);
matdim=[nTT,nTT];
P=polynomial(coeff,degmat,varname,matdim);
%degmat=