function norm_est=CL_norm_estimator(tau,A0,A,B1,B2,C0,C,D1,D2,padeorder)

for i=1:length(tau)
    DelayT(i) = struct('delay',tau(i),'a',A{i},'b',0*[B1 B2],'c',C{i},'d',0*[D1 D2]);
end
sysdel=delayss(A0,[B1 B2],[C0],[D1 D2],DelayT);
sysx=pade(sysdel,padeorder);


[AT,BT,CT,DT] = ssdata(sysx);
range11=1:size(B1,2);
range22=size(B1,2)+1:(size(B1,2)+size(B2,2));
BT1=BT(:,range11);
BT2=BT(:,range22);
DT1=DT(:,range11);
DT2=DT(:,range22);
nss=size(AT,1);
ncc=size(B2,2);
ndd=size(B1,2);
nrr=size(C0,1);  % number of regulated outputs

gamma=sdpvar(1);               % represents the bound on the H-infinity norm of the CL system.
X=sdpvar(nss);
Z=sdpvar(ncc,nss,'full');
W=sdpvar(nrr);

% declare constraints
MAT=[AT*X+X*AT'+BT2*Z+Z'*BT2'       BT1              (CT*X+DT2*Z)';
     BT1'                        -gamma*eye(ndd)   DT1';
     CT*X+DT2*Z                 DT1              -gamma*eye(nrr)];
F=[MAT<=0];
F=[F;X>=.0001*eye(nss)];

OPTIONS = sdpsettings('solver','sedumi','verbose',0);

% Solve the LMI, minimizing gamma
optimize(F,gamma,OPTIONS);
norm_est=value(gamma);