function [bigZCth,P_h,H_h,Gam_h,S_h] = P_PQRS_Inverse_joint_sep_ndelay_vtau_alt(NP,NQ,NR,NS,delays)
%
% P_PQRS_Inverse_joint_sep(P,Q,R,S) computes the inverse operator of the
% operator
%
% P[ x1    ](s)=[ P*x1 +sum_i int_-tau_i^0 Q_i(th)x_2(th)d th                    ]
%  [ x2_i(s) ]    [ tauK*Q_i(s)^T*x1 +tauK*S_i(s)x_2(s) + tauK*sum_j int_-tau_j^0 R_ij(s,th)x2_j(th)dth ]
%
% In this version, the function resturns the matrix representations of Q_h
% and R_h as these variables are more numerically reliable.
%
% INPUTS 
%   NP,NQ,NR,NS: values of P,Q,R,S - Q,R,S must be of type cell
%   delays = [tau1 ... tauK] increasing values of the delay
%
% OUTPUT 
%   bigZCth,P_h,H_h,Gam_h,S_h
%
%   The variables P_h,Qh,Rh,S_h are polynomials of dimensions compatible with
%   P,Q,R,S and are found as
%   Qh{i}=H_h{i}*bigZCth*S_h{i}
%   R_h{i,j}=S_h{i}*bigZCth'*Gam_h{i,j}*subs(bigZCth,th,ksi)*S_h{j}
%
% the inverse operator has the form
% P^-1[ x1      ](s)=[ Ph*x1 +1/tauK*sum_i int_-tau_i^0 Qh_i(th)x_2(th)d th                    ]
%     [ x2_i(s) ]    [ Qh_i(s)^T*x1 +1/tauK*Sh_i(s)x_2(s) + 1/tauK*sum_j int_-tau_j^0 Rh_ij(s,th)x2_j(th)dth ]
%
% NOTES:
% Distributed with DelayTOOLS
% Compatable with MULTIPOLY and SOSTOOLS as of June 2013
% For support, contact M. Peet, Arizona State University at mpeet@asu.edu
% Initial Coding:
% 6/21/18 - MMP  -  titled P_PQRS_Inverse_joint_sep_ndelay_vtau_alt

K=length(delays);
for i=1:K
    l(i)=-delays(i);u(i)=0;
end
%tau=u-l;

n_dim=size(NP,1);
m_dim=size(NS{1},1);

if ~iscell(NQ)
    error(['NQ, NR, SR must be cell arrays'])
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The first step is to construct the separable representation of the
% Polynomials Q and R
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% For ZQ and NR, we need to convert to the forms
% NQ=H Z(s) and NR= Z(s)^T Gam Z(theta) as per paper
% or for us this is Q=HZ(theta) and NR= Z(theta)^T Gam Z(ksi)
% however, we need to be consistent about our Z
dm=0;
for i=1:K
    dQ{i}=NQ{i}.degmat;
    dmQ{i}=max(max(dQ{i}));
    dm=max([dm dmQ{i}]);
    for j=1:K
        dR{i,j}=NR{i,j}.degmat;
        dmR{i,j}=max(max(dR{i,j}));
        dm=max([dm dmR{i,j}]);
    end
    %    dm=max([dmQ dmR]);
end

var1=NQ{1}.Varname(1);

ZCth=polynomial(eye(dm+1),[0:dm]',NQ{1}.Varname(1),[dm+1 1]); % common vector of monomials
bigZCth=[];
for i=1:m_dim
    bigZCth=blkdiag(bigZCth,ZCth);
end

% Now use bigZCth to find H_i!
for ii=1:K
    nZ=length(ZCth);
    for i=1:n_dim
        for j=1:m_dim
            [CQij,Ztemp,etemp] = poly2basis(NQ{ii}(i,j),ZCth); % examine each element of NQ
            bigC{ii}(i,(nZ*(j-1)+1):(nZ*j))=CQij.';
        end
    end
    H{ii}=bigC{ii};
end


%H{1}*bigZCth-NQ{1}  %uncomment to verify the representation (should be 0)

% Now we deal with NR

for ii=1:K
    for jj=1:K
        for i=1:m_dim
            for j=1:m_dim % address the decomposition of each element separately and place in the larger matrix Q
                if strcmp(var1,NR{ii,jj}(i,j).varname(1))
                    varR1=1;
                    varR2=2;
                elseif strcmp(var1,NR{ii,jj}(i,j).varname(2))
                    varR1=2;
                    varR2=1;
                else
                    disp('ERROR: variables in Q and R do not match')
                end
                dmij=NR{ii,jj}(i,j).degmat;
                cfij=NR{ii,jj}(i,j).coeff;
                CN=zeros(dm+1,dm+1);
                for k=1:length(cfij) % take each coefficient and put it in its proper place in CN, which is then assembled into CbigN
                    CN(full(dmij(k,varR1))+1,full(dmij(k,varR2))+1)=cfij(k);
                end
                Gam{ii,jj}(((dm+1)*(i-1)+1):((dm+1)*i),((dm+1)*(j-1)+1):((dm+1)*j))=CN;
            end
        end
    end
end
%bigZCksi=subs(bigZCth,th,ksi); bigZCksi.'*Gam{1,1}*bigZCth-NR{1,1} % this
%bigZCksi=subs(bigZCth,th,ksi); bigZCth.'*Gam{1,1}*bigZCksi-NR{1,1} % this
%should be zero, uncomment to verify

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now that we have the right representation, we can construct the inverse
% using our generalization of Keqin's formula.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% The first step is to find a polynomial approximation to S^{-1}

N=20; orderapp=6; % specifies the degree of the polynomial approximation and the number of data points to fit at.
% It is recommended to use at least a 12th order approximation
pvar th ss ksi

for iii=1:K
    interval = delays(iii)/N; % specifies the degree of the polynomial approximation and the number of data points to fit at.
    ii=0;
    NSnoma{iii}=inv(double(subs_p(NS{iii},th,-delays(iii)))); % calculates the inverse at s=-tau
    NSnomb{iii}=inv(double(subs_p(NS{iii},th,0))); % calculates the inverse at s=0
    for ss=[-delays(iii):interval:0]
        ii=ii+1;
        NShtemp(:,:,ii)=inv(double(subs_p(NS{iii},th,ss))); % going to use polyfix...
    end
    
    % The following fits a polynomial to every element of S^{-1} (now fitting the deviation)
    for i=1:m_dim
        for j=1:m_dim
            Data1=squeeze(NShtemp(i,j,:))';
            xfix=[-delays(iii),0]; %matching constraint at -tau and 0
            yfix=[NSnoma{iii}(i,j),NSnomb{iii}(i,j)]; % match to the value of the inverse matrix at these points
            [temp]=polyfix([-delays(iii):interval:0],Data1,orderapp,xfix,yfix);
%            % uses matlab internal polynomial representation - This alternative requires recentering and rescaling post-processing
            syms th2   %Converts to a symbolic variable representation
            Sinv_temp=s2p(poly2sym(temp,th2)); % this approach works, but seems fragile.
            pvar th2   % Converts to a pvar representation
            Sinv{iii}(i,j)=subs_p(Sinv_temp,th2,th);
            clear Data1 temp Sinv_temp
        end
    end
    S_h{iii}=Sinv{iii};
    
% This is the polynomial that is returned as S_h. It is not used to calculate the
    % following integral, however.
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    
    % Now we compute the matrix K (does not use the approximate S^{-1})
    % This is an anonymous function which is the integrand
    int_fun = @(sss) double(subs_p(bigZCth,th,sss))*inv(double(subs_p(NS{iii},th,sss)))*double(subs_p(bigZCth,th,sss)).';
    % Uses Matlab internal numerical integration routine.
%    Ks{iii}=integral(int_fun,-delays(iii),0,'ArrayValued',true,'AbsTol',1e-16,'RelTol',1e-12);
    Ks{iii}=integral(int_fun,-delays(iii),0,'ArrayValued',true,'AbsTol',1e-12,'RelTol',1e-10);
    
    % Now ready to compute the matrices to return
    
    
end

%Now construct big versions of K, Gam and H
Hb=[];Gamb=[];Kb=[];
for ii=1:K
    Hb=[Hb H{ii}];
    Kb=blkdiag(Kb,Ks{ii});
    GamT=[];
    for jj=1:K
        GamT=[GamT Gam{ii,jj}];
    end
    Gamb=[Gamb;GamT];
end

P_inv=inv(double(NP));

ndtemp=size(Kb,1);
Tb=inv(Kb*Hb.'*P_inv*Hb-eye(ndtemp)-Kb*Gamb);
Hb_h=P_inv*Hb*inv(Kb*Hb.'*P_inv*Hb-eye(ndtemp)-Kb*Gamb);

P_h=(eye(n_dim) - Hb_h*Kb*Hb.')*P_inv;

Gamb_h=-(Hb_h.'*Hb+Gamb)*inv(eye(ndtemp)+Kb*Gamb);

zdim=size(H{1},2);
for ii=1:K
    H_h{ii}=Hb_h(1:n_dim,((ii-1)*zdim+1):ii*zdim);
    Z_h_th{ii}=bigZCth*Sinv{ii}; % This inherits its degree from S^{-1}
    Q_h{ii}=H_h{ii}*Z_h_th{ii};
    Z_h_ksi{ii}=subs_p(Z_h_th{ii},th,ksi);   
end
for ii=1:K
     for jj=1:K
             Gam_h{ii,jj}=Gamb_h(((ii-1)*zdim+1):ii*zdim,((jj-1)*zdim+1):jj*zdim);
             R_h{ii,jj} = Z_h_th{ii}.'*Gam_h{ii,jj}*Z_h_ksi{jj};  % Twice the degree of S^{-1}
     end
end
% T=inv(eye(ndtemp)+K*Gam-K*H.'*P_inv*H); % Scalar Matrix
% H_h=-P_inv*H*T; % Scalar Matrix

% % % Qh = H_h*Z_h_th; % Same degree as S^{-1}
% % 
% % %Gam_h=(T.'*H.'*P_inv*H-Gam)*inv(eye(ndtemp)+K*Gam); % % Scalar Matrix
% % 
% % % Z_h_ksi=subs(Z_h_th,th,ksi);   
% % % Rh = Z_h_th.'*Gam_h*Z_h_ksi;  % Twice the degree of S^{-1}
% % 
% % % % check self-adjoint condition - these should be equal
% % % delays(1)*(subs(NQ{1}.',th,0)+subs(NS{1},th,0))
% % %  NP
% % % 
% % % % check self-adjoint condition - these should be equal
%  subs(R_h{1,1},th,0)
%  Q_h{1}
% % % 
% % % % check self-adjoint condition - these should be equal
% subs(Q_h{1}.',th,0)+subs(S_h{1},th,0)/delays(1)
% P_h
% 
% % check self-adjoint condition - these should be equal
% subs(R_h{1,1},th,0)
% Q_h{1}


