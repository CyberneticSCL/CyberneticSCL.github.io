function [ f ] = estimator_dynamics3( t,y,Apr,Apr2,C,xmesh,x_sol )
%The state variables are
% ph - first n_dim*(N-1) states in y
% xh - last n_dim states in y

% Last Edited:
% 1/27/18 - MMP

% still needs n_dim, C, xmesh, x_sol
N=size(xmesh,2);
n_dim=size(C,2);
q_dim=size(C,1);
tmesh=t+xmesh;

err=reshape(C*(reshape(y,[n_dim,N])-deval(x_sol,tmesh,((N-1)*n_dim+1):N*n_dim)),[q_dim*N,1]);

f=Apr*y+Apr2*err;


end
   
