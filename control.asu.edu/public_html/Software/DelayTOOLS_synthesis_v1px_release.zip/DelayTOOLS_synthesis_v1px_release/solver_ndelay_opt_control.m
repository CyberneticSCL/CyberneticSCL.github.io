clear all; close all; echo off;
total=tic;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% DelayTools/Linear v.05 - solver_ndelay_opt_control
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This program finds a full-state feedback controller which minimizes an
% H_\infty bound on the closed-loop system. The system has the form
% \dot{x}(t)=A0x(t)+A{1}x(t-tau(1))+...+A{K}x(t-tau(K)) + B1w(t)+B2u(t)
% where w(t) is the vector of disturbances
%
% u(t) is the controller input and is of the form
% u(t)=K0 x(t) + \sum_i K1{i}x(t-tau(i)) + \sum_i \int_{-\tau(i)}^0 K2{i}(s)x(t-s)ds
%
% The regulated output is of the form
% y(t) = C0x(t)+\sum_i C{i}x(t-tau(i))+D1w(t)+D2u(t)
%
% where A0, A{i}, B1, B2, C0, C{i}, D1, D2 and tau(i) are all user inputs.
%
% Inputs: A0, A{i} - matrices of dimension n x n (n is arbitrary)
%
%         B1 - a matrix of dimension n x m (m is arbitrary)
%         B2 - a matrix of dimension n x p (p is arbitrary)
%
%         C0, C{i} - matrices of dimension q x n (q is arbitrary)
%
%         D1 - a matrix of dimension q x m
%         D2 - a matrix of dimension q x p
%
%         tau(i) - These can be an arbitrary sequence of positive increasing
%         numbers.
%
%         orderth/ordernu - This input controls the accuracy of the results. For
%         most problems, orderth=ordernu=4 should be sufficient to obtain a
%         reasonable degree of accuracy. Note: orderth should be an even
%         integer.
%
% Requirements: In order to operate, this program requires a working
%               version of SOStools. There are some known compatability
%               issues with SOStools and Matlab version 7+ due to errors in
%               the implementation of Maple v8. In addition, it
%               is highly recommended that the user have a compiled version
%               of cdd. Finally the following package of subprograms are
%               required which allows SOStools to handle matrix objects
%               directly:
%               SOStools Matrix Addon package:
%                   sosposmatr.m
%                   sosmateq.m
%                   sosjointpos_mat_ker_ndelay_PQRS_vZ
%                   sosjointpos_mat_ker_R_L2
%                   sosjointpos_mat_ker_R_L2_psatz
%
% version .03   M. Peet, Arizona State University. mpeet@asu.edu
%% Initial Coding:
% 6/21/18 - MMP  -  titled solver_ndelay_opt_control.m

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs
%
% Enter degree of accuracy - must be an even integer
orderth = 6;  % this number is twice that listed in the paper as d
ordernu = 12;  % it is recommended to use ordernu = 2*orderth in order to match degrees
override1=0; % if override1=1, the LF will not include psatz terms in the kernel - default=0
override2=0; % if override2=1, the derivative check will not include psatz terms in the kernel - default=0
shower_ex=0;


%%%%%%%%%%%%%%%%%%%
% Simulation Options:
nspans=20; % Length of simulation as measured by a multiple of the max delay 
N=50;     % number of discrete states used to represent the history of each delay



%
% Enter system dynamics

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Examples of Controller Synthesis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Uncomment this section to run the shower example from the paper
% Plots generated for this example will be different than for other test
% cases
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % %%% Multiple Showering People - tracking with integral control
% n=4; %This is the number of users and can be changed
%
% shower_ex=2;
% nndelay=n;
% for i=1:nndelay
%     tau(i)=n;
% end
% alpha=1;
% alphav=alpha*ones(n,1);
% gamma=1/n;
% gammaM=gamma*ones(n,n);
% zn=zeros(n);
%  A0=[zn eye(n);zn zn];
% for i=1:n
%     gammav=gammaM(:,i);
%     Atemp=zn;
%     Atemp(:,i)=alphav(i)*gammav;
%     Atemp(i,i)=-alphav(i);
%     A{i}=[zn zn;zn Atemp];
% end
% Gam=zn;
% for i=1:nndelay
%     for j=1:n
%         if i~=j
%             Gam(i,j)=alphav(j)*gammaM(i,j);
%         end
%     end
% end
% B1=[-eye(n);diag(alphav)-Gam];
% B2=[zn;eye(n)];
% C0=[eye(n) zn;zn zn];
% for i=1:nndelay
%     C{i}=[zn zn;zn zn];
% end
% D1=[zn;zn];
% D2=[zn;.1*eye(n)];
% %gam_guess; % min in [.32 .38]

% 
% % % % % % % Problem B.1 - from Example 3 in Fridman/Shaked 2003
  A0=[0 0;0 1];%
  A{1}=[-1 -1; 0 -.9];%
  B1=[1;1]; B2=[0;1];
  C0=[0 1;0 0]; C{1}=[0 0;0 0];
  D1=[0;0]; D2=[0;.1];
  tau(1) = 2; %1.5707
% % 
% % % %  gam=1.4385  % range is in [1.4385] @2,4, eps1=eps2=.000001, tau=2
% % % % gam=1.3533  % range is in [1.35, 1.36] @4,8, eps1=eps2=.000001, tau=2
% % % % gam=1.3315  % range is in [1.340, 1.341] @6,12, eps1=eps2=.000001, tau=2
% % % % gam=.10001  % range is in [.1, .10001] @2,4, eps1=eps2=.000001, tau=.999
% % % % gam=.10001  % range is in [.1, .10001] @4,8, eps1=eps2=.000001, tau=.999
% % % % gam=.10001  % range is in [.1, .10001] @6,12, eps1=eps2=.000001, tau=.999
% %%%% at tau=5, Pade estimate is 3.487



% % % % Problem B.2 - Example 1 in Fridman, 1998
%  A0=[2 1; 0 -1];
%  A{1}=[-1 0; -1 1];
% C0=[1 -.5; 0 0]; C{1}=[0 0;0 0];
% B2=[3;1]; %B in paper
% B1=[-.5;1]; % D in paper
% tau(1)=.3;
% D1=[0;0];
% D2=[0;1];
% % gam=.3953  % range is in [.246, .248] @4,8, eps1=eps2=.000001, tau=.3
% % compare with .3983 at tau=.3 in Fridman
% % % C=[0 10]


% % % % % Problem B.3 - Modified Problem 3: from Fridman/Shaked 2003
% A0=[0 0;0 1];%
% A{1}=[-1 -1; 0 -.9];%
% B1=[1 0;0 1]; B2=[0;1];
% C0=[1 0;0 1;0 0]; C{1}=[0 0; 0 0;0 0];
% D1=[0 0;0 0;0 0]; D2=[0;0;.1];
% tau(1) = 2; %1.5707
% % gam=3  % range is in [1.41, 1.42] @4,8, eps1=eps2=.000001, tau=2
% % gam=.101  % range is in [.099, .101] @4,8, eps1=eps2=.000001, tau=.999

% % % % Problem B.4 - from Fridman/Shaked 2003 with two delays
%   A0=[0 0;0 1];%
%   A{1}=[-1 -1; 0 -.9];%
%   A{2}=[-1 -1; 0 -.9];%
%   B1=[1;1]; B2=[0;1];
%   C0=[0 1;0 0]; C{1}=[0 0;0 0]; C{2}=[0 0;0 0];
%   D1=[0;0]; D2=[0;.1];
%   tau(1) = 1; %1.5707
%   tau(2) = 2; %1.5707
% % gam=2  % range is in [1.41, 1.42] @4,8, eps1=eps2=.000001, tau=2
% % gam=.101  % range is in [.099, .101] @4,8, eps1=eps2=.000001, tau=.999


% % % % Problem B.5: This is scalability test which uses orderth=ordernu=2 and
% % both overrides. For this case, the closed-loop gain is typically ~1.0
% 
% % % delaymat=[1 2 3 5 10]
% % % dimmat=[1 2 3 5 20]
% % % for iii=1:1
% % %     for jjj=5:5
% % %         clear prog tau A A0 R R2 Q Q2 S S2 P P2 G
% % % nndim=dimmat(jjj);nndelay=delaymat(iii);
%  nndim=10;nndelay=1;
% 
% A0=zeros(nndim);B1=ones(nndim,1); B2=ones(nndim,1); C0=[ones(1,nndim);zeros(1,nndim)];
% D1=[0;0]; D2=[0;1];
% for j=1:nndelay
%   A{j}=-eye(nndim)/nndelay;
%   C{j}=zeros(2,nndim);
%   tau(j) = j/nndelay;
% end
% % % % % %          n_dim
% % % % % %          1      2      3      5      10
% % % % % % n_dly 1  .271                        18.00
% % % % % % n_dly 2  
% % % % % % n_dly 3  
% % % % % % n_dly 5  1.387
% % % % % % n_dly 10 12.12


%
% toc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% H_infty Norm Calculations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% For these calculations, we set B2=0
% The open loop must be stable
% Note that computational complexity for norm bounding can be reduced by
% eliminating the controller variables entirely.

% % % % Problem A.1 from Fridman 2001 Example 1:
%   A0=[-2 0;0 -.9];%
%   A{1}=[-1 0; -1 -1];%
%   B1=[-.5;1]; B2=[0;0];
%   C0=[1 0]; C{1}=[0 0];
%   D1=[0]; D2=[0];
%   tau(1) = .846; %1.5707
%  %gam=.2373  % range is in [.2373] @2,4, eps1=.00001, tau=.846
%  %gam=.2365 % range is in [.2365] @4,8, eps1=.00001, tau=.846
%  %gam=.2365  % range is in [.2365] @6,12, eps1=.00001, tau=.846

% % % % % Problem A.2: verify simulation without control
%  A0=[0 1; -2 .1];
%  A{1}=[0 0;1 0];
%  tau(1) = 1.1710; %stable range is [.10017, 1.71785]
%    B1=[1 0;0 1]; B2=[0;0];
%    C0=[0 1;0 0]; C{1}=[0 0;0 0]; 
%    D1=[0 0;0 0]; D2=[0;.1];
% % % orderth 2 [.10017 .10018 ] [1.693 1.694] time=.478
% % % orderth 4 [.100173 .100174] [1.7176 1.7177] time= .879
% % % orderth 6 [.100173 ] [1.71785] time=2.48


% % % Problem A.3:
% A0=[0 1; -1 .1];
% A{1}=[0 0;-1 0];
% A{2}=[0 0;1 0];
%    B1=[1 0;0 1]; B2=[0;0];
%    C0=[1 0;0 1]; C{1}=[0 0;0 0]; C{2}=[0 0;0 0]; 
%    D1=[0 0;0 0]; D2=[0;0];
% tau(2) = 1.0 %1.372 is max [1.35,1.372]
% tau(1) = tau(2)/2;
% % orderth 2 10.5996 tau2=1
% % orderth 4 10.3265 tau2=1
% % orderth 6 10.3264 tau2=1
% % pade gives 10.3263



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% End User Defined Inputs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\
padeorder=10;
norm_est=CL_norm_estimator(tau,A0,A,B1,B2,C0,C,D1,D2,padeorder);
disp('The minimum estimated CL norm using Pade is ')
norm_est

% %====================
% %====================
% % estimate open-loop Hinf norm using Pade
% n_dim=size(A0,1);
% s=tf('s');
% den=s*eye(n_dim)-A0;
% num=C0;
% ndelay=length(tau);
% for i=1:ndelay
% den=den-A{i}*exp(-tau(i)*s);
% num=num+C{i}*exp(-tau(i)*s);
% end
% pp=num*inv(den)*B1+D1;
% sysapp=pade(pp,10);
% disp('Estimated open-loop Hinf norm is')
% norm(sysapp,inf)



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% internal variables:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%fact=1/tau;
fact=1;           % conditioning multiplier
eps1=.00001;           % strictness of LF w/r to norm{x(0)} - must be strictly positive (but can be small)
eps11=0;          % strictness of LF w/r to norm{x_t}_{L2}
eps2=0;%.0001;           % strictness of derivative negativity
%epsbig=1000;

% control inputs to SeDuMi
pars.alg=2;
pars.stepdif=1;
pars.eps=10^(-10);
pars.maxiter=100;
pars.cg.maxiter=200;
pars.cg.qprec=1;
pars.cg.stagtol=1e-22;
pars.cg.restol=5e-5;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% internal processing:
pvar th ksi
pvar gam

n_dim=length(A0);
p_dim=size(B2,2); % input size
q_dim=size(C0,1); % regulated output size
m_dim=size(B1,2); % disturbance size
n_delay=length(tau);
tauK=tau(n_delay);

mastervartable=[th,ksi];
prog = sosprogram(mastervartable,[gam]);

% This is the multiple delay case.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% phase 1 - variables %%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% we will need to declare variables:
% P, Q(th), S(th), R(th,ksi)
%

disp('creating joint positive operator variable')
tic


[prog,P,Q,R,S] = sosjointpos_mat_ker_ndelay_PQRS_vZ(prog,n_dim,n_dim,orderth/2,ordernu/2,th,ksi,tau,override1);

% % creating an upper bound
% [prog,Pu,Qu,Ru,Su] = sosjointpos_mat_ker_ndelay_PQRS_vZ(prog,n_dim,n_dim,orderth/2,ordernu/2,th,ksi,tau,override1);
% prog = sosmateq(prog,epsbig*eye(n_dim)-P-Pu);
% for i=1:n_delay
%     prog = sosmateq(prog,-Q{i}-Qu{i});
%     prog = sosmateq(prog,epsbig*eye(n_dim)-S{i}-Su{i});
%     for j=i:n_delay % the latter j>1 define constraints
%             prog = sosmateq(prog,-R{i,j}-Ru{i,j});
%     end
% end


toc
P=P+eps1*eye(n_dim); % making the operator strictly positive

% There are two constraints that the variables must satisfy:
% P=\tau_kQ_i(0)^T + \tau_k S_i(0)   for all i
% Q_i(s)=R_{j,i}(0,s)                for all i,j

for i=1:n_delay % the latter i define constraints
    S{i}=S{i}+eps11*eye(n_dim);
    %[sos] = sosmatrixineq(sos,fM,option)
    %    prog = sosmatrixineq(prog,epsbig*eye(n_dim)-S{i})
    prog = sosmateq(prog,P-(tauK*subs_p(Q{i}.',th,0)+tauK*subs_p(S{i},th,0)));
    for j=1:n_delay % the latter j>1 define constraints
        prog = sosmateq(prog,Q{i}-subs_p(var_swap(R{j,i},th,ksi),ksi,0));
    end
end

% Z variables
[prog, Z0]= sosmatrvar(prog,[1],[p_dim,n_dim]);
for i=1:n_delay % the latter i define constraints
    [prog, Z1{i}]= sosmatrvar(prog,[1],[p_dim,n_dim]);
    [prog, Z2{i}]= sosmatrvar(prog,monomials(th,0:orderth),[p_dim,n_dim]);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% phase 2 - derivatives %%%%%%%%%%%%%%%%%%%%
%%%%%%% Step1 %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% the derivative matrices are spelled out in the paper, they are
disp('constructing Derivatives, elapsed time:')
tic
% Construct D, E{i}, F{i}, G{i,j} in the derivative

% first do the constant terms. These are inside the integral.



D11=-gam/tauK*eye(q_dim);
D12=D1/tauK;
D13=(C0*P+D2*Z0)/tauK;
D14=[];
for i=1:n_delay
    D13=D13+C{i}*subs_p(Q{i}.',th,-tau(i));
    D14=[D14 C{i}*subs_p(S{i},th,-tau(i))+D2*Z1{i}/tauK];
end
D22=-gam/tauK*eye(m_dim);
D23=B1.';
D24=polynomial(zeros(m_dim,n_delay*n_dim));

L0=A0*P+B2*Z0;
for i=1:n_delay
    L0=L0+tauK*A{i}*subs_p(Q{i}.',th,-tau(i))+subs_p(S{i},th,0)/2;
end

D33=L0+L0.'+eps2*eye(n_dim);
D34=[];
D44=[];
for i=1:n_delay
    %    D33=D33+tauK*A{i}*subs(Q{i}.',th,-tau(i))+tauK*subs(Q{i},th,-tau(i))*A{i}.'+subs(S{i},th,0);
    D34=[D34 tauK*A{i}*subs_p(S{i},th,-tau(i))+B2*Z1{i}];
    D44=blkdiag(D44,(subs_p(-S{i},th,-tau(i))));
end
D=[D11 D12 D13 D14;
    D12.' D22 D23 D24;
    D13.' D23.' D33 D34
    D14.' D24.' D34.' D44];

% Construct E{i} and F{i}
E4=polynomial(zeros(n_delay*n_dim,n_dim));
E2=polynomial(zeros(m_dim,n_dim));
for i=1:n_delay
    E1{i}=C0*Q{i}+D2*Z2{i};
    E3{i}=A0*Q{i} + diff(Q{i},th)+B2*Z2{i};
    for j=1:n_delay
        E1{i}=E1{i}+C{j}*subs_p(var_swap(R{j,i},th,ksi),ksi,-tau(j));
        E3{i}=E3{i}+A{j}*subs_p(var_swap(R{j,i},th,ksi),ksi,-tau(j));
    end
    E{i}=[E1{i}/tauK;
        E2;
        E3{i};
        E4];
    F{i}=diff(S{i},th)+eps2*eye*(n_dim);
end



for i=1:n_delay
    for j=1:n_delay
        G{i,j}=(diff(R{i,j},th)+diff(var_swap(R{j,i}.',th,ksi),ksi));
    end
end

toc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Step2 %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Enforce negativity of D
disp('enforcing negativity of derivative')
%Now declare first spacing functions

%[prog, M, N] = sosjointpos_mat_ker_ndelay(prog,2*n_dim,orderth/2,ordernu/2,th,ksi,II);
disp('Calling for jointly positive Mat/Kernel, elapsed time:')
tic
[prog,P2,Q2,R2,S2] = sosjointpos_mat_ker_ndelay_PQRS_vZ(prog,q_dim+m_dim+(n_delay+1)*n_dim,n_dim,orderth/2,ordernu/2,th,ksi,tau,override2);
toc

disp('Constructing Equality Constraints:')

tic
prog = sosmateq(prog,D+P2);
for i=1:n_delay
    prog = sosmateq(prog,Q2{i}+E{i});
    prog = sosmateq(prog,S2{i}+F{i});
    for j=i:n_delay % the latter j>1 define constraints
        prog = sosmateq(prog,R2{i,j}+G{i,j});
    end
end
toc

toc
disp('TOTAL POLYNOMIAL TIME:')
toc(total)
disp('Computing Solution')

prog=sossetobj(prog,gam);

disp('Computing Solution')
prog = sossolve(prog);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reconstructing the Controller and Simulating the Response
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

disp('The Closed-Loop Hinf norm bound obtained was')
ngam=sosgetsol(prog,gam)


r=tau(n_delay);
NP = sosgetsolmat(prog,P,10);
NZ0 = sosgetsolmat(prog,Z0,10);
for i=1:n_delay
    NQ{i} = sosgetsolmat(prog,Q{i},10);
    NS{i} = sosgetsolmat(prog,S{i},10);
    NZ1{i} = sosgetsolmat(prog,Z1{i},10);
    NZ2{i} = sosgetsolmat(prog,Z2{i},10);
    
    for j=1:n_delay
        NR{i,j} = sosgetsolmat(prog,R{i,j},10)/tauK; % the /tau is to match the input format of the inverse function
    end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% We now have the variables and the next step is computing the inverse of
% P_{P,Q,S,R}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

tspan=nspans*tau(n_delay);  % length of simulation and number of states representing the delay
% where the states are determined by the values of s in xmesh





[bigZ,P_h,H_h,Gam_h,S_h] = P_PQRS_Inverse_joint_sep_ndelay_vtau_alt(NP,NQ,NR,NS,tau);

for i=1:n_delay
    int_fun = @(sss) double(subs_p(NZ2{i},th,sss))*inv(double(subs_p(NS{i},th,sss)))*double(subs_p(bigZ,th,sss)).';
    % Uses Matlab internal numerical integration routine.
    LT{i}=integral(int_fun,-tau(i),0,'ArrayValued',true,'AbsTol',1e-12,'RelTol',1e-10);
    NSi{i}=inv(double(subs_p(NS{i},th,-tau(i))));
end

clear K0t K12t K2t
K0=NZ0*P_h;
for j=1:n_delay
    K0=K0+(NZ1{j}*NSi{j}*subs_p(bigZ.',th,-tau(j))+LT{j})*H_h{j}.';
end

for i=1:n_delay
    K1{i}=1/tauK*NZ1{i}*NSi{i};
    K2{i}=NZ0*H_h{i}*bigZ+NZ2{i};
    for j=1:n_delay
        K2{i}=K2{i}+(NZ1{j}*NSi{j}.'*subs_p(bigZ.',th,-tau(j))+LT{j})*Gam_h{j,i}*bigZ;
    end
    K2{i}=K2{i}/tauK; % note that the actual multiplier is K2ti(s)*Si^{-1}(s)
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% For implementation, we construct the matrix representation of K
%%% In the multi-delay case, we have two options, we can create a separate
%%% set of states for every [-tau_i,0] or for every [-tau_i, -tau_{i-1}]
%%% Naturally, the first option creates significantly more states, but
%%% is more consistent with our state-space representation, wherein
%%% there is a separate pipe for every delay. I am also concerned there
%%% could be losses at the transition between pipes if the
%%% discretization step is different for each section of the pipe.
%%% Obviously, the ideal would be a uniform discretization, but this is
%%% not possible unless the delays are commensurate. Finally, the
%%% separate pipe strategy adapts well to the differential-difference
%%% formulation where the pipes have different sizes.
%%%
%%% For these reasons, we will use a signficantly inflated state-space
%%% corresponding to a separate set of states for each interval of
%%% delay [-tau_i,0]. This will result in N*n_dim*n_delay states in the
%%% ODE representation.
% the tau_i is increasing
% the total number of states is n_dim*((N-1)*n_delay+1)=n_dim*N*n_delay-n_delay*n_dim+ndim because the final n_dim states are common to all (the current state)
% The set of states associated with [-tau_i,0] is (N-1)*n_dim*(i-1)+1:(N-1)*n_dim*i
nstates=n_dim*N*n_delay-n_delay*n_dim+n_dim;
rangef=(n_dim*(N*n_delay-1)+1):n_dim*N*n_delay; % this is the Final(f) set of states which define the current time



clear K0M K1M K2M
K0M=double(K0);
Kpr=zeros(p_dim,nstates);
Kpr(1:p_dim,rangef)=K0M;

for i=1:n_delay
    xmesh{i}=linspace(-tau(i),0,N);
    dx(i)=xmesh{i}(2)-xmesh{i}(1);
    
    ii=0;
    K1M{i}=double(K1{i});
    for xi=xmesh{i}
        ii=ii+1;
        K2M{i}(:,:,ii)=double(subs_p(K2{i},th,xi))*inv(double(subs_p(NS{i},th,xi)));
    end
    begin=(N-1)*n_dim*(i-1);        % this is the index for the last state in the previous interval.
    Kpr(1:p_dim,(begin+1):(begin+n_dim))=K1M{i}+K2M{i}(:,:,1)*dx(i);
    for ii=2:N-1
        rangei2=(begin+(ii-1)*n_dim+1):(begin+ii*n_dim);
        Kpr(1:p_dim,rangei2)=K2M{i}(:,:,ii)*dx(i);
    end
    % I have this commented to skip the final period of integration.
    % Alternatively, we could skip the first period, but one should be
    % skipped for each interval
    %        Kprt(1:p_dim,rangef)=Kprt(1:p_dim,rangef)+K2M{i}(:,:,N)*dx(i);
    
end
% The Kpr matrix should now be set up. We now proceed to the system
% matrices

%%%%%%%%%%%%%%%% System Matrices %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% We now construct the Nominal derivative matrices for the state

% We are building a representation of the form \dot x = (A+B2K)x + B1 w

% Apr respresents the uncontrolled dynamics after discretization
Apr=zeros(nstates,nstates);
B2pr=zeros(nstates,p_dim);
B1pr=zeros(nstates,m_dim);
Cpr=zeros(q_dim,nstates);

for i=1:n_delay
    begin=(N-1)*n_dim*(i-1);        % this is the index for the last state in the previous interval.
    ranges=begin+1:(N-1)*n_dim*i; % this is the range of indices for states in the current interval
    
    % This matrix is of size (N-1)*n_dim x N*n_dim
    Apr_temp=[-eye((N-1)*n_dim)/dx(i) zeros((N-1)*n_dim,n_dim)]+[zeros((N-1)*n_dim,n_dim) eye((N-1)*n_dim)/dx(i)];
    %         ranges=(N-1)*n_dim*(i-1)+1:(N-1)*n_dim*i;
    Apr(ranges,ranges)=Apr_temp(1:(N-1)*n_dim,1:(N-1)*n_dim);
    Apr(ranges,rangef)=Apr_temp(:,(N-1)*n_dim+1:N*n_dim);
    Apr(rangef,begin+1:begin+n_dim)=A{i}; % this picks out the states x(t-\tau_i)
    
    Cpr(1:q_dim,begin+1:begin+n_dim)=C{i};   % this picks out the states x(t-\tau_i)
    
end
Apr(rangef,rangef)=A0;                    % this picks out the states x(t)

B2pr(rangef,1:p_dim)=B2;                  % the input only affects the dynamics of the current state
B1pr(rangef,1:m_dim)=B1;                  % the disturbance only affects the dynamics of the current state
Cpr(1:q_dim,rangef)=C0;                   % This is the output from the current state

%    Now Construct the closed-loop system matrices

Afin=Apr+B2pr*Kpr;
Bfin=B1pr;
Cfin=Cpr+D2*Kpr;
Dfin=D1;
sys=ss(Afin,Bfin,Cfin,Dfin);

%%% Here we enter our disturbance model as an anonymous function which
%%% is zero until time t=tau. Right now this only is implemented for a
%%% single disturbance channel
wfun=@(t) 10*(t>tau)*sinc((4*t-tau(n_delay))); % disturbance function - zero until time tau (to allow for startup)

% Here we numerically calculate the L_2 norm of the disturbance
tmesh1=linspace(0,tspan,1000);
norm_w=0;
for tt=2:length(tmesh1)
    norm_w=norm_w+norm(wfun(tmesh1(tt)))^2*(tmesh1(tt)-tmesh1(tt-1));
end
l2w=sqrt(norm_w);


nsamples=tspan/dx(n_delay);
t2=linspace(0,tspan,nsamples);
u=repmat(sinc((t2-tau(n_delay))).',1,m_dim);

[ys,ts,xs]=lsim(sys,u,t2);
dt=t2(2)-t2(1);
ntemp=0;
ntemp2=0;

for t3=1:nsamples-1
    ntemp=ntemp+u(t3,:)*u(t3,:).'*dt;
    ntemp2=ntemp2+ys(t3,:)*ys(t3,:).'*dt;
end
normu=sqrt(ntemp);
normy=sqrt(ntemp2);

disp('The closed-loop system L_2 gain for the Sinc disturbance is ')
gain_est=normy/normu
disp('This number may be slightly off due to finite time-horizon and discretization errors')
%    plot(ts,xs(:,n_dim*N+1:2*N*n_dim))

rangef1=n_dim*(N-1)+1:n_dim*N;
figure
plot(ts,xs(:,rangef))
plot(ts,xs(:,1:n_dim))
hold on
title('State History for sinc disturbance')
figure
hold on
plot(ts,u)
plot(ts,ys)
title('Disturbance and Regulated Output for sinc disturbance')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Special Case Logic for step response if the Shower example is being tested.

if shower_ex==2
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%% Step Response v2.
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% Avoid using the Matlab Step command
    
    % Here we numerically calculate the L_2 norm of the disturbance
    tmesh1=linspace(0,tspan,1000);
    
    nsamples=tspan/dx(n_delay);
    %    nsamples=500;
    t2=linspace(0,tspan,nsamples);
    temp=1:n
    ustep=repmat(1:m_dim,length(t2),1);
    %    u=repmat(sin((t2-tau)).',1,w_dim);
    %     for t3=1:nsamples
    %     u(t3,:)=wfun(t2(t3));
    %     end
    [ys,ts,xs]=lsim(sys,ustep,t2);
    
    %    plot(ts,xs(:,n_dim*N+1:2*N*n_dim))
    
    rangef1=n_dim*(N-1)+1:n_dim*N;
    figure
    plot(ts,xs(:,rangef(n+1:2*n)))
    %   plot(ts,xs(:,1:n_dim))
    hold on
    title('State History for step input')
    %     figure
    %     hold on
    %     plot(ts,u)
    %     plot(ts,ys)
    %     title('Disturbance and Regulated Output for sinc disturbance')
    %
   

end












