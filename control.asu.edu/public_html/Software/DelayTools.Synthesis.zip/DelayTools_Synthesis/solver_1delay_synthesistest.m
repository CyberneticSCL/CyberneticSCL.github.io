

% Enter values of the delay tau(1), ..., tau(K)
clear all,close all
% A0=[0 1;-2 0.1];
% A{1}=[0 0;1 0];
% B0=[1 ; 1];
% tau(1)=1;

A0=[0 0;0 1];
A{1}=[-2 -.5;0 -1];
B0=[0;1];
tau(1)=5;
% 

% A0=[0 0;0 1];
% A{1}=[-1 -1;0 -.9];
% B0=[0;1];
% tau(1)=12;

% uncontrollable system
% A0=[0 0;0 0];
% A{1}=[-2 0;0 -1];
% B0=[0;1];
% tau(1)=50;

% A0=0;
% A{1}=-1;
% B0=1;
% tau(1)=30;

% Enter degree of accuracy - must be an even integer
orderth =2;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% internal variables:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%fact=1/tau;
fact=1/5;           % conditioning multiplier
eps1=.1;           % strictness of lyapunov positivity
eps2=.1;           % strictness of derivative negativity

% control inputs to SeDuMi 
pars.alg=2;
pars.stepdif=1;
pars.eps=10^(-10);
pars.maxiter=100;
pars.cg.maxiter=200;
pars.cg.qprec=1;
pars.cg.stagtol=1e-22;
pars.cg.restol=5e-5;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% internal processing:
pvar th ksi
n_dim=length(A0);
m_dim=size(B0,2);
h=tau(1);

% declare lots of symbolic variables
vartablex=[];
vartablexth=[];
vartablexksi=[];
vartabled=[];
for i=1:n_dim
    eval(['pvar x',int2str(i),' x',int2str(i),'th x',int2str(i),'ksi']);
    eval(['pvar x',int2str(i),'d']);
    eval(['vartablex=[vartablex, x',int2str(i),'];'])
    eval(['vartablexth=[vartablexth, x',int2str(i),'th];'])
    eval(['vartablexksi=[vartablexksi, x',int2str(i),'ksi];'])
    eval(['vartabled=[vartabled,x',int2str(i),'d];']);
end

mastervartable=[tau,th,ksi,vartablex,vartablexth,vartablexksi,vartabled];

prog = sosprogram(mastervartable);

% local positivity regions:
g{1}=th*(th+tau(1));            %negative on interval [-\tau,0]



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% phase 1 - variables %%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% we will need to declare variables:
% P, Q(th), S(th), R(th,ksi)
%
disp('Creating Lyapunov Variables')
%[prog,P] = sossymmatrvar_p(prog,monomials(th,0),[n_dim]);
%[prog,Q] = sosmatrvar_p(prog,monomials([fact*th],0:orderth),[n_dim,n_dim]);
[prog,Q1] = sossymmatrvar_p(prog,monomials([fact*th],0:orderth),[n_dim]);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% phase 1 - controller Variables %%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

disp('Controller Synthesis Variables')
%[prog,P] = sossymmatrvar_p(prog,monomials(th,0),[n_dim]);
[prog,Z0] = sosmatrvar_p(prog,monomials([fact*th],0:0),[m_dim,n_dim]);
[prog,Z1] = sosmatrvar_p(prog,monomials([fact*th],0:0),[m_dim,n_dim]);
[prog,Z2] = sosmatrvar_p(prog,monomials([fact*th],0:orderth),[m_dim,n_dim]);





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Step2 %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% we first construct the variable R
% First declare a monomial basis for R
disp('Using Mercer Kernels')

Z=monomials([fact*th],0:orderth);

nZ=length(Z);
bigZ1=[];
for i=1:n_dim
    bigZ1=blkdiag(bigZ1,Z);
end
% This creates a positive semidefinite matrix variable of size 4nZ*4nZ, where
% nZ is the length of the monomial basis
[prog,L]=sosposmatr_p(prog,n_dim*nZ);

% Now equate the block os the matrix to pieces of Rij


LeftZ{1}=bigZ1;
RightZ{1}=subs(LeftZ{1},th,ksi);

Q2=LeftZ{1}.'*L*RightZ{1};


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% moved the positivity constraints here
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

P=h*subs(subs(Q2,ksi,0),th,0) +subs(Q1,th,0);


%Now declare first spacing functions
disp('Using Spacing Functions')

[prog,U] = sossymmatrvar_p(prog,monomials([fact*th],0:orderth),[n_dim]);

U_constr=int_p(vartablex*U*vartablex.',th,-tau(1),0);


% Implementation 1
prog = soseq(prog,U_constr);


% now constrain P,Q,S in H1
vartable1=[vartablex vartablexth];

poly=vartable1*([P+U,h*subs(Q2,ksi,0).'; h*subs(Q2,ksi,0) Q1])*vartable1.';

%poly2=vartable1*([P+U2 tau*Q2;tau*Q2.' tau*S2])*vartable1.';

% local positivity multipliers, s1 and s2
zzn=th*zeros(n_dim,n_dim);

if orderth>0
        [prog,bigs] = sosposmatrvar_p(prog,2*n_dim,orderth,[th]);
else
        bigs=blkdiag(zzn,zzn);   
end


% constraint P,Q,S in H1 strictly

extras=vartablex*vartablex.';


   tempcon = -eps1*extras+poly+vartable1*(bigs*g{1})*vartable1.';
   prog = sosineq(prog,tempcon,'sparsemultipartite',{vartable1,[th]});



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% phase 2 - derivatives %%%%%%%%%%%%%%%%%%%%
%%%%%%% Step1 %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% the derivative matrices are spelled out in the paper, they are 
disp('constructing Derivatives')
%Q200=subs(subs(Q2,ksi,0),th,0);
S11 = A0*P+h*A{1}*subs(subs(Q2,th,-h),ksi,0)+subs(Q1,th,0)/2/h;
S12 = A{1}*subs(Q1,th,-h); S21 = S12.';
S22 = -subs(Q1,th,-h)/h;
S13 = h*A0*subs(subs(Q2,th,0),ksi,th) + h*A{1}*subs(subs(Q2,th,-h),ksi,th) + h*diff(subs(Q2.',ksi,0),th);
S31 = S13.';

L11 = B0*Z0;
L12 = B0*Z1;
L13 = h*B0*Z2;
% 
% D11=th*zeros(n_dim*2,n_dim*2);
% D11(1:n_dim,1:n_dim)=S11+S11.'+ L11+L11.';
% D11(1:n_dim,n_dim+1:2*n_dim)=S12 + L12;
% D11(n_dim+1:2*n_dim,1:n_dim)=S21 ;
% D11(n_dim+1:2*n_dim,n_dim+1:2*n_dim)=S22;
% 
%     
%     % define D_12{i}
%     D12=[S13+L13;th*zeros(n_dim,n_dim)];
%     D22=diff(Q1,th);
%     Dt=[D11 D12;D12.' D22];

Dt = [S11+S11.'+L11+L11.'   S12+L12                 S13+L13;
      S21+L12.'             S22                     th*zeros(n_dim,n_dim);
      S31+L13.'             th*zeros(n_dim,n_dim)   diff(Q1,th)];
    
   G=-diff(Q2,th)-diff(Q2,ksi);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Step2 %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Enforce negativity of D 
disp('enforcing negativity of derivative')
%Now declare first spacing functions
disp('Using Spacing Functions')


vartablexxd=[vartablex vartabled];

[prog,T] = sossymmatrvar_p(prog,monomials([fact*th],0:orderth),[2*n_dim]);

T_constr=int_p(vartablexxd*T*vartablexxd.',th,-tau(1),0);

% Implementation 1
prog = soseq(prog,T_constr);

% now constrain -D_i+T_i in H1
vartable2=[vartablexxd vartablexth];
Tfull=blkdiag(T,zzn);
newpoly=vartable2*(Tfull-Dt)*vartable2.';

if orderth>0
    
    [prog,newbigs] = sosposmatrvar_p(prog,3*n_dim,orderth-2,[th]);
    
else
    newbigs=sym(zeros(3*n_dim,3*n_dim)); 
end

   tempcon = -eps2*extras+newpoly+vartable2*(newbigs*g{1})*vartable2.';
   prog = sosineq(prog,tempcon,'sparsemultipartite',{vartable2,[th]});


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Step3 %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Enforce positivity of G
disp('Using Mercer Kernels')

% Now equate the block os the matrix to pieces of M
vartableL=vartablexth;%=[x1th, x2th];
vartableR=vartablexksi;%=[x1ksi,x2ksi];

% Now equate the block os the matrix to pieces of M
[prog,L2]=sosposmatr_p(prog,n_dim*nZ);

        M=LeftZ{1}.'*L2(1:n_dim*nZ,1:n_dim*nZ)*RightZ{1};
        pmin_temp=vartableL*(M-G)*vartableR.';
        prog = soseq( prog , pmin_temp); 

disp('Computing Solution')
prog = sossolve(prog);







