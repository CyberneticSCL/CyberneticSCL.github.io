function s = p2s_mat(p)


for i=1:size(p,1)
    for j=1:size(p,2)
        s(i,j) = p2s_p(p(i,j));
    end
end
