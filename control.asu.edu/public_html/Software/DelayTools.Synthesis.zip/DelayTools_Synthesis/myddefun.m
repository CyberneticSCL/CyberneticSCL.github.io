function dydt = myddefun(t,y,Z)
% requires access to K0 K1 K2, B, A0, A{1} lags

global K0 K1 K2 mylags
syms th2

npoints = length(mylags);
A0=[0 0;0 1];
A{1}=[-2 -.5;0 -1];
B0=[0;1];
%interval = tau(1)/100;
%lags=[0:interval:tau(1)];
integral=(mylags(1)-0)*subs(K2,th2,mylags(1))*Z(:,1);
for i=2:npoints
    integral=integral+(mylags(i)-mylags(i-1))*subs(K2,th2,mylags(i))*Z(:,i);
end
%dydt = double((A0)*y+(A{1})*Z(:,size(Z,2)));
dydt = double((A0+B0*K0)*y+(A{1}+B0*K1)*Z(:,size(Z,2))+B0*integral);
t
double([y Z(:,size(Z,2)) double(A0+B0*K0)*y (A{1}+B0*K1)*Z(:,size(Z,2)) B0*integral])
