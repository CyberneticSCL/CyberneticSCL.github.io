
% This is a subroutine to invert the operator and obtain the controller K=Z
% P^{-1}.
% The data we need to input are the positive multiplier function M(s) and
% the positive matrix which defines the kernel function N(s,t)= Z(s)QZ(t)
syms th2
NM = sosgetsolmat(prog,Q1,5);
NL = sosgetsolmat(prog,L,5);
K = sosgetsolmat(prog,tau(1)*subs(Q2,ksi,0),5);
NZ0 = sosgetsolmat(prog,Z0,5);
NZ1 = sosgetsolmat(prog,Z1,5);
NZ2 = sosgetsolmat(prog,Z2,5);
% Now convert to symbolic form

NL_sym=p2s_mat(NL);
NM_sym=p2s_mat(NM);
K_sym=p2s_mat(K);
NZ0_sym=p2s_mat(NZ0);
NZ1_sym=p2s_mat(NZ1);
NZ2_sym=p2s_mat(NZ2);

bigZ1_sym=p2s_mat(bigZ1);
Zth_sym = p2s_mat(monomials(th,0:length(NM_sym)-1));
% Export Variables to MuPad
nb=mupad('inverting_operators_scalar.mn');
setVar(nb,NL_sym)
setVar(nb,NM_sym)
setVar(nb,K_sym)
setVar(nb,'Z0',NZ0_sym)
setVar(nb,'Z1',NZ1_sym)
setVar(nb,'Z2',NZ2_sym)

setVar(nb,Zth_sym)
setVar(nb,bigZ1_sym)
setVar(nb,'n_dim',sym(n_dim))
setVar(nb,'tau',sym(tau(1)))

% Mupad needs Matlab help for polynomial approximation of the rational
% function Minv
orderapp=2; interval = tau(1)/10;
% retrieve the controller from mupad
Minv = getVar(nb,'Minvth2');
for i=1:n_dim
    for j=1:n_dim
        Data1=subs(Minv(i,j),th2,[-tau(1):interval:0]);
        temp=polyfit([-tau(1):interval:0],Data1,orderapp);
        Minv_app(i,j)=poly2sym(temp,'th2');
        clear Data1
    end
end
setVar(nb,Minv_app)

% Now retrieve the Controller:
K0 = getVar(nb,'K0');
K1 = getVar(nb,'K1');
K2 = getVar(nb,'K2');
