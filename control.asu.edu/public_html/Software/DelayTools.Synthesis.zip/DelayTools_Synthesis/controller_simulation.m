%In this script we implement the controller defined by 
% u(t) = K_0 x(t) + K_1 x(t-tau)+int_{-tau}^0 K_2(s)x(t+s)ds





interval = tau(1)/4;
lags=[interval:interval:tau(1)];
mylags=lags;
%npoints = length(lags)
%K_num = subs(K2,th,lags)
history = 3*ones(2,1);
tspan = [0,100];
% K0=sym([-.00599 -1.00149]);
% K1=sym([7.99783 2.99945])
% K2=sym([0 0]);
global K0 K1 K2 mylags

sol = dde23(@myddefun,lags,history,tspan)
fig=plot(sol.x,sol.y)