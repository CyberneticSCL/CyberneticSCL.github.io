function [prog, Mp, N] = sosjointpos_mat_ker_ndelay_parallel_MTNS(prog,n1,n2,d1,d2,var1,var2,I)
%
% SOSJOINTPOS_MAT_KER_test(prog,n1,n2,d1,d2,var1,var2,I) declares the multiplier $M(s)$ and
% kernel part $N(s,t)$ of a positive multiplier+integral operator. The
% multiplier and kernel have the form
%
% M_i(s) = [ Q11        Q12_{:,i}*Z(s) + sum_j Q13_{:,ij} \int_I_j  Z(eta,s)d eta]
%          [ *^T        Z(s)^T Q_22_{ii} Z(s)
% Nij(s,t) = Z(s)^T Q_{23}_{i,ji} Z(s,t) + Z(t,s)^T Q_{32}_{ij,j} Z(t) + sum_k \int_{I_k} Z(ss,s)^T Q_{33}_{ik,jk} Z(ss,t) dss
% Q = [ Q_{11}  Q_{12} Q_{13}]
%     [ Q_{21}  Q_{22} Q_{23}] >0
%     [ Q_{31}  Q_{32} Q_{33}]
% 
% where Z(x)= Z_d1(x) \otimes I_n and Z_d(x) is the vector of monomials in
% variables x of degree d1 or less. Z(x,y) = Z_{d1}(x) \otimes Z_{d2}(x)
% \otimes I_n. If the application is stability of time-delay systems, d1
% will eventually be more or less the degree of the multiplier and d2 more
% or less the degree of the kernel function.
% we recommend setting d2 = d1 to keep the polynomial degrees balanced.

% INPUTS 
%   prog: SOS program to modify.
%   n: dimension of the resulting matrix
%   d1: degree of the multiplier (sort of)
%   d2: degree of the kernel
%   var1: Single pvar corresponding to s in the description
%   var2: Single pvar corresponding to t in the description
%   I = {[l1 u1]},{[l2,u2]},... cell array of intervals of integration
%
% OUTPUT 
%   M{i}: A cell array of functions of var1 valid on the intervals i
%   N{i,j}: A cell array of kernels valid on the intervals I{i} in variable
%   var1 and intervals I{j} in variable var2
%
% NOTES:
% Distributed with DelayTOOLS
% Compatable with MULTIPOLY and SOSTOOLS as of June 2013
% For support, contact M. Peet, Arizona State University at mpeet@asu.edu

if ~isvalid(var1) || ~isvalid(var2)
  error(['vars must be a polynomial variable']);
end
if ~iscell(I)
    error(['I must be a cell array of intervals'])
end

ss=polynomial(1,1,{'ss'},[1 1]);

% These indices allow for parfor implementation of multi-indexed elements
nints=length(I);
ij_iter=0;
niter=nints^2;
for i=1:nints
    for j=1:nints
        ij_iter=ij_iter+1;
        Ic(ij_iter)=i;
        Jc(ij_iter)=j;
    end
end 


% I'm going to construct Z manually so I know where everything is
nZth=d1+1;
Z1degmat = [0:d1]';
Z1coeff = speye(nZth);
Z1varname = var1.varname;
Z1matdim = [nZth 1];
Z1th=polynomial(Z1coeff,Z1degmat,Z1varname,Z1matdim);


% There are two configurations for the degree d2. Probably the most logical one is 
% that for TDS applications, 2d1 ends up as the degree of the multiplier and
% 2d2 as the degree of the kernel. This is the following:
%Z2degmat = [repmat([0:d2]',d1+1,1),vec(repmat(0:d1,d2+1,1))];
Z2degmat = [repmat([0:d1]',d2+1,1),vec(repmat(0:d2,d1+1,1))];
nZthksi=length(Z2degmat);
Z2coeff = speye(nZthksi);
Z2varname = [var1.varname; var2.varname];
Z2matdim = [nZthksi 1];
Z2thksi=polynomial(Z2coeff,Z2degmat,Z2varname,Z2matdim);

% For other applications, however, we may want 2d2 to represent the
% internal variable of integration, in which case we use the following:
% 
% Z2degmat = [repmat([0:d2]',d1+1,1),vec(repmat(0:d1,d2+1,1))];
% % Z2degmat = [repmat([0:d2]',d1+1,1),vec(repmat(0:d1,d2+1,1))];
% nZthksi=length(Z2degmat);
% Z2coeff = speye(nZthksi);
% Z2varname = [var1.varname; var2.varname];
% Z2matdim = [nZthksi 1];
% ZZZthksi=polynomial(Z2coeff,Z2degmat,Z2varname,Z2matdim);


nBZ1=n2*nZth;
nBZ2=n2*nZthksi;


bZ1th=[];
for i=1:n2
    bZ1th=blkdiag(bZ1th,Z1th);
end

bZ2thksi=[];
for i=1:n2
    bZ2thksi=blkdiag(bZ2thksi,Z2thksi);
end



% First Sparsity Structure
sp1=sparse(nBZ1*nints,nBZ1*nints);
for i=1:nints
    sp1(((i-1)*nBZ1+1):i*nBZ1,((i-1)*nBZ1+1):i*nBZ1)=ones(nBZ1);
end

% Second Sparsity Structure
sp2=sparse(nBZ1*nints,nBZ2*nints^2);
for i=1:nints
    for j=1:nints
        irange=((i-1)*nBZ1+1):i*nBZ1; % standard range
        jrange=((j-1)*nBZ2+1+(i-1)*nBZ2*nints):(j*nBZ2+(i-1)*nBZ2*nints); % for every increase in i, we shift by an entire set of intervals
        sp2(irange,jrange)=ones(nBZ1,nBZ2);
    end
end

% Third Sparsity Structure

sp3=sparse(nBZ2*nints^2,nBZ2*nints^2);
%size(sp3)
for i=1:nints
    sp3(((i-1)*nBZ2*nints+1):i*nBZ2*nints,((i-1)*nBZ2*nints+1):i*nBZ2*nints)=ones(nBZ2*nints);
end
%size(sp3)

sp_pat=[ones(n1,n1) ones(n1,size(sp1,2)) ones(n1,size(sp2,2))  ;ones(n1,size(sp1,2))' sp1 sp2;ones(n1,size(sp2,2))' sp2' sp3];
[prog,LLL]=sosposmatr_struct(prog,n1+nBZ1*nints+nBZ2*nints^2,sp_pat);
%[prog,LLL]=sosposmatr(prog,nBZ1*nints+nBZ2*nints^2);

% Construct Q11, Q12, Q13
Q11=LLL(1:n1,1:n1);
%Q12=LLL(1:n1,(n1+1+(i-1)*nBZ1):(n1+i*nBZ1));
%Q13=LLL(1:n1,(nints*nBZ1+1):end);
for i=1:nints
    Q12i=LLL(1:n1,(n1+1+(i-1)*nBZ1):(n1+i*nBZ1));
    M2{i}=Q12i*bZ1th;
    for j=1:nints
        jrange=((j-1)*nBZ2+1+(i-1)*nBZ2*nints):(j*nBZ2+(i-1)*nBZ2*nints);
        Q13ij=LLL(1:n1,(n1+nBZ1*nints+jrange));
        M2{i}=M2{i}+Q13ij*int(var_swap(bZ2thksi,var1,var2),var2,I{j}(1),I{j}(2)); % need to redefine range to match swapped variables.
    end
end


%LLL
parfor i=1:nints
    Ltemp=LLL((n1+1+(i-1)*nBZ1):(n1+i*nBZ1),(n1+1+(i-1)*nBZ1):(n1+i*nBZ1));
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    avarname=[Ltemp.varname; Z1varname];
    % For the next part, we just need the degmat part of the block-diagonal
    % monomial matrix
    
    bZdegmat=repmat(Z1degmat,n2,1);
    
    [PIlist, PJlist]=find(Ltemp.coefficient); % This is the list of terms in P, but PIlist and Pjlist will be relatively short.
    [PIlist2,ttt]=unique(PIlist);
    PJlist2=PJlist(ttt,:);
    
    [Prowu,Pcolu] = ind2sub([n2*nZth n2*nZth],PJlist2); % this returns the matrix locations for every term in P
    adegmat = [Ltemp.degmat(PIlist2,:) bZdegmat(Prowu,:)+bZdegmat(Pcolu,:)];
    
    
    % but now we have to modify the coefficient matrix. We can group this by
    % blocks. For a 2x2 matrix, all the coefficients from block 1 will be [1 0 0 0], all the
    % coefficients from block 2 will be [0 1 0 0], all the coefficients from
    % block 3 will be [0 0 0 1],
    
    % Positions in Pjlist from 1:nZ get reassigned to 1, nZ+1:2nZ -> 2, etc
    [row,col] = ind2sub([n2*nZth n2*nZth],PJlist);
    newrow=ceil(row/nZth);
    newcol=ceil(col/nZth);
    newidx=sub2ind([n2 n2],newrow, newcol);
    
    coeff=sparse(PIlist,newidx,1);
    amatdim=[n2 n2];
    M{i}=polynomial(coeff,adegmat,avarname,amatdim);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %    M{i}=bZ1th'*LLL(((i-1)*nBZ1+1):i*nBZ1,((i-1)*nBZ1+1):i*nBZ1)*bZ1th;
    Mp{i}=[Q11 M2{i}; M2{i}' M{i}];
end
% Kernal Part I
% This is the Z(s)^T Q23 Z(s,t) term
LLL2=LLL((n1+1):(n1+nints*nBZ1),(n1+nints*nBZ1+1):end);
parfor ij=1:niter
        i=Ic(ij);j=Jc(ij);
        irange=((i-1)*nBZ1+1):i*nBZ1; % standard range
        jrange=((j-1)*nBZ2+1+(i-1)*nBZ2*nints):(j*nBZ2+(i-1)*nBZ2*nints); % for every increase in i, we shift by an entire set of intervals
        Ltemp=LLL2(irange,jrange);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        avarname=[Ltemp.varname; Z2varname ];
        % For the next part, we just need the degmat part of the block-diagonal
        % monomial matrix
        if strcmp(var1.varname{1},Z2varname{1}) % var1 is in the first position
            bZdegmat1=repmat([Z1degmat zeros(nZth,1)],n2,1);
        else
            bZdegmat1=repmat([zeros(nZth,1) Z1degmat],n2,1);
        end
        bZdegmat2=repmat(Z2degmat,n2,1);
        
        [PIlist, PJlist]=find(Ltemp.coefficient); % This is the list of terms in P, but PIlist and Pjlist will be relatively short.
        [Prowu,Pcolu] = ind2sub([n2*nZth n2*nZthksi],PJlist); % this returns the matrix locations for every term in P
        adegmat = [Ltemp.degmat(PIlist,:) bZdegmat1(Prowu,:)+bZdegmat2(Pcolu,:)];
        %
        % but now we have to modify the coefficient matrix. We can group this by
        % blocks. For a 2x2 matrix, all the coefficients from block 1 will be [1 0 0 0], all the
        % coefficients from block 2 will be [0 1 0 0], all the coefficients from
        % block 3 will be [0 0 0 1],
        
        % Positions in Pjlist from 1:nZ get reassigned to 1, nZ+1:2nZ -> 2, etc
        [row,col] = ind2sub([n2*nZth n2*nZthksi],PJlist);
        newrow=ceil(row/nZth);
        newcol=ceil(col/nZthksi);
        newidx=sub2ind([n2 n2],newrow, newcol);%(newcol-1)*n+newrow;
        
        nPIlist=(1:length(PIlist))';
        coeff=sparse(nPIlist,newidx,1);
        amatdim=[n2 n2];
        A{ij}=polynomial(coeff,adegmat,avarname,amatdim);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%        clear Ltemp
%       A{i,j}=bZ1th.'*LLL2(irange,jrange)*bZ2thksi;

end
clear LLL2

% Kernal Part II
% This is the Z(t,s)^T Q21 Z(t) term
% for i=1:nints
%     for j=1:nints
%         B{i,j} = subs(subs(subs(A{j,i}.',var1,ss),var2,var1),ss,var2);
%     end
% end


LLL4=LLL((n1+1+nints*nBZ1):end,(n1+1):(n1+nints*nBZ1));
parfor ij=1:niter
        i=Ic(ij);j=Jc(ij);
        irange=((i-1)*nBZ2+1+(j-1)*nBZ2*nints):(i*nBZ2+(j-1)*nBZ2*nints); % for every increase in i, we shift by an entire set of intervals
        jrange=((j-1)*nBZ1+1):j*nBZ1; % standard range
%        LLL2(irange,jrange)
        B{ij}=var_swap(bZ2thksi,var1,var2).'*LLL4(irange,jrange)*subs(bZ1th,var1,var2);
%        A{1,1}(1,1)
end

% Kernal Part III
% This is the int Z(om,s)^T Q22 Z(om,t) term
% bZ2omksi=subs(bZ2thksi,var1,ss);
% bZ2omth=subs(bZ2omksi,var2,var1);

ij_iter2=0;
niter2=nints^3;
for i=1:nints
    for j=1:nints
        for k=1:nints
            ij_iter2=ij_iter2+1;
            Ic2(ij_iter2)=i;   % translates ijk index to i index
            Jc2(ij_iter2)=j;   % translates ijk index to j index
            Kc2(ij_iter2)=k;  % translates ijk index to k index
            IJKc(i,j,k)=ij_iter2; % translates i,j,k indices to ijk indices
        end
    end
end 

LLL3=LLL((n1+nints*nBZ1+1):end,(n1+nints*nBZ1+1):end);
parfor ijk=1:niter2
    i=Ic2(ijk);j=Jc2(ijk);k=Kc2(ijk);
            irange=((i-1)*nBZ2+1+(k-1)*nBZ2*nints):(i*nBZ2+(k-1)*nBZ2*nints);
            jrange=((j-1)*nBZ2+1+(k-1)*nBZ2*nints):(j*nBZ2+(k-1)*nBZ2*nints);
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            Ltemp=LLL3(irange,jrange);
            avarname=[Ltemp.varname; var1.varname; var2.varname; ss.varname{1}];
            %assignin('base',['LLL3',int2str(i),int2str(j),int2str(k)],Ltemp)
            if strcmp(var1.varname{1},Z2varname{1}) % th is in the first position
                bZdegmat1=repmat([Z2degmat(:,2) zeros(nZthksi,1)  Z2degmat(:,1)],n2,1); %bZomth
                bZdegmat2=repmat([zeros(nZthksi,1) Z2degmat(:,2)  Z2degmat(:,1)],n2,1); %bZomksi
            else
                bZdegmat1=repmat([Z2degmat(:,1) zeros(nZthksi,1)  Z2degmat(:,2)],n2,1); %bZomth
                bZdegmat2=repmat([zeros(nZthksi,1) Z2degmat(:,1)  Z2degmat(:,2)],n2,1); %bZomksi
            end
            
            [PIlist, PJlist]=find(Ltemp.coefficient); % This is the list of terms in P, but PIlist and Pjlist will be relatively short.
            [Prowu,Pcolu] = ind2sub([n2*nZthksi n2*nZthksi],PJlist); % this returns the matrix locations for every term in P
            adegmat = [Ltemp.degmat(PIlist,:) bZdegmat1(Prowu,:)+bZdegmat2(Pcolu,:)];
            % but now we have to modify the coefficient matrix. We can group this by
            % blocks. For a 2x2 matrix, all the coefficients from block 1 will be [1 0 0 0], all the
            % coefficients from block 2 will be [0 1 0 0], all the coefficients from
            % block 3 will be [0 0 0 1],
            
            newrow=ceil(Prowu/nZthksi);
            newcol=ceil(Pcolu/nZthksi);
            
            newidx=sub2ind([n2 n2],newrow, newcol);%(newcol-1)*n+newrow;
            nPIlist=(1:length(PIlist))';
            coeff=sparse(nPIlist,newidx,1);
            amatdim=[n2 n2];
            CA{ijk}=polynomial(coeff,adegmat,avarname,amatdim);
end
%            clear Ltemp

parfor ij=1:niter
        CC{ij}=polynomial(zeros(n2,n2));
        for k=1:nints
            CC{ij}=CC{ij}+int(CA{IJKc(Ic(ij),Jc(ij),k)},ss,I{k}(1),I{k}(2));
        end
        NN{ij}=A{ij}+B{ij}+CC{ij};
%         N{i,j}=C{i,j};
       

end



for ij=1:niter
        N{Ic(ij),Jc(ij)}=NN{ij};
end
% for i=1:nints
%     parfor j=1:nints
%         C{i,j}=polynomial(zeros(n,n));
%         for k=1:nints
%             C{i,j}=C{i,j}+int(CA{i,j,k},ss,I{k}(1),I{k}(2));
%         end
%         N{i,j}=A{i,j}+B{i,j}+C{i,j};
% %         N{i,j}=C{i,j};
%        
%     end
% end


