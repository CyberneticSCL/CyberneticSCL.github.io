function [prog, F, H] = sosspacing_mat_ker_ndelay(prog,n1,n2,d1,d2,var1,var2,II)
%
% SOSSPACING_MAT_KER(prog,n,d1,d2,var1,var2,I) declares the multiplier $F(s)$ and
% kernel part $H(s,t)$ of a positive multiplier+integral operator such that
%
% int [c   ] F(s) [c   ] ds + int int [c   ] [ H(s,t) ] [ c  ] ds dt = 0
%     [x(s)]      [x(s)]              [x(s)]            [x(t)]
% where c \in \R^n1 and x \in L_2^n2
% 
% we recommend setting d2 = 2*d1 to keep the polynomial degrees balanced.

% INPUTS 
%   prog: SOS program to modify.
%   n1: dimension of the 1-1 block
%   n2: dimension of the 2-2 block
%   d1: degree of F (even integer is recommended)
%   d2: degree of H (even integer is recommended)
%   var1: Single pvar corresponding to s in the description
%   var2: Single pvar corresponding to t in the description
%   I = {[l1 u1]},{[l2,u2]},... cell array of intervals of integration
%
% OUTPUT 
%   F{i}: A cell array of functions of var1 valid on the intervals i
%   H{i,j}: A cell array of kernels valid on the intervals I{i} in variable
%   var1 and intervals I{j} in variable var2
%
% NOTES:
% Distributed with DelayTOOLS
% Compatable with MULTIPOLY and SOSTOOLS as of April 2016
% For support, contact M. Peet, Arizona State University at mpeet@asu.edu

if ~isvalid(var1) || ~isvalid(var2)
  error(['vars must be a polynomial variable']);
end
if ~iscell(II)
    error(['I must be a cell array of intervals'])
end

% The number of domains of integration
nints=length(II);

zzn1=polynomial(zeros(n1,n1));
zzn12=polynomial(zeros(n1,n2));
zzn2=polynomial(zeros(n2,n2));

Ztemp1=monomials([var1],0:d1);
Ztemp2=monomials(monomials([var1],0:floor(d2/2))*monomials([var2],0:floor(d2/2)).');


Kint=zzn1;
for i=1:nints
    [prog,K{i}] = sossymmatrvar(prog,Ztemp1,[n1]);
    Kint=Kint+int(K{i},var1,II{i}(1),II{i}(2));
    for j=1:nints
        [prog,L11{i,j}] = sosmatrvar(prog,Ztemp2,[n1,n1]);
        [prog,L12{i,j}] = sosmatrvar(prog,Ztemp2,[n1,n2]);
        [prog,L21{i,j}] = sosmatrvar(prog,Ztemp2,[n2,n1]);
    end
end
[prog]=sosmateq(prog,Kint);

% for i=1:nints
%     for j=1:nints
%         L21{i,j}=var_swap(L12{j,i}.',var1,var2);
%     end
% end

Lint11=zzn1;
for i=1:nints
    for j=1:nints
        Lint11=Lint11+int(int(L11{i,j},var1,II{i}(1),II{i}(2)),var2,II{j}(1),II{j}(2));
    end
end

for i=1:nints
    Lint12{i}=zzn12;
    Lint21{i}=zzn12.';
    for j=1:nints
        Lint12{i}=Lint12{i}+subs(int(L12{j,i},var1,II{j}(1),II{j}(2)),var2,var1);
        Lint21{i}=Lint21{i}+int(L21{i,j},var2,II{j}(1),II{j}(2));
    end
end
% for i=1:nints
%     for j=1:nints
%         Lint21{j}=Lint12{i}.';
%     end
% end


 
 
 % assign all variables
 for i=1:nints
    F{i} = [K{i}+Lint11/norm(II{nints}(1)) Lint12{i}; Lint21{i} zzn2];
    for j=1:nints
        H{i,j} = -[L11{i,j} L12{i,j};L21{i,j} zzn2];
    end
end