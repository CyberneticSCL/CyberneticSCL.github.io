% SOSTOOLS --- Sum of Squares Toolbox
% Version 2.04, 12 August 2010.
%
% Monomial vectors construction:
%    MONOMIALS   --- Construct a vector of monomials with prespecified 
%                    degrees.
%    MPMONOMIALS --- Construct a vector of multipartite monomials with
%                    prespecified degrees.
%
% General purpose sum of squares program (SOSP) solver:
%    SOSPROGRAM  --- Initialize a new SOSP.
%    SOSDECVAR   --- Declare new decision variables in an SOSP. 
%    SOSPOLYVAR  --- Declare a new polynomial variable in an SOSP.
%    SOSSOSVAR   --- Declare a new sum of squares variable in an SOSP.
%    SOSEQ       --- Add a new equality constraint to an SOSP.
%    SOSINEQ     --- Add a new inequality constraint to an SOSP.
%    SOSSETOBJ   --- Set the objective function of an SOSP.
%    SOSSOLVE    --- Solve an SOSP.
%    SOSGETSOL   --- Get the solution from a solved SOSP.
%
% Customized functions:
%    FINDSOS     --- Find a sum of squares decomposition of a given polynomial.
%    FINDLYAP    --- Find a Lyapunov function for a dynamical system.
%    FINDBOUND   --- Find a global/constrained lower bound for a polynomial.
% 
% Demos:
%    SOSDEMO1 and SOSDEMO1P   --- Sum of squares test.
%    SOSDEMO2 and SOSDEMO2P   --- Lyapunov function search.
%    SOSDEMO3 and SOSDEMO3P   --- Bound on global extremum.
%    SOSDEMO4 and SOSDEMO4P   --- Matrix copositivity.
%    SOSDEMO5 and SOSDEMO5P   --- Upper bound for the structured singular value mu.
%    SOSDEMO6 and SOSDEMO6P   --- MAX CUT.
%    SOSDEMO7    --- Chebyshev polynomials.
%    SOSDEMO8    --- Bound in probability.
%
% Copyright (C)2002, 2004  S. Prajna (1), A. Papachristodoulou (1), P. Seiler (2),
%                          P. A. Parrilo (3)
% (1) Control and Dynamical Systems - California Institute of Technology,
%     Pasadena, CA 91125, USA.
% (2) Mechanical and Industrial Engineering Department - University of Illinois 
%     Urbana, IL 61801, USA
% (3) Institut fur Automatik - ETH Zurich, CH-8092 Zurich, Switzerland.
%
% Send bug reports and feedback to: sostools@cds.caltech.edu
%

% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 2 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
%
