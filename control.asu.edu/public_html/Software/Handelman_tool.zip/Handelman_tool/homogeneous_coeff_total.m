function out = homogeneous_coeff_total(deg,n_states)

out = length(homopoly(n_states,deg));