function lexhnh = homog_lex_index(alfa)

deg = sum(alfa);
n = length(alfa);


lexnh =  lex_index(alfa,n,deg);
