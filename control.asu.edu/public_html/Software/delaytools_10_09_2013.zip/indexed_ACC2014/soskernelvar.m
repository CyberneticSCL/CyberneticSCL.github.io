function [prog, N] = soskernelvar(prog,n,d,var1,var2)
%SOSKERNELVAR(prog,n,d,var1,var2) 
% declares a bivariate n x n matrix-valued polynomial in variables vars1 and
% vars2 of degree d or less. The variable is of form Z_nd(var1)^T P Z_nd(var2)
% where Znd(x)= Z_d(x) \otimes I_n and Z_d(x) is the vector of monomials in
% variables x of degree d or less. Note the length of vars1 and vars2 must
% be the same
%
% Note: The degree of the variable will be 2*d
%
% Inputs: 
% prog - The SOSprogram to which to attach the variable
% n - the dimension of the resulting kernel matrix
% d - The degree of the resulting kernel will be 2d (d in each variable)
% var1 - a POLYNOMIAL variable which will appear in the kernel
% var2 - The other POLYNOMIAL variable
%
% NOTES:
% Distributed with DelayTOOLS
% Compatable with MULTIPOLY and SOSTOOLS as of June 2013
% For support, contact M. Peet, Arizona State University at mpeet@asu.edu




Z=monomials(var1,0:d);
bigLZ=[];
for i=1:n
    bigLZ=blkdiag(bigLZ,Z);
end
bigRZ=subs(bigLZ,var1,var2);
% We have constructed Z_nd(var1) = bigLZ; Z_nd(var2) = bigRZ
% Now create the kernel variable N = Z_nd(var1)^T P Z_nd(var2);
nBZ=length(bigLZ);
[prog,L]=sosmatrvar(prog,polynomial(1),[nBZ nBZ]);
N=bigLZ'*L*bigRZ;

end

