function [Z]=monomials_mp(vars,ords);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% MatrixTools - monomials_mp
%
% usage: [Z]=monomials_mp(vars,ords)
%
% This function takes as inputs, a list of variables, v, and a list of
% degrees, d, and returns a list of all monomials which contain the
% variables v_i at degree d_i or less
%
% e.g. vars={x, y}, ords=[1, 3] returns
% Z=[1 x y xy y^2 xy^2 y^3 xy^3]
%
% inputs: 
% vars - list of symbolic variables
% ords - vector of positive integers of same length as vars
%
%
% version .03   M. Peet, matthew.peet@inria.fr
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Z=[1];
for i=1:length(ords)
    Z=kron(Z,monomials(vars{i},0:ords(i)));
end