

% Enter values of the delay tau(1), ..., tau(K)
clear all,close all
%A0=[0 1;-2 0.1];
%A{1}=[0 0;1 0];
A0=0;
A{1}=-1;
tau(1)=.79;

% Enter degree of accuracy - must be an even integer
orderth =10;
ordernu = 6;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% internal variables:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%fact=1/tau;
fact=1;           % conditioning multiplier
eps1=.01;           % strictness of lyapunov positivity
eps2=0;           % strictness of derivative negativity

% control inputs to SeDuMi 
pars.alg=2;
pars.stepdif=1;
pars.eps=10^(-10);
pars.maxiter=100;
pars.cg.maxiter=200;
pars.cg.qprec=1;
pars.cg.stagtol=1e-22;
pars.cg.restol=5e-5;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% internal processing:
pvar th ksi
n_dim=length(A0);
h=tau(1);

% declare lots of symbolic variables
vartablex=[];
vartablexth=[];
vartablexksi=[];
vartabled=[];
for i=1:n_dim
    eval(['pvar x',int2str(i),' x',int2str(i),'th x',int2str(i),'ksi']);
    eval(['pvar x',int2str(i),'d']);
    eval(['vartablex=[vartablex, x',int2str(i),'];'])
    eval(['vartablexth=[vartablexth, x',int2str(i),'th];'])
    eval(['vartablexksi=[vartablexksi, x',int2str(i),'ksi];'])
    eval(['vartabled=[vartabled,x',int2str(i),'d];']);
end

mastervartable=[tau,th,ksi,vartablex,vartablexth,vartablexksi,vartabled];

prog = sosprogram(mastervartable);

% local positivity regions:
g{1}=th*(th+tau(1));            %negative on interval [-\tau,0]



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% phase 1 - variables %%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% we will need to declare variables:
% P, Q(th), S(th), R(th,ksi)
%
disp('Creating Lyapunov Variables')
%[prog,P] = sossymmatrvar(prog,monomials(th,0),[n_dim]);
%[prog,Q] = sosmatrvar(prog,monomials([fact*th],0:orderth),[n_dim,n_dim]);
[prog,M2] = sossymmatrvar(prog,monomials([fact*th],0:orderth),[n_dim]);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Step2 %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% we first construct the variable R
% First declare a monomial basis for R
disp('Using Mercer Kernels')

Z=monomials([fact*th],0:orderth);

nZ=length(Z);
bigZ1=[];
for i=1:n_dim
    bigZ1=blkdiag(bigZ1,Z);
end
% This creates a positive semidefinite matrix variable of size 4nZ*4nZ, where
% nZ is the length of the monomial basis

% Now equate the block os the matrix to pieces of Rij


LeftZ{1}=bigZ1;
RightZ{1}=subs(LeftZ{1},th,ksi);

%sos_semisep_poskernel(prog,n_dim,((orderth-ordernu)/2),ordernu,th,ksi,[-tau,0]);
[prog, M3, M4] = sos_semisep_poskernel(prog,n_dim,((orderth-ordernu)/2),ordernu,th,ksi,[-h,0]);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% moved the positivity constraints here
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

P=h*subs(subs(M3,ksi,0),th,0) +subs(M2,th,0);


%Now declare first spacing functions
disp('Using Spacing Functions')

[prog,U] = sossymmatrvar(prog,monomials([fact*th],0:orderth),[n_dim]);

U_constr=int(vartablex*U*vartablex.',th,-tau(1),0);


% Implementation 1
prog = soseq(prog,U_constr);


% now constrain P,Q,S in H1
vartable1=[vartablex vartablexth];

poly=vartable1*([P+U,h*subs(M4,ksi,0).'; h*subs(M4,ksi,0) M2])*vartable1.';

%poly2=vartable1*([P+U2 tau*M3;tau*M3.' tau*S2])*vartable1.';

% local positivity multipliers, s1 and s2
zzn=th*zeros(n_dim,n_dim);

if orderth>0
        [prog,bigs] = sosposmatrvar(prog,2*n_dim,orderth,[th]);
else
        bigs=blkdiag(zzn,zzn);   
end


% constraint P,Q,S in H1 strictly

extras=vartablex*vartablex.';


   tempcon = -eps1*extras+poly+vartable1*(bigs*g{1})*vartable1.';
   prog = sosineq(prog,tempcon,'sparsemultipartite',{vartable1,[th]});



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% phase 2 - derivatives %%%%%%%%%%%%%%%%%%%%
%%%%%%% Step1 %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% the derivative matrices are spelled out in the paper, they are 
disp('constructing Derivatives')
%Q200=subs(subs(M3,ksi,0),th,0);
S11 = A0*P+h*A{1}*subs(subs(M3',th,0),ksi,-h)+subs(M2,th,0)/2/h;
S12 = A{1}*subs(M2,th,-h); S21 = S12.';
S22 = -subs(M2,th,-h)/h;
S13 = h*A0*subs(subs(M3,th,0),ksi,th) + h*A{1}*subs(subs(M4,th,-h),ksi,th) + h*diff(subs(subs(M3,th,0),ksi,th),th);
S31 = S13.';

D11=th*zeros(n_dim*2,n_dim*2);
D11(1:n_dim,1:n_dim)=S11+S11.';
D11(1:n_dim,n_dim+1:2*n_dim)=S12;
D11(n_dim+1:2*n_dim,1:n_dim)=S21;
D11(n_dim+1:2*n_dim,n_dim+1:2*n_dim)=S22;

    
    % define D_12{i}
    D12=[S13;th*zeros(n_dim,n_dim)];
    D22=diff(M2,th)+2*subs(M3-M4,ksi,th);
    Dt=[D11 D12;D12.' D22];
    
   G1=-diff(M3,th)-diff(subs(subs(subs(M4',th,x1th),ksi,th),x1th,ksi),th);
   G2=-diff(M4,th)-diff(subs(subs(subs(M3',th,x1th),ksi,th),x1th,ksi),th);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Step2 %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Enforce negativity of D 
disp('enforcing negativity of derivative')
%Now declare first spacing functions
disp('Using Spacing Functions')


vartablexxd=[vartablex vartabled];

[prog,T] = sossymmatrvar(prog,monomials([fact*th],0:orderth),[2*n_dim]);

T_constr=int(vartablexxd*T*vartablexxd.',th,-tau(1),0);

% Implementation 1
prog = soseq(prog,T_constr);

% now constrain -D_i+T_i in H1
vartable2=[vartablexxd vartablexth];
Tfull=blkdiag(T,zzn);
newpoly=vartable2*(Tfull-Dt)*vartable2.';

if orderth>0
    
    [prog,newbigs] = sosposmatrvar(prog,3*n_dim,orderth-2,[th]);
    
else
    newbigs=sym(zeros(3*n_dim,3*n_dim)); 
end

   tempcon = -eps2*extras+newpoly+vartable2*(newbigs*g{1})*vartable2.';
   prog = sosineq(prog,tempcon,'sparsemultipartite',{vartable2,[th]});


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Step3 %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Enforce positivity of G
disp('Using Mercer Kernels')

% Now equate the block os the matrix to pieces of M
vartableL=vartablexth;%=[x1th, x2th];
vartableR=vartablexksi;%=[x1ksi,x2ksi];




[prog, kernDp1, kernDp2] = sos_semisep_poskernel(prog,n_dim,((orderth-ordernu)/2),ordernu,th,ksi,[-h,0]);


%  vartableL=[x1th, x2th];
%  vartableR=[x1ksi,x2ksi];
% 
 pmin1=vartableL*(kernDp1-G1)*vartableR.';
 pmin2=vartableL*(kernDp2-G2)*vartableR.';
disp('running equalities')
% prog=soseq(prog,kernDp1(1,1)-kernD1(1,1));
% prog=soseq(prog,kernDp1(1,2)-kernD1(1,2));
% prog=soseq(prog,kernDp1(2,1)-kernD1(2,1));
% prog=soseq(prog,kernDp1(2,2)-kernD1(2,2));
% prog=soseq(prog,kernDp2(1,1)-kernD2(1,1));
% prog=soseq(prog,kernDp2(1,2)-kernD2(1,2));
% prog=soseq(prog,kernDp2(2,1)-kernD2(2,1));
% prog=soseq(prog,kernDp2(2,2)-kernD2(2,2));
prog = soseq( prog , pmin1);
prog = soseq( prog , pmin2);

% % Now equate the block os the matrix to pieces of M
% [prog,L2]=sosposmatr(prog,n_dim*nZ);
% 
%         M=LeftZ{1}.'*L2(1:n_dim*nZ,1:n_dim*nZ)*RightZ{1};
%         pmin_temp=vartableL*(M-G)*vartableR.';
%         prog = soseq( prog , pmin_temp); 

disp('Computing Solution')
prog = sossolve(prog);
