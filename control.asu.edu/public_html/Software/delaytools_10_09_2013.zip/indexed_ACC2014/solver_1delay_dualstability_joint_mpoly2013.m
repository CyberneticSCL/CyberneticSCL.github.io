clear all; close all; clear classes
total=tic;
%% Welcome to DelayTools
% This script uses a dual formulation to test the exponential stability of a
% linear differential equation with discrete delays of the form:
%
% $\dot x(t)=A0 x(t) + A\{1\}x(t-\tau(1))$.
%
% The matrices $A0$ and $A\{1\}$ must be square but may be of any
% dimension. The delay $\tau(1)$ must be a positive real number. These three
% entries should be entered now:
%%
% A0=[-1 0 0;0 0 1;0  -2 .1];
% A{1}=[0 0 0; 0 0 0;0 1 0];
% %  A0=[0 1;  -2 .1];
% %  A{1}=[ 0 0; 1 0];
%  tau(1)=1.71;
 A0=0;%[-1 0; 0 0];
 A{1}=-1;%[0 0;0 -1];
 tau(1) = 1%.57079;

%% Output
% The only output from the code is the Sedumi script. To determine whether
% the system is stable, examine the columns feas and prec. Ideally,
% feas=1.00 and prec<1E-10. However, these numbers may become fuzzy around
% the limit of accuracy. To reconstruct the Lyapunov function, use the
% command sosgetsol to retrieve the functions $Q1$ and $Q2$ which define
% the Lyapunov functional as described in <http://control.asu.edu>

 %% Accuracy Parameters
 % In addition to the system, we ask you to enter certain parameters which
 % determine the degree of the polynomial variables. Specifically, choose 
%%

orderth = 4;

%%
% We recommend values between 2 and 6. However, the number MUST be even.
% (odd polynomial are not positive). For normal systems, an orderth of 2
% will probably achieve accuracy out to two or three decimals.
%
% In addition, bevause this code uses joint positivity in order to avoid 
% conservativity, we also give you the option to choose the internal degree
% of this construct. Gerenally, we recommend ordernu=orderth so that all
% the polynomial degrees are balanced. However, you may reduce this
% variable to improve run-time.

ordernu=4;

%% Internal Parameters
% There are several internal parameters you can tweak if interested. The
% first defines how positive the Lyapunov functional must be. 

eps1=.1;

% The second Lyapunov parameter determines if the derivative must also be
% strictly negative. Use this parameter if you want to determine the rate
% of decay of the system.

eps2=0;

% Next, if you are using our modified version of SOSTOOLS, you can use the
% following to adjust the SDP parameters in SeDuMi

% control inputs to SeDuMi 
pars.alg=2;
pars.stepdif=1;
pars.eps=10^(-10);
pars.maxiter=100;
pars.cg.maxiter=200;
pars.cg.qprec=1;
pars.cg.stagtol=1e-22;
pars.cg.restol=5e-5;

%% The Code
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% internal variables:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eps=eps1;
fact=1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% internal processing:
h=tau;
tic
pvar th ksi
g1=th*(th+tau);            %negative on interval [-\tau,0]

n_dim=length(A0);
n_delay=length(tau);
tauK=tau(n_delay);

% declare lots of symbolic variables
vartablex=[];
vartablexth=[];
vartablexksi=[];
for j=1:n_delay
    eval(['vartabled',int2str(j),'=[];'])
end   
for i=1:n_dim
    eval(['pvar x',int2str(i),' x',int2str(i),'th x',int2str(i),'ksi']);
    eval(['vartablex=[vartablex, x',int2str(i),'];'])
    eval(['vartablexth=[vartablexth, x',int2str(i),'th];'])
    eval(['vartablexksi=[vartablexksi, x',int2str(i),'ksi];'])
    for j=1:n_delay
        eval(['pvar x',int2str(i),'d',int2str(j)]);
        eval(['vartabled',int2str(j),'=[vartabled',int2str(j),', x',int2str(i),'d',int2str(j),'];'])
    end        
end
mastervartable=[th,ksi,vartablex,vartablexth,vartablexksi];
for j=1:n_delay
    eval(['mastervartable=[mastervartable, vartabled',int2str(j),'];'])
end 


% local positivity regions:
g{1}=th*(th+tau(1));            %negative on interval [-\tau,0]
for i=2:n_delay
    g{i}=(th+tau(i))*(th+tau(i-1));%negative on interval [-tau_i,-\tau_i-1]
end

Z=monomials([fact*th],0:orderth);
nZ=length(Z);
bigZ1=[];
for i=1:n_dim
    bigZ1=blkdiag(bigZ1,Z);
end

extras=vartablex*vartablex.';
delta(1) = tau(1);
for i=2:n_delay 
    delta(i)=tau(i)-tau(i-1);
end
LeftZ{1}=subs(bigZ1,th,tauK/delta(1)*th+0*tauK/delta(1));
RightZ{1}=subs(LeftZ{1},th,ksi);
for i=2:n_delay
    delta(i)=tau(i)-tau(i-1);
    LeftZ{i}=subs(bigZ1,th,tauK/delta(i)*th+tau(i-1)*tauK/delta(i));
    RightZ{i}=subs(LeftZ{i},th,ksi);
end
 vartablexxd=[vartablex];
 for i=1:n_delay
     eval(['vartablexxd=[vartablexxd vartabled',int2str(i),'];'])
 end
vartable1=[vartablex vartablexth];
vartable2=[vartablexxd vartablexth];

 vartableL=vartablexth;%=[x1th, x2th];
 vartableR=vartablexksi;%=[x1ksi,x2ksi];

prog = sosprogram(mastervartable);

% local positivity regions:
g{1}=th*(th+tau(1));            %negative on interval [-\tau,0]


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% phase 1 - variables %%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% we will need to declare variables:
% P, Q(th), S(th), R(th,ksi)
%
disp('Some overhead, elapsed time:')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Step2 %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[prog,Q1] = sossymmatrvar(prog,monomials([fact*th],0:orderth),[n_dim]);
[prog,Q2as] = sosmatrvar(prog,monomials([th,ksi],0:orderth),[n_dim n_dim]);
Q2=.5*(Q2as+subs(Q2as.',[th;ksi],[ksi;th])); %mod for new pvar
%Q2=.5*(Q2as+subs(Q2as.',{th,ksi,x1},{x1,th,ksi}));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% thing to constrain positivity of 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Q1=Q1*0
bigP=[h*subs(subs(Q2,ksi,0),th,0)+subs(Q1,th,0), h*subs(Q2,[th;ksi],[0;th]); h*subs(Q2,ksi,0) Q1]; %mod for new pvar

toc
%Now declare first spacing functions
disp('creating joint positive operator variable')
tic
[prog, M, N] = sosjointpos_mat_ker(prog,2*n_dim,orderth/2,ordernu/2,th,ksi,[-tau(1),0]);
toc
disp('manipulating variables, elapsed time:')
tic

N11=N(1:n_dim,1:n_dim);
N12=N(1:n_dim,(n_dim+1):2*n_dim);
N21=N((n_dim+1):2*n_dim,1:n_dim);
N22=N((n_dim+1):2*n_dim,(n_dim+1):2*n_dim);

Mex11=1/tau*int(int(N11,th,-tau,0),ksi,-tau,0);
Mex12=subs(int(N12,th,-tau(1),0),ksi,th);
Mex21=int(N21,ksi,-tau(1),0);


% local positivity multipliers, s1 and s2
if orderth>0
        [prog,bigS] = sosposmatrvar(prog,2*n_dim,orderth-2,[th]);
else
   bigS = 0;
end

% Mp=M+[Mex11+eps1*speye(n_dim),  Mex12; Mex21, zeros(n_dim,n_dim)]-g{1}*bigS;
% 
% Mp11=Mp(1:n_dim,1:n_dim);
% Mp12=Mp(1:n_dim,(n_dim+1):2*n_dim);
% Mp21=Mp((n_dim+1):2*n_dim,1:n_dim);
% Mp22=Mp((n_dim+1):2*n_dim,(n_dim+1):2*n_dim);
% 
% H1=[1/tau*int(Mp11,th,-tau,0) Mp12;Mp21 Mp22];


Mp=M-g{1}*bigS;

Mp11=Mp(1:n_dim,1:n_dim);
Mp12=Mp(1:n_dim,(n_dim+1):2*n_dim);
Mp21=Mp((n_dim+1):2*n_dim,1:n_dim);
Mp22=Mp((n_dim+1):2*n_dim,(n_dim+1):2*n_dim);

H1=[1/tau*int(Mp11,th,-tau,0)+Mex11+eps1*speye(n_dim) Mp12+Mex12;Mp21+Mex21 Mp22];

% Should we make this exact?
toc
disp('running equalities, elapsed time:')
tic
prog = sosmateq(prog,H1-bigP);
prog = sosmateq(prog,N22-Q2);

toc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% phase 2 - derivatives %%%%%%%%%%%%%%%%%%%%
%%%%%%% Step1 %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% the derivative matrices are spelled out in the paper, they are 
disp('constructing Derivatives, elapsed time:')
tic
%Q200=subs(subs(Q2,ksi,0),th,0);
S11 = A0*(h*subs(subs(Q2,ksi,0),th,0)+subs(Q1,th,0))+h*A{1}*subs(subs(Q2,th,-h),ksi,0)+subs(Q1,th,0)/2/h;
S12 = A{1}*subs(Q1,th,-h); S21 = S12.';
S22 = -subs(Q1,th,-h)/h;
S13 = h*A0*subs(subs(Q2,th,0),ksi,th) + h*A{1}*subs(subs(Q2,th,-h),ksi,th) + h*diff(subs(Q2.',ksi,0),th);
S31 = S13.';

D11=polynomial(zeros(n_dim*2,n_dim*2));
D11(1:n_dim,1:n_dim)=S11+S11.';
D11(1:n_dim,n_dim+1:2*n_dim)=S12;
D11(n_dim+1:2*n_dim,1:n_dim)=S21;
D11(n_dim+1:2*n_dim,n_dim+1:2*n_dim)=S22;

    
    % define D_12{i}
    D12=[S13;polynomial(zeros(n_dim,n_dim))];
    D22=diff(Q1,th);
    D{1}=[D11 D12;D12.' D22];
    
   G{1,1}=diff(Q2,th)+diff(subs(Q2.',[th;ksi],[ksi;th]),ksi); % mod for new pvar
%   G{1,1}=diff(Q2,th)+diff(subs(Q2.',{th,ksi,x1},{x1,th,ksi}),ksi);
toc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Step2 %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Enforce negativity of D 
disp('enforcing negativity of derivative')
%Now declare first spacing functions
disp('Calling for jointly positive Mat/Kernel, elapsed time:')
% 
% 
tic
[prog, F, R] = sosjointpos_mat_ker(prog,3*n_dim,orderth/2,ordernu/2,th,ksi,[-tau,0]);
toc

disp('Manipulating variables, elapsed time:')
tic
R11=R(1:2*n_dim,1:2*n_dim);
R12=R(1:2*n_dim,(2*n_dim+1):3*n_dim);
R21=R((2*n_dim+1):3*n_dim,1:2*n_dim);
R22=R((2*n_dim+1):3*n_dim,(2*n_dim+1):3*n_dim);
toc 
tic
Dex11=1/tau*int(int(R11,th,-tau,0),ksi,-tau,0);
Dex12=subs(int(R12,th,-tau,0),ksi,th);
Dex21=int(R21,ksi,-tau,0);
toc
tic
% local positivity multipliers
if orderth>0
        [prog,bigSD] = sosposmatrvar(prog,3*n_dim,orderth-2,[th]);
else
   bigSD = 0;
end
toc
tic
% Fp=F+[Dex11,  Dex12; Dex21, polynomial(zeros(n_dim,n_dim))]-g{1}*bigSD;
% toc
% tic
% Fp11=Fp(1:2*n_dim,1:2*n_dim);
% Fp12=Fp(1:2*n_dim,(2*n_dim+1):3*n_dim);
% Fp21=Fp((2*n_dim+1):3*n_dim,1:2*n_dim);
% Fp22=Fp((2*n_dim+1):3*n_dim,(2*n_dim+1):3*n_dim);
% toc
% tic
% HH=[1/tau*int(Fp11,th,-tau,0) Fp12;Fp21 Fp22];
Fp=F-g{1}*bigSD;
toc
tic
Fp11=Fp(1:2*n_dim,1:2*n_dim);
Fp12=Fp(1:2*n_dim,(2*n_dim+1):3*n_dim);
Fp21=Fp((2*n_dim+1):3*n_dim,1:2*n_dim);
Fp22=Fp((2*n_dim+1):3*n_dim,(2*n_dim+1):3*n_dim);
toc
tic
%HH=[1/tau*int(Fp11,th,-tau,0) Fp12;Fp21 Fp22];
HH=[1/tau*int(Fp11,th,-tau,0)+Dex11 Fp12+Dex12;Fp21+Dex21 Fp22];
toc

%poly3=vartable2*(HH+D{1})*vartable2.';
%poly4=vartableL*(R22+G{1,1})*vartableR.';

disp('running equalities, elapsed time:')
tic
prog = sosmateq(prog,HH+D{1});
prog = sosmateq(prog,R22+G{1,1});
%prog = soseq(prog,poly3);
%prog = soseq(prog,poly4);
toc
disp('TOTAL POLYNOMIAL TIME:')
toc(total)
disp('Computing Solution')
prog = sossolve(prog);

%% Conclusion:
if norm(prog.solinfo.info.feasratio-1)<=.1 && ~prog.solinfo.info.numerr
    disp('The System is STABLE.')
elseif norm(prog.solinfo.info.feasratio-1)<=.1 && prog.solinfo.info.numerr
    disp('The System is likely STABLE. However, Double-check the precision.')
elseif prog.solinfo.info.pinf || prog.solinfo.info.dinf || norm(prog.solinfo.info.feasratio+1)<=.1
    disp('The System is probably NOT STABLE.')
else
    disp('Unable to definitively determine stability. Numerical errors dominating or at the limit of stability.')
end



%
% % 
% First check positivity of the multiplier/integrator
% nvec=6
% nH1=sosgetsol(prog,H1);
% nbP=sosgetsol(prog,bigP);
% 
% 
% n01=sosgetsol(prog,H1-bigP);
% N02=sosgetsol(prog,N22-Q2);
% % First check positivity of the multiplier/integrator
% nvec=6
% Mn=sosgetsol(prog,M);
% Nn=sosgetsol(prog,N);
% xtest =(-10 + (10+10).*rand(nvec,2))'*monomials([th],0:(nvec-1));
% % 
% % xtest=[1+th-4*th^2;
% %     -th+th^3; ]
% xtestksi=subs(xtest,th,ksi);
% eigs(double(subs(Mn,th,-2)))
% int(xtest.'*Mn*xtest,th,-tau,0)
% int(int(xtest.'*Nn*xtestksi,th,-tau,0),ksi,-tau,0)
% 
%   st=[  -7.7066*th^5 - 9.6726*th^4 + 9.0079*th^3 - 8.3433*th^2 - 5.6106*th - 8.779;
%    -5.0892*th^5 + 0.33982*th^4 + 2.849*th^3 - 9.7714*th^2 - 5.6755*th - 9.7518 ]
% 
% % Next check negativity of the derivative
% Dn=sosgetsol(prog,D{1});
% Gn=sosgetsol(prog,G{1,1});
% % generate a random polynomial
% xtest =[(-10 + (10+10).*rand(2,1)); (-10 + (10+10).*rand(nvec,1))'*monomials([th],0:(nvec-1))]
% 
% % xtest=[1+th-4*th^2;
% %     -th+th^3; -5+th ]
% xtestksi=subs(xtest,th,ksi)
% eigs(double(subs(Dn,th,-2)))
% kk1=int(xtest.'*Dn*xtest,th,-tau,0)
% kk2=int(int(xtest(3).'*Gn*xtestksi(3),th,-tau,0),ksi,-tau,0)
% kk1+kk2
