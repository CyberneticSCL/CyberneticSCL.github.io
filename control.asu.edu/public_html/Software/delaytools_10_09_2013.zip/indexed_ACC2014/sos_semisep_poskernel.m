function [prog, N1, N2] = sos_semisep_poskernel(prog,n,d1,d2,var1,var2,I)
% DESCRIPTION 
%
%SOS_SEMISEP_POSKERNEL declares two bivariate n x n matrix-valued polynomials in variables vars1 and
%vars2 of degree d or less. The variable is of form 

% N1(th,ksi) = Z_nd(var1)^T (int(Q1,ss,I(1),var1)+int(Q2,ss,var1,var2)+int(Q3,ss,var2,I(2)))*Z_nd(var2)
% N2(th,ksi)=N1(ksi,th)'
% where Q(s)=[Q1  Q2]
%            [Q2' Q3]>0 is of degree d2 and
%where Znd(x)= Z_d(x) \otimes I_n and Z_d(x) is the vector of monomials in
%variables x of degree d1 or less and P is a positive semidefinite matrix. 
%Note the length of vars1 and vars2 must be the same

% INPUTS 
%   prog: SOS program to modify.
%   n: dimension of the resulting matrix
%   d1: degree of the resulting polynomial in each variable
%   d2: degree of the internal matrix
%   var1: Left-sided pvar
%   var2: right-sided pvar
%   I = [l u] interval of integration
%
% OUTPUT 
%   N1: subdiagonal function
%   N2: superdiagonal function
%
% NOTES:
% Distributed with DelayTOOLS
% Compatable with MULTIPOLY and SOSTOOLS as of June 2013
% For support, contact M. Peet, Arizona State University at mpeet@asu.edu

if ~ispvar(var1) || ~ispvar(var2)
    error('var1 and var2 must be polynomial variables')
end



nZth=d1+1;
Z1degmat = [0:d1]';
Z1coeff = speye(nZth);
Z1varname = var1.varname;
Z1matdim = [nZth 1];
Zth=polynomial(Z1coeff,Z1degmat,Z1varname,Z1matdim);


ss=polynomial(1,1,{'ss'},[1 1]);



% This creates a positive semidefinite matrix variable of size 4nZ*4nZ, where
% nZ is the length of the monomial basis
[prog,Q]=sosposmatrvar(prog,2*nZth*n,d2,ss);

Q1=Q(1:nZth*n,1:nZth*n);
Q2=Q(1:nZth*n,(nZth*n+1):2*nZth*n);
Q3=Q((nZth*n+1):2*nZth*n,(nZth*n+1):2*nZth*n);
Q2p=Q((nZth*n+1):2*nZth*n,1:nZth*n);


N1m=int(Q1,ss,I(1),var1)+int(Q2p,ss,var1,var2)+int(Q3,ss,var2,I(2));
N2m=int(Q1,ss,I(1),var2)+int(Q2,ss,var2,var1)+int(Q3,ss,var1,I(2));
nmatdim=[n n];
nvars=length(N1m.varname);
idxN1v1=find(strcmp(var1.varname,N1m.varname));
idxN1v2=find(strcmp(var2.varname,N1m.varname));
bZdegmat1=sparse(1:n*nZth,idxN1v1,repmat([Zth.degmat],n,1),n*nZth,nvars);
bZdegmat2=sparse(1:n*nZth,idxN1v2,repmat([Zth.degmat],n,1),n*nZth,nvars);

% For the next part, we just need the degmat part of the block-diagonal
% monomial matrix
[PIlistN1, PJlistN1,N1c]=find(N1m.coefficient); % This is the list of terms in P, but PIlist and Pjlist will be relatively short. 
nPIlistN1 = [1:length(PIlistN1)]';

[ProwN1,PcolN1] = ind2sub([n*nZth n*nZth],PJlistN1); % this returns the matrix locations for every term in P

tempdegmat = N1m.degmat;
n1degmat(nPIlistN1,:) = tempdegmat(PIlistN1,:)+ bZdegmat1(ProwN1,:)+bZdegmat2(PcolN1,:);
   
% 
% but now we have to modify the coefficient matrix. We can group this by
% blocks. For a 2x2 matrix, all the coefficients from block 1 will be [1 0 0 0], all the
% coefficients from block 2 will be [0 1 0 0], all the coefficients from
% block 3 will be [0 0 0 1],

% Positions in Pjlist from 1:nZ get reassigned to 1, nZ+1:2nZ -> 2, etc
%[PIlistN1, PJlistN1,N1c]=find(N1m.coefficient); % This is the list of terms in P, but PIlist and Pjlist will be relatively short. 
newrowN1=ceil(ProwN1/nZth);
newcolN1=ceil(PcolN1/nZth);
newidxN1=sub2ind([n n],newrowN1, newcolN1);%(newcol-1)*n+newrow;
n1coeff=sparse(nPIlistN1,newidxN1,N1c);
N1=polynomial(n1coeff,n1degmat,N1m.varname,nmatdim);

% repeat

idxN2v1=find(strcmp(var1.varname,N2m.varname));
idxN2v2=find(strcmp(var2.varname,N2m.varname));
bZdegmat1=sparse(1:n*nZth,idxN2v1,repmat([Zth.degmat],n,1),n*nZth,nvars);
bZdegmat2=sparse(1:n*nZth,idxN2v2,repmat([Zth.degmat],n,1),n*nZth,nvars);
[PIlistN2, PJlistN2,N2c]=find(N2m.coefficient); % This is the list of terms in P, but PIlist and Pjlist will be relatively short. 
nPIlistN2 = [1:length(PIlistN2)]';
[ProwN2,PcolN2] = ind2sub([n*nZth n*nZth],PJlistN2); % this returns the matrix locations for every term in P
tempdegmat = N2m.degmat;
n2degmat(nPIlistN2,:) = tempdegmat(PIlistN2,:)+ bZdegmat1(ProwN2,:)+bZdegmat2(PcolN2,:);
newrowN2=ceil(ProwN2/nZth);
newcolN2=ceil(PcolN2/nZth);
newidxN2=sub2ind([n n],newrowN2, newcolN2);%(newcol-1)*n+newrow;
n2coeff=sparse(nPIlistN2,newidxN2,N2c);
N2=polynomial(n2coeff,n2degmat,N2m.varname,nmatdim);






