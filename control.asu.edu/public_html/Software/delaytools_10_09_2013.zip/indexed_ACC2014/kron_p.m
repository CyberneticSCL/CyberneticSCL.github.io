function b = kron_p(a1,a2)
%
% DESCRIPTION 
%   Add Kronecker product functionality to pvar
%   
%
%      b= [ a1(1,1)*a2  a1(1,2)*a2  a1(1,3)*a2
%        a1(2,1)*a2  a1(2,2)*a2  a1(2,3)*a2 ]
%  
% SYNTAX 
%   b = kron(a1,a2);
%       a1 and a2 are scalar or matrix-valued pvar elements
%
% 6/4/2013: MMP  Initial Coding   

if ndims(a1) > 2 || ndims(a2) > 2
    error(message('MATLAB:kron:TwoDInput'));
end

[ma,na] = size(a1);
[mb,nb] = size(a2);


   [ia,ib] = meshgrid(1:ma,1:mb);
   [ja,jb] = meshgrid(1:na,1:nb);
   b=polynomial(zeros(ma*mb,na*nb));
% going to use the old for-loop. Obviously room for improvement
for i1=1:ma %rows
    for j1=1:na %columns

    b(mb*(i1-1)+1:mb*i1, nb*(j1-1)+1:nb*j1) = a1(i1,j1)*a2;
    end
end
   
   

