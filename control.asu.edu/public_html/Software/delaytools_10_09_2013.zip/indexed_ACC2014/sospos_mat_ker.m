function [prog, M, N] = sospos_mat_ker(prog,n,d1,d2,var1,var2)
%
% SOSJOINTPOS_MAT_KER(prog,n,d1,d2,var1,var2,I) declares the multiplier $M(s)$ and
% kernel part $N(s,t)$ of a positive multiplier+integral operator. The
% multiplier and kernel have the form
%
% M(s) = Z(s)^T Q_1 Z(s)
% N(s,t) = Z(s)^T Q_2 Z(t)
%
% 
% where Z(x)= Z_d1(x) \otimes I_n and Z_d(x) is the vector of monomials in
% variables x of degree d1 or less. Z(x,y) = Z_{d1}(x) \otimes Z_{d2}(x)
% \otimes I_n. If the application is stability of time-delay systems, d1
% will eventually be more or less the degree of the multiplier and d2 more
% or less the degree of the kernel function.
% we recommend setting d2 = d1 to keep the polynomial degrees balanced.

% INPUTS 
%   prog: SOS program to modify.
%   n: dimension of the resulting matrix
%   d1: degree of the multiplier (sort of)
%   d2: degree of the kernel
%   var1: Single pvar corresponding to s in the description
%   var2: Single pvar corresponding to t in the description
%   I = [l u] interval of integration
%
% OUTPUT 
%   N1: subdiagonal function
%   N2: superdiagonal superdiagonal
%
% NOTES:
% Distributed with DelayTOOLS
% Compatable with MULTIPOLY and SOSTOOLS as of June 2013
% For support, contact M. Peet, Arizona State University at mpeet@asu.edu

if ~isvalid(var1) || ~isvalid(var2)
  error(['vars must be a polynomial variable']);
end
dum=polynomial(1,1,{'ss'},[1 1]);

% I'm going to construct Z manually so I know where everything is
nZth=d2+1;
Z1degmat = [0:d2]';
Z1coeff = speye(nZth);
Z1varname = var1.varname;
Z1matdim = [nZth 1];
ZZZth=polynomial(Z1coeff,Z1degmat,Z1varname,Z1matdim);


% There are two configurations for the degree d2. Probably the most logical one is 
% that for TDS applications, 2d1 ends up as the degree of the multiplier and
% 2d2 as the degree of the kernel. This is the following:


% For other applications, however, we may want 2d2 to represent the
% internal variable of integration, in which case we use the following:
% 
% Z2degmat = [repmat([0:d2]',d1+1,1),vec(repmat(0:d1,d2+1,1))];
% nZthksi=length(Z2degmat);
% Z2coeff = speye(nZthksi);
% Z2varname = [var1.varname; var2.varname];
% Z2matdim = [nZthksi 1];
% ZZZthksi=polynomial(Z2coeff,Z2degmat,Z2varname,Z2matdim);


nBZ1=n*nZth;
[prog,M]=sosposmatrvar(prog,n,2*d1,[var1]);

[prog,LLL4]=sosposmatr(prog,nBZ1);
bZ1th=[];
for i=1:n
    bZ1th=blkdiag(bZ1th,ZZZth);
end
N=bZ1th.'*LLL4*subs(bZ1th,var1,var2);
end
