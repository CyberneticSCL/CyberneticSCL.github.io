function [prog, N] = sosposkernelvar(prog,n,d,var1,var2)
%SOSPOSKERNELVAR(prog,n,d,var1,var2) 
% Declares a bivariate n x n matrix-valued polynomial in variables vars1 and
% vars2 of degree d or less. The variable is of form Z_nd(var1)^T P Z_nd(var2)
% where Znd(x)= Z_d(x) \otimes I_n and Z_d(x) is the vector of monomials in
% variables x of degree d or less and P is a positive semidefinite matrix. 
% Note the length of vars1 and vars2 must be the same
%
% Note: The degree of the variable will be 2*d
%
% Inputs: 
% prog - The SOSprogram to which to attach the variable
% n - the dimension of the resulting kernel matrix
% d - The degree of the resulting kernel will be 2d (d in each variable)
% var1 - a POLYNOMIAL variable which will appear in the kernel
% var2 - The other POLYNOMIAL variable
%
% NOTES:
% Distributed with DelayTOOLS
% Compatable with MULTIPOLY and SOSTOOLS as of June 2013
% For support, contact M. Peet, Arizona State University at mpeet@asu.edu

if ~ispvar(var1) || ~ispvar(var2)
    error('var1 and var2 must be polynomial variables')
end

nZth=d+1;
Z1degmat = [0:d]';
Z1coeff = speye(nZth);
Z1varname = var1.varname;
Z1matdim = [nZth 1];
ZZZth=polynomial(Z1coeff,Z1degmat,Z1varname,Z1matdim);


% We have constructed Z_nd(var1) = bigLZ; Z_nd(var2) = bigRZ
% Now create the kernel variable N = Z_nd(var1)^T P Z_nd(var2);

[prog,P]=sosposmatr(prog,nZth*n);

nvarname=[P.varname; var1.varname; var2.varname ];
% For the next part, we just need the degmat part of the block-diagonal
% monomial matrix
bZdegmat1=repmat([ZZZth.degmat zeros(nZth,1)],n,1);
bZdegmat2=repmat([zeros(nZth,1) ZZZth.degmat],n,1);

[PIlist, PJlist]=find(P.coefficient); % This is the list of terms in P, but PIlist and Pjlist will be relatively short. 
[Prowu,Pcolu] = ind2sub([n*nZth n*nZth],PJlist); % this returns the matrix locations for every term in P
ndegmat = [P.degmat(PIlist,:) bZdegmat1(Prowu,:)+bZdegmat2(Pcolu,:)];

    
% 
% but now we have to modify the coefficient matrix. We can group this by
% blocks. For a 2x2 matrix, all the coefficients from block 1 will be [1 0 0 0], all the
% coefficients from block 2 will be [0 1 0 0], all the coefficients from
% block 3 will be [0 0 0 1],

% Positions in Pjlist from 1:nZ get reassigned to 1, nZ+1:2nZ -> 2, etc
[row,col] = ind2sub([n*nZth n*nZth],PJlist);
newrow=ceil(row/nZth);
newcol=ceil(col/nZth);
newidx=sub2ind([n n],newrow, newcol);%(newcol-1)*n+newrow;

nPIlist=(1:length(PIlist))';
coeff=sparse(nPIlist,newidx,1);
nmatdim=[n n];
N=polynomial(coeff,ndegmat,nvarname,nmatdim);


end

