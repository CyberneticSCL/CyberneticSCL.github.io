clear all; close all; echo off; 
total=tic;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% DelayTools/Linear v.04 - solver_delay_nd
%
% This program determines stablity of a linear differential equation with a
% a single delay, where \dot{x}(t)=A0x(t)+A{1}x(t-tau(1))+...+A{K}x(t-tau(K))  
% where A0, A{i}, and tau(i) are user inputs. 
%
% Inputs: A{i} - these can be arbitrary square matrices of arbitrary 
%         dimension. However,  the higher the higher the dimension of A{i},
%         the more time the program will take to run
%         
%         tau(i) - These can be an arbitrary sequence of positive increasing 
%         numbers.
%
%         orderth - This input controls the accuracy of the results. For
%         most problems, orderth=2 should be sufficient to obtain a
%         reasonable degree of accuracy. Note: orderth should be an even
%         integer.
% 
% Requirements: In order to operate, this program requires a working
%               version of SOStools. There are some known compatability 
%               issues with SOStools and Matlab version 7+ due to errors in 
%               the implementation of Maple v8. In addition, it
%               is highly recommended that the user have a compiled version
%               of cdd. Finally the following package of subprograms are
%               required which allows SOStools to handle matrix objects
%               directly:
%               SOStools Matrix Addon package:
%                   sosposmatr.m
%                   sosposmatr.m
%                   sosmatrvar.m
%                   sossymmatrvar.m
%                   sosposmatrvar.m
%
% version .03   M. Peet, Stanford. mmpeet@stanford.edu
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DelayTools/Linear v.03 - solver_delay_nd
% Release Notes:
% v.03 - Compatibility with MatrixTOOLS v.03
%
% Coming soon - The big change with release v.04 will be the use of semiseparable
% kernel functions. These functions have properties in common with the
% Gaussian and seem to give an order of magnitude increase in Accuracy in
% most problems, expecially ones which were problematic using separable
% kernels. As yet, we have no joint positivity condition for semiseparable
% kernels. Thus the choice was between either joint positivity or
% semiseparable kernels. Since joint positivity demonstrated little or no
% improvement in performance, the choice was relatively simple.
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs
%
% Enter system dynamics in terms of A0, A{1}, ..., A{K}
% A0=[0 1; 0 -.1];
% A{1}=[0; .1]*[-3.75 -11.5];
%====================
% Gu 2delay example 1
% A0=[-2 0; 0 -.9];
% A{1}=[-1 0;-1 -1]*.05;
% A{2}=[-1 0;-1 -1]*.95;
% tau(2) = 6.%8.5
% tau(1) = tau(2)/2;
%====================
% Gu 2delay example 2
A0=[0 1; -1 .1];
A{1}=[0 0;-1 0];
A{2}=[0 0;1 0];
tau(2) = 1.3723%1.372 is max
tau(1) = tau(2)/2;
%====================
%  A0=[0];
%  A{1}=[-.5];
% A{2}=[-.5];
% tau(1) = 7;
% tau(2) = 7.1;
%  A0=[0];
%  A{1}=[-1];
% A{2}=[0];
% tau(1) = 1.3;
% tau(2) = 8;


% ntemp=2;
% A0=zeros(ntemp,ntemp);
% A{1}=-eye(ntemp);
% tau(1)=1.4;

% 
% A0=[0 0;0 1] + [0 0; -.00599 -1.00149];
% A{1}=[-2 -.5;0 -1]+ [0 0;7.99783 2.99945];
% tau(1)=1000;

% Enter values of the delay tau(1), ..., tau(K)


% tau(1) = 1.166;
%tau(2) = 1.34;
%
% Enter degree of accuracy - must be an even integer
orderth = 4;
ordernu=4;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% internal variables:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%fact=1/tau;
fact=1;           % conditioning multiplier
eps1=1;           % strictness of lyapunov positivity
eps2=0;           % strictness of derivative negativity

% control inputs to SeDuMi 
pars.alg=2;
pars.stepdif=1;
pars.eps=10^(-10);
pars.maxiter=100;
pars.cg.maxiter=200;
pars.cg.qprec=1;
pars.cg.stagtol=1e-22;
pars.cg.restol=5e-5;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% internal processing:
tic
pvar th ksi

n_dim=length(A0);
n_delay=length(tau);
tauK=tau(n_delay);

mastervartable=[th,ksi];
prog = sosprogram(mastervartable);

% local positivity regions:
g{1}=th*(th+tau(1));            %negative on interval [-\tau,0]
for i=2:n_delay
    g{i}=(th+tau(i))*(th+tau(i-1));%negative on interval [-tau_i,-\tau_i-1]
end
II{1}=[-tau(1) 0];            %negative on interval [-\tau,0]
for i=2:n_delay
    II{i}=[-tau(i) -tau(i-1)];%negative on interval [-tau_i,-\tau_i-1]
end
% This is the multiple delay case.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% phase 1 - variables %%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% we will need to declare variables:
% P, Q(th), S(th), R(th,ksi)
%
disp('Overhead and Lyapunov Variables, elapsed time:')

%[prog,P] = sossymmatrvar(prog,monomials(th,0),[n_dim]);
% for i=1:n_delay
% %    eval(['[prog,Q1',int2str(i),'] = sosmatrvar(prog,monomials([fact*th],0:orderth),[n_dim,n_dim]);'])
%      [prog,Q1{i}]=sossymmatrvar(prog,monomials([fact*th],0:orderth),n_dim);
% end
% % for i=1:n_delay
% %     for j=1:n_delay
% %     [prog,Q2{i,j}] = sosmatrvar(prog,monomials([fact*th fact*ksi],0:orderth),[n_dim, n_dim]);
% % %    eval(['[prog,Q2',int2str(i),int2str(j),'] = sossymmatrvar(prog,monomials([fact*th],0:orderth),[n_dim]);'])
% %     end
% % end
% for i=1:n_delay
%     for j=1:n_delay %j>i
%     [prog,Q2t{i,j}] = sosmatrvar(prog,monomials([fact*th fact*ksi],0:orderth),[n_dim, n_dim]);
%     end
% end
% for i=1:n_delay
%     for j=1:n_delay %j<i
%         Q2{i,j}=.5*(Q2t{i,j}+var_swap(Q2t{j,i}.',th,ksi)); % enforce 
%     end
% end
% 
% for i=1:n_delay
%         bigP{i}=[tau(n_delay)*subs(subs(Q2{1,1},ksi,0),th,0)+subs(Q1{1},th,0), tau(n_delay)*subs(var_swap(Q2{1,i},ksi,th),ksi,0); tau(n_delay)*subs(Q2{i,1},ksi,0) Q1{i}]; %mod for new pvar
% end
% 
% for i=1:n_delay
%     for j=1:n_delay %j>i
%     [prog,Q2t{i,j}] = sosmatrvar(prog,monomials([fact*th fact*ksi],0:orderth),[n_dim, n_dim]);
%     end
% end
% 
% for i=1:n_delay
%     for j=1:n_delay %j<i
%         Q2{i,j}=.5*(Q2t{i,j}+var_swap(Q2t{j,i}.',th,ksi)); % enforce 
%     end
% end
% % 
% % 
% % for i=1:n_delay
% %     for j=i:n_delay %j>i
% %     [prog,Q2{i,j}] = sosmatrvar(prog,monomials([fact*th fact*ksi],0:orderth),[n_dim, n_dim]);
% %     end
% % end
% % 
% % 
% % for i=1:n_delay
% %     for j=1:(i-1) %j<i
% %         Q2{i,j}=var_swap(Q2{j,i}.',th,ksi); % enforce 
% %     end
% % end
% [prog,P11]=sossymmatrvar_p(prog,[polynomial(1)],n_dim);
% 
% for i=1:n_delay
%        [prog,P12{i}] = sosmatrvar(prog,monomials([fact*th],0:orderth),[n_dim, n_dim]);
%        [prog, P22{i}]=sossymmatrvar(prog,monomials([fact*th],0:orderth),n_dim); %mod for new pvar
%        bigP{i}=[P11 P12{i}; P12{i}.' P22{i}];
% end
% %bigP{i}=
% 
% Nw=Q2; % our kernel is Q2 in this case, but lets keep it general
toc
disp('creating joint positive operator variable')
tic
%[prog, M, N] = sospos_mat_ker_ndelay(prog,2*n_dim,orderth/2,ordernu/2,th,ksi,II);
[prog, M, N] = sosjointpos_mat_ker_ndelay(prog,2*n_dim,orderth/2,ordernu/2,th,ksi,II);
%[prog, M, N] = sosjointpos_mat_ker_ndelay_backup(prog,2*n_dim,orderth/2,ordernu/2,th,ksi,II);
toc


disp('manipulating variables, elapsed time:')
tic
for i=1:n_delay
    for j=1:n_delay
        N11{i,j}=N{i,j}(1:n_dim,1:n_dim);
        N12{i,j}=N{i,j}(1:n_dim,(n_dim+1):2*n_dim);
        N21{i,j}=N{i,j}((n_dim+1):2*n_dim,1:n_dim);
        Nw{i,j}=N{i,j}((n_dim+1):2*n_dim,(n_dim+1):2*n_dim);
    end
end
zzn=polynomial(zeros(n_dim));
Mex11=zzn;
for i=1:n_delay
    Mex12{i}=zzn;
    for j=1:n_delay
        Mex11=Mex11+int(int(N11{i,j},th,II{i}(1),II{i}(2)),ksi,II{j}(1),II{j}(2));
        Mex12{i}=Mex12{i}+int(var_swap(N12{j,i},th,ksi),ksi,II{j}(1),II{j}(2));
%        Mex21{j}=Mex12{i}.';
    end
end
Mex11=Mex11/tau(n_delay);
 for i=1:n_delay
    Mex21{i}=zzn;
     for j=1:n_delay
        Mex21{i}=Mex21{i}+int(N21{i,j},ksi,II{j}(1),II{j}(2));
     end
 end

% local positivity multipliers, s1 and s2


if orderth>0
    for i=1:n_delay
%        eval(['[prog,bigs',int2str(i),'] = sosposmatrvar(prog,2*n_dim,orderth-2,[th]);'])
        [prog,bigS{i}] = sosposmatrvar(prog,2*n_dim,orderth-2,[th]);
    end
else
    for i=1:n_delay
%        eval(['bigs',int2str(i),'=blkdiag(zzn,zzn);'])
        bigS{i}=polynomial(zeros(2*n_dim));
    end
end
Mp11i=zzn;
 for i=1:n_delay
    Mp{i}=M{i}-g{i}*bigS{i};
    Mp11{i}=Mp{i}(1:n_dim,1:n_dim);
    Mp12{i}=Mp{i}(1:n_dim,(n_dim+1):2*n_dim);
    Mp21{i}=Mp{i}((n_dim+1):2*n_dim,1:n_dim);
    Mp22{i}=Mp{i}((n_dim+1):2*n_dim,(n_dim+1):2*n_dim);
    Mp11i=Mp11i+int(Mp11{i},th,II{i}(1),II{i}(2));
 end
  for i=1:n_delay
    bigP{i}=[Mp11i/tau(n_delay)+Mex11+eps1*eye(n_dim) Mp12{i}+Mex12{i};Mp21{i}+Mex21{i} Mp22{i}];
      %   H1{i}=[Mp11i/tau(n_delay)+Mex11+eps1*speye(n_dim) Mp12{i}+Mex12{i};Mp21{i}+Mex21{i} Mp22{i}];
  end

% bigP{2}=bigP{2};
% Nw{1,2}=Nw{1,2}
% Nw{2,2}=Nw{2,2}
% Nw{2,1}=Nw{2,1}
 
%  % Should we make this exact?
% toc
% disp('running equalities, elapsed time:')
% tic
% 
% for i=1:n_delay
%     [prog] = sosmateq(prog,H1{i}-bigP{i});
% end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Step2 %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% we first construct the variable R
% First declare a monomial basis for R

% for i=1:n_delay
%     for j=1:n_delay
%         [prog] = sosmateq(prog,Q2{i,j}-N22{i,j});
%     end
% end
toc

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% phase 2 - derivatives %%%%%%%%%%%%%%%%%%%%
%%%%%%% Step1 %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% the derivative matrices are spelled out in the paper, they are 
disp('constructing Derivatives, elapsed time:')
tic

zzn=polynomial(zeros(n_dim));
P11=bigP{1}(1:n_dim,1:n_dim);
for i=1:n_delay
    P12{i}=bigP{i}(1:n_dim,(n_dim+1):(2*n_dim));
    P21{i}=bigP{i}((n_dim+1):(2*n_dim),1:n_dim);%P12{i}.';
    P22{i}=bigP{i}((n_dim+1):(2*n_dim),(n_dim+1):(2*n_dim));
end

D11=P11*A0+A0.'*P11+subs(P12{1}+P21{1}+P22{1},th,0)/tau(n_delay);
D13=P11*A{n_delay}-(subs(P12{n_delay},th,-tau(n_delay)))/tau(n_delay); % Another TYPO in the paper
D33=-subs(P22{n_delay},th,-tau(n_delay))/tau(n_delay);
D12=[];%polynomial(zeros(n_dim,(n_delay-1)*n_dim));
D22=[];
for i=1:n_delay-1
    D12=[D12 P11*A{i}+(subs(-P12{i}+P12{i+1},th,-tau(i)))/tau(n_delay)]; %TYPO in the paper- left out the tau factor
%    D21=[D21; P11*A{i}+(-subs(P12{i}+P12{i+1},th,-tau(i)))/tau(n_delay)]; %TYPO in the paper- left out the tau factor
    D22=blkdiag(D22,(subs(-P22{i}+P22{i+1},th,-tau(i)))/tau(n_delay));
end
D23=polynomial(zeros((n_delay-1)*n_dim,n_dim));


for i=1:n_delay
    D14{i}=subs(var_swap(Nw{1,i},th,ksi),ksi,0)+A0.'*P12{i}-diff(P12{i},th);
    D34{i}=A{n_delay}.'*P12{i}-subs(var_swap(Nw{n_delay,i},th,ksi),ksi,-tau(n_delay));
    D44{i}=-diff(P22{i},th);
    D24{i}=[];
    for k=1:(n_delay-1)
        D24{i}=[D24{i}; subs(var_swap(Nw{k+1,i},th,ksi),ksi,-tau(k))-subs(var_swap(Nw{k,i},th,ksi),ksi,-tau(k))+A{k}.'*P12{i}]; % There is a TYPO in the paper for this term: DN -> -Dn
    end
    D{i}=[D11 D12 D13 D14{i};
        D12.' D22 D23 D24{i};
        D13.' D23.' D33 D34{i};
        D14{i}.' D24{i}.' D34{i}.' D44{i}];
end


for i=1:n_delay
    for j=1:n_delay
        G{i,j}=-(diff(Nw{i,j},th)+diff(Nw{i,j},ksi));
    end
end

% D11=P11*A0+A0.'*P11+subs_p(P12{1}+P21{1}+P22{1},th,0)/tau(n_delay);
% D13=P11*A{n_delay}-(subs_p(P12{n_delay},th,-tau(n_delay)))/tau(n_delay); % Another TYPO in the paper
% D33=-subs_p(P22{n_delay},th,-tau(n_delay))/tau(n_delay);
% D12=[];%polynomial(zeros(n_dim,(n_delay-1)*n_dim));
% D22=[];
% for i=1:n_delay-1
%     D12=[D12 P11*A{i}+(-subs_p(P12{i}+P12{i+1},th,-tau(i)))/tau(n_delay)]; %TYPO in the paper- left out the tau factor
% %    D21=[D21; P11*A{i}+(-subs_p(P12{i}+P12{i+1},th,-tau(i)))/tau(n_delay)]; %TYPO in the paper- left out the tau factor
%     D22=blkdiag(D22,(-subs_p(P22{i}+P22{i+1},th,-tau(i)))/tau(n_delay));
% end
% D23=polynomial(zeros((n_delay-1)*n_dim,n_dim));
% 
% 
% for i=1:n_delay
%     D14{i}=subs_p(var_swap(Nw{1,i},th,ksi),ksi,0)+A0.'*P12{i}-diff(P12{i},th);
%     D34{i}=A{n_delay}.'*P12{i}-subs_p(var_swap(Nw{n_delay,i},th,ksi),ksi,-tau(n_delay));
%     D44{i}=-diff(P22{i},th);
%     D24{i}=[];
%     for k=1:(n_delay-1)
%         D24{i}=[D24{i}; subs_p(var_swap(Nw{k+1,i},th,ksi),ksi,-tau(k))-subs_p(var_swap(Nw{k,i},th,ksi),ksi,-tau(k))+A{k}.'*P12{i}]; % There is a TYPO in the paper for this term: DN -> -Dn
%     end
%     D{i}=[D11 D12 D13 D14{i};
%         D12.' D22 D23 D24{i};
%         D13.' D23.' D33 D34{i};
%         D14{i}.' D24{i}.' D34{i}.' D44{i}];
% end
% 
% 
% for i=1:n_delay
%     for j=1:n_delay
%         G{i,j}=-(diff(Nw{i,j},th)+diff(Nw{i,j},ksi));
%     end
% end
toc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Step2 %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Enforce negativity of D 
disp('enforcing negativity of derivative')
%Now declare first spacing functions

%[prog, M, N] = sosjointpos_mat_ker_ndelay(prog,2*n_dim,orderth/2,ordernu/2,th,ksi,II);
disp('Calling for jointly positive Mat/Kernel, elapsed time:')
% 
% 
tic
%[prog, F, R] = sospos_mat_ker_ndelay(prog,(n_delay+2)*n_dim,orderth/2,ordernu/2,th,ksi,II);
[prog, F, R] = sosjointpos_mat_ker_ndelay(prog,(n_delay+2)*n_dim,orderth/2,ordernu/2,th,ksi,II);
toc

disp('Manipulating variables, elapsed time:')
tic
for i=1:n_delay
    for j=1:n_delay
        R11{i,j}=R{i,j}(1:(n_dim*(n_delay+1)),1:(n_dim*(n_delay+1)));
        R12{i,j}=R{i,j}(1:(n_dim*(n_delay+1)),(n_dim*(n_delay+1)+1):((n_delay+2)*n_dim));
        R21{i,j}=R{i,j}((n_dim*(n_delay+1)+1):((n_delay+2)*n_dim),1:(n_dim*(n_delay+1)));
        R22{i,j}=R{i,j}((n_dim*(n_delay+1)+1):((n_delay+2)*n_dim),(n_dim*(n_delay+1)+1):((n_delay+2)*n_dim));

    end
end
Dex11=polynomial(zeros(n_dim*(n_delay+1)));
for i=1:n_delay
    Dex12{i}=polynomial(zeros(n_dim*(n_delay+1),n_dim));
    for j=1:n_delay
        Dex11=Dex11+int(int(R11{i,j},th,II{i}(1),II{i}(2)),ksi,II{j}(1),II{j}(2));
        Dex12{i}=Dex12{i}+subs(int(R12{j,i},th,II{j}(1),II{j}(2)),ksi,th);
%        Dex21{j}=Dex12{i}.';
    end
end
Dex11=Dex11/tau(n_delay);
 for i=1:n_delay
    Dex21{i}=polynomial(zeros(n_dim,n_dim*(n_delay+1)));
     for j=1:n_delay
        Dex21{i}=Dex21{i}+int(R21{i,j},ksi,II{j}(1),II{j}(2));
     end
 end

 if orderth>0
    for i=1:n_delay
        [prog,bigSD{i}] = sosposmatrvar(prog,(n_delay+2)*n_dim,orderth-2,[th]);
    end
else
    for i=1:n_delay
%        eval(['bigs',int2str(i),'=blkdiag(zzn,zzn);'])
        bigSD{i}=polynomial(zeros((n_delay+2)*n_dim));
    end
end

Fp11i=polynomial(zeros((n_delay+1)*n_dim));
 for i=1:n_delay
    Fp{i}=F{i}-g{i}*bigSD{i};
    Fp11{i}=Fp{i}(1:(n_dim*(n_delay+1)),1:(n_dim*(n_delay+1)));
    Fp12{i}=Fp{i}(1:(n_dim*(n_delay+1)),(n_dim*(n_delay+1)+1):((n_delay+2)*n_dim));
    Fp21{i}=Fp{i}((n_dim*(n_delay+1)+1):((n_delay+2)*n_dim),1:(n_dim*(n_delay+1)));
    Fp22{i}=Fp{i}((n_dim*(n_delay+1)+1):((n_delay+2)*n_dim),(n_dim*(n_delay+1)+1):((n_delay+2)*n_dim));
    Fp11i=Fp11i+int(Fp11{i},th,II{i}(1),II{i}(2));
  end
 
 
  for i=1:n_delay
%    H1{i}=[Mp11i/tau(n_delay)+Mex11+eps1*speye(n_dim) Mp12{i}+Mex12{i};Mp21{i}+Mex21{i} Mp22{i}];
    HH{i}=[Fp11i/tau(n_delay)+Dex11 Fp12{i}+Dex12{i};Fp21{i}+Dex21{i} Fp22{i}];
 end
 
% Should we make this exact?
toc
disp('running equalities, elapsed time:')
tic

for i=1:n_delay
    [prog] = sosmateq(prog,HH{i}+D{i});
    for j=1:n_delay
                [prog] = sosmateq(prog,R22{i,j}+G{i,j});
    end
end
toc
disp('TOTAL POLYNOMIAL TIME:')
toc(total)
disp('Computing Solution')


disp('Computing Solution')
prog = sossolve(prog);
%% Conclusion:
if norm(prog.solinfo.info.feasratio-1)<=.1 && ~prog.solinfo.info.numerr
    disp('The System is STABLE.')
elseif norm(prog.solinfo.info.feasratio-1)<=.1 && prog.solinfo.info.numerr
    disp('The System is likely STABLE. However, Double-check the precision.')
elseif prog.solinfo.info.pinf || prog.solinfo.info.dinf || norm(prog.solinfo.info.feasratio+1)<=.1
    disp('The System is probably NOT STABLE.')
else
    disp('Unable to definitively determine stability. Numerical errors dominating or at the limit of stability.')
end

% 
% %
% % % 
% % First check positivity of the multiplier/integrator
%  nvec=6
%  nH1=sosgetsol(prog,H1{1});
%  nbP=sosgetsol(prog,bigP{1});
%  
%  
 n01=sosgetsol(prog,H1{1}-bigP{1});
 N01=sosgetsol(prog,N22{1,1}-Q2{1,1});

  n02=sosgetsol(prog,HH{1}+D{1});
 N02=sosgetsol(prog,R22{1,2}+G{1,2})
 
 
 
%  
%  idxxx=find( prog.expr.At{1}(:,1));
%  xxx=prog.solinfo.RRx(idxxx);
%  [dum,dum2,Attt]=find(prog.expr.At{1}(:,1));
%  Attt'*xxx;
%  % % First check positivity of the multiplier/integrator
% % nvec=6
% % Mn=sosgetsol(prog,M);
% % Nn=sosgetsol(prog,N);
% % xtest =(-10 + (10+10).*rand(nvec,2))'*monomials([th],0:(nvec-1));
% % % 
% % % xtest=[1+th-4*th^2;
% % %     -th+th^3; ]
% % xtestksi=subs(xtest,th,ksi);
% % eigs(double(subs(Mn,th,-2)))
% % int(xtest.'*Mn*xtest,th,-tau,0)
% % int(int(xtest.'*Nn*xtestksi,th,-tau,0),ksi,-tau,0)
% 
% 
%  % % First check positivity of the multiplier/integrator
%  ndim=length(M{1});
%  nvec=6;
% i1temp=0;
% i2temp=0;
% for i=1:n_delay
%         xtest{i}=(-10 + (10+10).*rand(nvec,ndim))'*monomials([th],0:(nvec-1));
%     xtestksi{i}=subs(xtest{i},th,ksi);
% end
% 
% for i=1:n_delay
%     Mn{i}=sosgetsol(prog,M{i});
% %    i1temp{i}=int(xtest{i}.'*Mn{i}*xtest{i},th,II{i}(1),II{i}(2))
%     i1temp=i1temp+int(xtest{i}.'*Mn{i}*xtest{i},th,II{i}(1),II{i}(2));
%     for j=i:n_delay
%         Nn{i,j}=sosgetsol(prog,N{i,j});
% %        i2temp{i,j}=int(int(xtest{i}.'*Nn{i,j}*xtestksi{j},th,II{i}(1),II{i}(2)),ksi,II{j}(1),II{j}(2))
%         i2temp=i2temp+int(int(xtest{i}.'*Nn{i,j}*xtestksi{j},th,II{i}(1),II{i}(2)),ksi,II{j}(1),II{j}(2));
%     end
% end
% i1temp
% i2temp
% i1temp+i2temp
% 
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% sup=inf;
%  ndim=length(bigP{1});
%  ndimG=length(Nw{1});
% for k=1:100
%  nvec=6;
% i1temp=0;
% i2temp=0;
% for i=1:n_delay
%         xtest{i}=(-10 + (10+10).*rand(nvec,ndim))'*monomials([th],0:(nvec-1));
%     xtestksi{i}=subs(xtest{i},th,ksi);
% end
% 
% for i=1:n_delay
%     Pn{i}=sosgetsol(prog,bigP{i});
% %    i1temp{i}=int(xtest{i}.'*Mn{i}*xtest{i},th,II{i}(1),II{i}(2))
%     i1temp=i1temp+int(xtest{i}.'*Pn{i}*xtest{i},th,II{i}(1),II{i}(2));
%     for j=i:n_delay
%         Nwn{i,j}=sosgetsol(prog,Nw{i,j});
% %        i2temp{i,j}=int(int(xtest{i}.'*Nn{i,j}*xtestksi{j},th,II{i}(1),II{i}(2)),ksi,II{j}(1),II{j}(2))
%         i2temp=i2temp+int(int(xtest{i}.'*[zeros(ndim-ndimG) zeros(ndim-ndimG,ndimG); zeros(ndim-ndimG,ndimG)' Nwn{i,j}]*xtestksi{j},th,II{i}(1),II{i}(2)),ksi,II{j}(1),II{j}(2));
%     end
% end
% i1temp
% i2temp
% i1temp+i2temp
% inf=min(double(i1temp+i2temp),inf)
% end
% 
% 
% 
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% sup=-inf;
%  ndim=length(D{1});
%  ndimG=length(G{1});
%  nvec=6;
% for k=1:100
% i1temp=0;
% i2temp=0;
% for i=1:n_delay
%         xtest{i}=(-10 + (10+10).*rand(nvec,ndim))'*monomials([th],0:(nvec-1));
%     xtestksi{i}=subs(xtest{i},th,ksi);
% end
% 
% for i=1:n_delay
%     Dn{i}=sosgetsol(prog,D{i});
% %    i1temp{i}=int(xtest{i}.'*Mn{i}*xtest{i},th,II{i}(1),II{i}(2))
%     i1temp=i1temp+int(xtest{i}.'*Dn{i}*xtest{i},th,II{i}(1),II{i}(2));
%     for j=i:n_delay
%         Gn{i,j}=sosgetsol(prog,G{i,j});
% %        i2temp{i,j}=int(int(xtest{i}.'*Nn{i,j}*xtestksi{j},th,II{i}(1),II{i}(2)),ksi,II{j}(1),II{j}(2))
%         i2temp=i2temp+int(int(xtest{i}.'*[zeros(ndim-ndimG) zeros(ndim-ndimG,ndimG); zeros(ndim-ndimG,ndimG)' Gn{i,j}]*xtestksi{j},th,II{i}(1),II{i}(2)),ksi,II{j}(1),II{j}(2));
%     end
% end
% %i1temp
% %i2temp
% i1temp+i2temp
% sup=max(double(i1temp+i2temp),sup)
% end
% 
% 
% 
%  % 
%  % xtest=[1+th-4*th^2;
%  %     -th+th^3; ]
%  eigs(double(subs(Mn,th,-2)))
%  int(xtest.'*Mn*xtest,th,-tau,0)
%  int(int(xtest.'*Nn*xtestksi,th,-tau,0),ksi,-tau,0)




% 
%   st=[  -7.7066*th^5 - 9.6726*th^4 + 9.0079*th^3 - 8.3433*th^2 - 5.6106*th - 8.779;
%    -5.0892*th^5 + 0.33982*th^4 + 2.849*th^3 - 9.7714*th^2 - 5.6755*th - 9.7518 ]
% 
% % Next check negativity of the derivative
% Dn=sosgetsol(prog,D{1});
% Gn=sosgetsol(prog,G{1,1});
% % generate a random polynomial
% xtest =[(-10 + (10+10).*rand(2,1)); (-10 + (10+10).*rand(nvec,1))'*monomials([th],0:(nvec-1))]
% 
% % xtest=[1+th-4*th^2;
% %     -th+th^3; -5+th ]
% xtestksi=subs(xtest,th,ksi)
% eigs(double(subs(Dn,th,-2)))
% kk1=int(xtest.'*Dn*xtest,th,-tau,0)
% kk2=int(int(xtest(3).'*Gn*xtestksi(3),th,-tau,0),ksi,-tau,0)
% kk1+kk2

