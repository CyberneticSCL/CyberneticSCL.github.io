function [prog,P] = sossymmatrvar(prog,Z,sizeP,wscoeff);
%SOSMATRVAR(prog,Z,sizeP,wscoeff) declares a n x m matrix-valued
%polynomial in monomials Z. 
%
% Inputs: 
% prog - The SOSprogram to which to attach the variable
% Z - The list of monomials which appear in the elements of the matrix.
% sizeP - The dimension of the resulting matrix will be sizePxsizeP so that
%               sizeP=#rows=#cols;
% wscoeff - if wscoeff='wscoeff', elements of the matrix will be declared
% as pvars in the workspace
%
% NOTES:
% Distributed with DelayTOOLS
% Compatable with MULTIPOLY and SOSTOOLS as of June 2013
% For support, contact M. Peet, Arizona State University at mpeet@asu.edu
%

% version 1.0   A. Papachristodoulou
%               M. Peet
if nargin > 3 & wscoeff == 'wscoeff'
for i = 1:sizeP*(sizeP+1)/2
   [prog,matrPi(i)] = sospolyvar(prog,Z,'wscoeff');
end
else;
for i = 1:sizeP*(sizeP+1)/2
   [prog,matrPi(i)] = sospolyvar(prog,Z);
end
end

% for i = 1:sizeP*(sizeP+1)/2
%    [prog,matrPi(i)] = sospolyvar(prog,Z,'wscoeff');
% end

dumvec(1) = 1;
for i = 1:sizeP-1
   dumvec(i+1) = dumvec(i)+(sizeP-i)+1;
end
dumvec(end+1) = dumvec(end)+1;

dumQ = diag([-1:-1:-sizeP]);
for i = 1:sizeP
   dumQ = dumQ + diag(dumvec(i):dumvec(i+1)-1,i-1)+ diag(dumvec(i):dumvec(i+1)-1,-i+1);
end

for i = 1:sizeP;
   for j = 1:sizeP;
      P(i,j) = matrPi(dumQ(i,j));
   end
end
