% setup_PIETOOLS_pde file performs the following two tasks.
% 1) It verifies the dimension compatibility of input parameters of ODE-PDE
% and sets any missing parameters to zero.
% 2) It converts the input ODE-PDE representation to a PIE
% representation. 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Test for domain (mandatory variables)
if ~exist('a','var')||~exist('b','var')
    error('Domain not defined');
end
X = [a,b];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Check for dimension of state variables (important but optional variables)
if ~exist('nu','var')
    warning('Number of inputs not defined. Defaulting to zero');
    nu=0;
end
if ~exist('nw','var')
    warning('Number of disturbances not defined. Defaulting to zero');
    nw=0;
end
if ~exist('ny','var')
    warning('Number of outputs not defined. Defaulting to zero');
    ny=0;
end
if ~exist('nz','var')
    warning('Number of regulated outputs not defined. Defaulting to zero');
    nz=0;
end
if ~exist('no','var')
    warning('Number of ODE states not defined. Defaulting to zero');
    no=0;
end
if ~exist('n0','var')
    warning('Number of non-differentiated states n_1 not defined. Defaulting to zero');
    n0=0;
end
if ~exist('n1','var')
    warning('Number of continuously differentiable states n1 not defined. Defaulting to zero');
    n1=0;
end
if ~exist('n2','var')
    warning('Number of twice continuously differentiable states n2 not defined. Defaulting to zero');
    n2=0;
end
np = n0+n1+n2;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Check parameters related to ODE dynamics 
if ~exist('E0','var') || any(size(E0)~=[no,2*n1+4*n2])
    disp('E0 not properly defined. Defaulting to zero');
    E0 = zeros(no, 2*n1+4*n2);
end
if ~exist('A','var')|| any(size(A)~=[no,no])
    disp('A has incorrect dimension or is undefined. Defaulting to zero');
    A = zeros(no);
end
if ~exist('Ea','var')|| any(size(Ea)~=[no,np])
    Ea=zeros(no,np);
    disp('Ea has incorrect dimension or is undefined. Defaulting to zero');
end
if ~exist('Eb','var') || any(size(Eb)~=[no,n1+n2])
    Eb=zeros(no,n1+n2);
    disp('Eb has incorrect dimension or is undefined. Defaulting to zero');
end
if ~exist('B11','var')|| any(size(B11)~=[no,nw])
    B11=zeros(no,nw);
    disp('B11 has incorrect dimension or is undefined. Defaulting to zero')
end
if ~exist('B12','var')|| any(size(B12)~=[no,nu])
    B12=zeros(no,nu);
    disp('B12 has incorrect dimension or is undefined. Defaulting to zero')
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Check parameters related to PDE dynamics
if ~exist('A0','var') || any(size(A0)~= [np,np])
    disp('A0 has incorrect dimension or is undefined. Defaulting to zero');
    A0=zeros(np);
end

if ~exist('A1','var') || any(size(A1)~= [np,n1+n2])
    disp('A1 has incorrect dimension or is undefined. Defaulting to zero');
    A1=zeros(np,n1+n2);
end

if ~exist('A2','var') || any(size(A2)~=[np,n2])
    disp('A2 has incorrect dimension or is undefined. Defaulting to zero');
    A2=zeros(np,n2);
end

if ~exist('E','var')|| any(size(E)~=[np,no])
    disp('E has incorrect dimension or is undefined. Defaulting to zero');
    E = zeros(np,no);
end

if ~exist('B21','var')|| any(size(B21)~=[np,nw])
    B21=zeros(np,nw);
    disp('B21 has incorrect dimension or is undefined. Defaulting to zero')
end

if ~exist('B22','var')|| any(size(B22)~=[np,nu])
    B22=zeros(np,nu);
    disp('B22 has incorrect dimension or is undefined. Defaulting to zero')
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Check parameters related to Boundary conditions (mandatory variables)
if ~exist('B','var')|| any(size(B)~=[n1+2*n2,2*n1+4*n2])
    error('B has incorrect dimension or is undefined.');
end

if ~exist('Bx0','var')|| any(size(Bx0)~=[n1+2*n2,n0])
    disp('Bx0 has incorrect dimension or is undefined. Defaulting to zero');
    Bx0 = zeros(n1+2*n2,no);
end

if ~exist('Bw','var')||any(size(Bw)~=[n1+2*n2,nw])
    disp('Bw has incorrect dimension or is undefined. Defaulting to zero');
    Bw = zeros(n1+2*n2,nw);
end

if ~exist('Bu','var')||any(size(Bu)~=[n1+2*n2,nu])
    disp('Bu has incorrect dimension or is undefined. Defaulting to zero');
    Bu = zeros(n1+2*n2,nu);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Check parameters related to regulated output
if ~exist('C1','var')||any(size(C1)~=[nz,no])
    C1=zeros(nz,no);
    disp('C1 has incorrect dimension or is undefined. Defaulting to zero')
end
if ~exist('C10','var')||any(size(C10)~=[nz,2*n1+4*n2])
    C10=zeros(nz,2*n1+4*n2);
    disp('C10 has incorrect dimension or is undefined. Defaulting to zero')
end
if ~exist('Ca1','var')||any(size(Ca1)~=[nz,np])
    Ca1=zeros(nz,np);
    disp('Ca1 has incorrect dimension or is undefined. Defaulting to zero')
end
if ~exist('Cb1','var')||any(size(Cb1)~=[nz,n1+n2])
    Cb1=zeros(nz,n1+n2);
    disp('Cb1 has incorrect dimension or is undefined. Defaulting to zero')
end
if ~exist('D11','var')||any(size(D11)~=[nz,nw])
    D11=zeros(nz,nw);
    disp('D11 has incorrect dimension or is undefined. Defaulting to zero')
end
if ~exist('D12','var')||any(size(D12)~=[nz,nu])
    D12=zeros(nz,nu);
    disp('D12 has incorrect dimension or is undefined. Defaulting to zero')
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Check parameters related to sensed output
if ~exist('C2','var')||any(size(C2)~=[ny,no])
    C2=zeros(ny,no);
    disp('C2 has incorrect dimension or is undefined. Defaulting to zero')
end
if ~exist('C20','var')||any(size(C20)~=[ny,2*n1+4*n2])
    C20=zeros(ny,2*n1+4*n2);
    disp('C20 has incorrect dimension or is undefined. Defaulting to zero')
end
if ~exist('Ca2','var')||any(size(Ca2)~=[ny,np])
    Ca2=zeros(ny,np);
    disp('Ca2 has incorrect dimension or is undefined. Defaulting to zero')
end
if ~exist('Cb2','var')||any(size(Cb2)~=[ny,n1+n2])
    Cb2=zeros(ny,n1+n2);
    disp('Cb2 has incorrect dimension or is undefined. Defaulting to zero')
end
if ~exist('D21','var')||any(size(D21)~=[ny,nw])
    D21=zeros(ny,nw);
    disp('D21 has incorrect dimension or is undefined. Defaulting to zero')
end
if ~exist('D22','var')||any(size(D22)~=[ny,nu])
    D22=zeros(ny,nu);
    disp('D22 has incorrect dimension or is undefined. Defaulting to zero')
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Define auxiliary variables to convert ODE-PDE to PIE
T = [eye(n1) zeros(n1,n2) zeros(n1,n2);
     eye(n1) zeros(n1,n2) zeros(n1,n2);
     zeros(n2,n1) eye(n2) zeros(n2);
     zeros(n2,n1) eye(n2) (b-a)*eye(n2);
     zeros(n2,n1) zeros(n2) eye(n2);
     zeros(n2,n1) zeros(n2) eye(n2)];
Q = [zeros(n1,n0) zeros(n1) zeros(n1,n2);
     zeros(n1,n0) eye(n1) zeros(n1,n2);
     zeros(n2,n0) zeros(n2,n1) zeros(n2);
     zeros(n2,n0) zeros(n2,n1) (b-theta)*eye(n2);
     zeros(n2,n0) zeros(n2,n1) zeros(n2);
     zeros(n2,n0) zeros(n2,n1) eye(n2)];
K = [zeros(n0,n1) zeros(n0,n2) zeros(n0,n2);
     eye(n1) zeros(n1,n2) zeros(n1,n2);
     zeros(n2,n1) eye(n2) (s-a)*eye(n2)];
L0 = [eye(n0) zeros(n0,n1) zeros(n0,n2);
     zeros(n1,n0) zeros(n1) zeros(n1,n2);
     zeros(n2,n0) zeros(n2,n1) zeros(n2)];
L1 = [zeros(n0) zeros(n0,n1) zeros(n0,n2);
     zeros(n1,n0) eye(n1) zeros(n1,n2);
     zeros(n2,n0) zeros(n2,n1) (s-theta)*eye(n2)];
V = [zeros(n1,n1) zeros(n1,n2) zeros(n1,n2);
     zeros(n2,n1) zeros(n2,n2) eye(n2)];
F0 = [zeros(n1,n0) eye(n1) zeros(n1,n2);
      zeros(n2,n0) zeros(n2,n1) zeros(n2)];
F1 = [zeros(n1,n0) zeros(n1) zeros(n1,n2);
      zeros(n2,n0) zeros(n2,n1) eye(n2)];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Test for well-posedness of Boundary conditions

if rcond(B*T)<1e-15
    error('Defined boundary conditions are not well-posed or have periodic boundary conditions');
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Converts ODE-PDE to PIE and defines PI operators
disp('Converting ODE-PDE to PIE');

opvar H0 H1 Hbf;
% H0 maps [xo x1 x2s x3ss] to [xo x1 x2 x3] 
H0.P = eye(no); H0.Q1 = zeros(no,np); H0.Q2 = K*inv(B*T)*Bx0;
H0.R.R0 = L0;
H0.R.R1 = L1 -K*inv(B*T)*B*Q; H0.R.R2 = -K*inv(B*T)*B*Q;
H0.dim = [no no; np np];
H0.I = [a b];
H0.var1 = s;
H0.var2 = theta;

% H1 maps [xo x1 x2s x3ss] to [x2s x3s]
H1.Q2 = V*inv(B*T)*Bx0;
H1.R.R0 = F0; 
H1.R.R1 = F1 - V*inv(B*T)*B*Q; H1.R.R2 = - V*inv(B*T)*B*Q;
H1.dim = [0 no; n1+n2 np];
H1.I = [a b];
H1.var1 = s;
H1.var2 = theta;

% Hbf maps [xo x1 x2s x3ss] to [x2(0) x2(L) x3(0) x3(L) x3s(0) x3s(L)]
Hbf.P = T*inv(B*T)*Bx0;
Hbf.Q1 = var_swap(-T*inv(B*T)*B*Q+Q, s, theta);
Hbf.dim = [2*n1+4*n2 no; 0 np];
Hbf.I = [a b];
Hbf.var1 = s;
Hbf.var2 = theta;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Convert parameters related to A's and E's to PI operator
opvar EAop EBop;
% EAop is integral operator on [xo x1 x2 x3]
EAop.Q1 = Ea; 
EAop.dim = [no no;0 np]; 
EAop.I = [a b]; EAop.var1 = s; EAop.var2 = theta;
%Ebop is integral operator on [x2s x3s]
EBop.Q1 = Eb;
EBop.dim = [no 0;0 n1+n2]; 
EBop.I = [a b]; EBop.var1 = s; EBop.var2 = theta;
% Af1 captures effect of [xo x1 x2s x3ss] on dynamics of ODE
Af1 = E0*Hbf+EAop*H0+EBop*H1;
Af1.P = Af1.P+A;

% Af2 captures effect of [xo x1 x2s x3ss] on dynamics of PDE
opvar A2p; 
A2p.R.R0 = [zeros(np,n0) zeros(np,n1) A2]; A2p.dim = [0 no; np np];
A2p.var1 = s; A2p.var2 = theta; A2p.I = [a b]; 
%Ip is temp variable, maps [xo x1 x2 x3] to [x1 x2 x3]
opvar Ip; 
Ip.R.R0 = eye(np); Ip.dim = [0 no; np np];  
Ip.var1 = s; Ip.var2 = theta; Ip.I = [a b]; 

Af2 = A0*Ip*H0+A1*H1+A2p;
Af2.Q2 = Af2.Q2+E;
% Af = [A     E1*H3+EA*H0+EB*H2;
%       E     A0*Ip*H0+A1*H2+[zeros(np,n0) zeros(np,n1) A2]];
Af = [Af1; Af2];
clear Af1 Af2 EAop EBop A2p;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Convert all C's to PI operators
opvar CA1 CB1 CA2 CB2;
% CA1 and CA2 integral operators on [x1 x2 x3] 
CA1.Q1 = Ca1; CA1.dim = [nz no;0 np]; 
CA1.I = [a b]; CA1.var1 = s; CA1.var2 = theta;
CA2.Q1 = Ca2; CA2.dim = [ny no;0 np];
CA2.I = [a b];CA2.var1 = s;CA2.var2 = theta;
% CB1 and CB2 integral operators on [x2s x3s]
CB1.Q1 = Cb1; CB1.dim = [nz 0;0 n1+n2];
CB1.I = [a b]; CB1.var1 = s; CB1.var2 = theta;
CB2.Q1 = Cb2; CB2.dim = [ny 0;0 n1+n2];
CB2.I = [a b];CB2.var1 = s;CB2.var2 = theta;
%Assemble final C operator
Cf1 = C10*Hbf + CA1*H0 + CB1*H1; 
Cf1.P = Cf1.P + C1;
Cf2 = C20*Hbf + CA2*H0 + CB2*H1; 
Cf2.P = Cf2.P + C2;

clear CA1 CB1 CA2 CB2;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Convert all B's and D's to PI operators
opvar Bf1 Bf2 Df11 Df12 Df21 Df22;

% Assemble B operator
Bf1.P = B11;
Bf1.Q2 = B21;
Bf1.dim = [no nw; np 0];
Bf1.I = [a b];Bf1.var1 = s;Bf1.var2 = theta;
Bf2.P = B12;
Bf2.Q2 = B22;
Bf2.dim = [no nu; np 0];
Bf2.I = [a b];Bf2.var1 = s;Bf2.var2 = theta;

%Assemble D operators
Df11.P = D11; Df11.dim = [nz nw; 0 0]; Df11.I = [a b];
Df12.P = D12; Df12.dim = [nz nu; 0 0]; Df12.I = [a b];
Df21.P = D21; Df21.dim = [ny nw; 0 0]; Df21.I = [a b];
Df22.P = D22; Df22.dim = [ny nu; 0 0]; Df22.I = [a b];

Eop = H0;
Aop = Af;
C1op = Cf1;
C2op = Cf2;
B1op = Bf1;
B2op = Bf2;
D12op = Df12;
D11op = Df11;
D21op = Df21;
D22op = Df22;
nx1 = no; nx = no; nx2 = np; nxb = np;

%remove unnecessary vars
clear Af Cf1 Cf2 Bf1 Bf2 Df11 Df22 Df12 Df21; 