% date: 6/13/2019
% Test for stability of the linear coupled PDE equation 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This program determines stability of a linear PDE which is defined
% in the format given below.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% System Definition:
% \dot x(t,s)=A0(s)[x_1(t,s)] + A1(s)[x_2s(t,s)] + A2(s)[x_3ss(t,s)]
%                  [x_2(t,s)]        [x_3s(t,s)]
%                  [x_3(t,s)]
                                    
% % Boundary conditions are of the form 
% % B[x_2(a)       
% %   x_2(b)
% %   x_3(a)
% %   x_3(b)
% %   x_3s(a)
% %   x_3s(b)]=0

% To test for stability, we solve the following feasibility problem
% after rewriting the system in fundamental state form which is
% \dot(x)(t,s) = (Af xf)(t,s) + E(s) z(t)
% \dot(z)(t,s)   = (Ef xf)(t,s) + A z(t)
% % % Find P, such that
% % %  P > 0
% % %  Af* P + P Af <= 0
% % %  

% User Inputs:
% A0(s)  -  matrix function of s of dimension n1+n2+n3 x n1+n2+n3 
% A1(s)  -  matrix function of s of dimension n1+n2+n3 x n2+n3
% A2(s)  -  matrix function of s of dimension n1+n2+n3 x n3
% B      -  matrix of dimension n2+2*n3 x n1+n2+n3 (must be full row rank)
% a,b    -  \R x \R - interval of the domain - s \in [a,b]
% eppos  -  for strict positivity
% epsneg (optional) - epsneg >0 for strictness of the negativity of derivative 
%
% here 
% n1 - dimension of x_1 (can be 0)
% n2 - dimension of x_2 (can be 0)
% n3 - dimension of x_3 (can be 0)



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% internal variables:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc; clear;
% setup pvars and other internal parameters
pvar s theta;
n_order = 2; 
eppos = 1e-2;
epneg = 1e-3; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%USER INPUT START%%

% Always stable
% standard heat equation 1D, with fixed boundaries
n1=0;n2=0;n3=1; np = n1+n2+n3;
a=0;b=1;
A0=0; A1=0; A2=1;
on = eye(np); zer = zeros(np);
B = [on zer zer zer;
     zer on zer zer];
 
% % Stable for R<2.7; 
% % Coupled reaction equation
% % output y(t) = int(x1(t,s),a,b) ds
% R=2.7-1e-5; n1=0;n2=0;n3=2; np = n1+n2+n3;
% A0 = [1 1.5;
%       5 0.2]; 
% A1= zeros(n2+n3);
% A2=(1/R)*[1 0; 0 1];
% a=0; b= 1;
% on = eye(np); zer = zeros(np);
% B = [on zer zer zer;
%      zer on zer zer];

% % Stable for lamb<=pi^2,
% n1=0;n2=0;n3=1;np = n1+n2+n3;
% lamb = (1+1e-3)*pi^2; %lamb=2.0;
% A0=lamb; A1=0; A2=1;
% a=0; b= 1;
% B = [1 0 0 0;
%      0 1 0 0];

% % % stable for lambda<=2.467,
% n1=0;n2=0;n3=1;np = n1+n2+n3;
% lamb = 2.45; 
% A0 = lamb; A1 = 0; A2 = 1;
% a=0; b= 1;
% on = eye(np); zer = zeros(np);
% B = [on zer zer zer;
%      zer zer zer on];

% % Stable for lambda<=4.65,
% n1=0;n2=0;n3=1;np = n1+n2+n3;
% lamb = 4.; 
% A0 = -0.5*s^3+1.3*s^2-1.5*s+0.7+lamb;
% A1 = 3*s^2-2*s; A2 = s^3-s^2+2;
% a=0; b= 1;
% on = eye(np); zer = zeros(np);
% B = [on zer zer zer;
%      zer zer zer on];

% % stable for R<=21,
% % output y(t) = int(x1(t,s),a,b) ds
% n1=0;n2=0;n3=3;np = n1+n2+n3;
% R = (21-1e-3); 
% A0 = [0 0 0; s 0 0; s^2 -s^3 0]; A1 = zeros(np); 
% A2= (1/R)*eye(np);
% a=0; b= 1;
% on = eye(np); zer = zeros(np);
% B = [on zer zer zer;
%      zer on zer zer];

% tip damped wave equation,
% output y(t) = int(x1(t,s),a,b) ds
% n1=0;n2=2;n3=0;np = n1+n2+n3;
% k =0.5; A1 = [0 1; 1 0]; A0 = zeros(np); A2 = zeros(np,n3);
% a=0; b= 1;
% on = eye(n3); zer = zeros(n3);
% B = [0 1 0 0; 0 0 k 1];

%%EB beam
n1 =0; n2 = 0; n3=2;
c=1;
np = n1+n2+n3; A0 = zeros(np); A1 = zeros(np,n2+n3); A2= [0 -c;1 0];
a=0; b=1;
B = [1 0 0 0 0 0 0 0; 
     0 0 0 1 0 0 0 0;
     0 0 0 0 1 0 0 0;
     0 0 0 0 0 0 0 1];

% %%USER INPUT END%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% setup an SOS program
varlist = [s; theta];
prog = sosprogram(varlist);

% domain of spatial variables
X = [a b];

% p-compact form of the interval
g1 = (X(2)-s)*(s-X(1));


% setup the variables for lyapunov function candidate
disp('Parameterizing Positive function');
opts.full = 0; 
[prog, Pv] = sos_posopvar(prog,[0 np],X,s,theta,[n_order/2,n_order],opts);

% enforce strict positivity on the operator
Pv.R.R0 = Pv.R.R0+eppos*eye(np);

% setup H,Af operators for the system
% assemble_operators_stab_pde;
setup_ops_fstate;

disp('Computing the derivative');
% Pheq = Af* P + P Af
Pheq = H'*(Pv*Af)+Af'*(Pv*H);
% Pheq = H*(Pv*Af')+Af*(Pv*H'); % dual form

%getting multiplier and kernel for derivative lyapunov function
disp('Parameterizing the negative operators');
% use the next two lines if multiplier is necessary, ie n1~=0
% [prog, Pe] = sospos_L2L_matker(prog, np, n_order1+3, n_order2+3, s, theta, X);
% [prog, Pf] = sospos_L2L_matker_psatz(prog, np, n_order1+3, n_order2+3, s, theta, X);

% use the next two lines if multiplier is not necessary, ie n1=0
opts1.full = 1; opts1.pure = 1; opts1.psatz = 0;
opts2.full = 1; opts2.pure = 1; opts2.psatz = 1;
[prog, Pe] = sos_posopvar(prog,[0 np],X, s, theta, [2, 2],opts1);
[prog, Pf] = sos_posopvar(prog,[0 np],X, s, theta, [2, 2],opts2);

% derivative negativity
% constraints
disp('Setting up the equality constraints');
prog = sosopeq(prog,Pe+Pf+Pheq); %Pe+Pf+Pheq=0

% choosing a different solver if needed
% option.solver = 'mosek'; 

%solving the sos program
prog = sossolve(prog); 

% Conclusion:
if norm(prog.solinfo.info.feasratio-1)<=.1 && ~prog.solinfo.info.numerr
    disp('The System is Stable.')
elseif norm(prog.solinfo.info.feasratio-1)<=.1 && prog.solinfo.info.numerr
    disp('The System is likely Stable. However, Double-check the precision.')
elseif prog.solinfo.info.pinf || prog.solinfo.info.dinf || norm(prog.solinfo.info.feasratio+1)<=.1
    disp('The System is Probably not Stable.')
else
    disp('Unable to definitively determine feasibility. Numerical errors dominating or at the limit of stability.')
end