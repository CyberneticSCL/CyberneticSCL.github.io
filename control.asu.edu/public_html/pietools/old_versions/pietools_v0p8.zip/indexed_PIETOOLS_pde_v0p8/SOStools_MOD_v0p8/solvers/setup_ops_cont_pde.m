setup_ops_fstate;

%Bf
opvar Bf;
Bf.Q2 = B1;
Bf.dim = [0 nw; np 0];
Bf.var1 = s; Bf.var2 =  theta; Bf.I = [a b];

%Bf
opvar Bf2;
Bf2.Q2 = B2;
Bf2.dim = [0 nu; np 0];
Bf2.var1 = s; Bf2.var2 =  theta; Bf2.I = [a b];

% convert operator E to fundamental state operator Ef
opvar CA CB;
CA.Q1 = Ca; CB.Q1 = Cb;
CA.dim = [nz 0;0 np];
CA.I = [a b];
CA.var1 = s;
CA.var2 = theta;
CB.dim = [nz 0;0 n2+n3];
CB.I = [a b];
CB.var1 = s;
CB.var2 = theta;

Cf = C1*H3+CA*H+CB*H2;
