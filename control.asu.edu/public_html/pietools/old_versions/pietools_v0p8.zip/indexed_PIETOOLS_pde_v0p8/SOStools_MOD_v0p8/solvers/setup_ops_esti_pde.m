setup_ops_fstate;

%Bf
opvar Bf;
Bf.Q2 = B1;
Bf.dim = [0 nw; np 0];
Bf.var1 = s; Bf.var2 =  theta; Bf.I = [a b];

% convert operator E to fundamental state operator Ef
opvar CA CB CA2 CB2;
CA.Q1 = Ca; CB.Q1 = Cb;
CA.dim = [nz 0;0 np];
CA.I = [a b];
CA.var1 = s;
CA.var2 = theta;
CB.dim = [nz 0;0 n2+n3];
CB.I = [a b];
CB.var1 = s;
CB.var2 = theta;

Cf = C1*H3+CA*H+CB*H2;

CA2.Q1 = Ca2; CB2.Q1 = Cb2;
CA2.dim = [ny 0;0 np];
CA2.I = [a b];
CA2.var1 = s;
CA2.var2 = theta;
CB2.dim = [ny 0;0 n2+n3];
CB2.I = [a b];
CB2.var1 = s;
CB2.var2 = theta;

Cf2 = C2*H3+CA2*H+CB2*H2;
