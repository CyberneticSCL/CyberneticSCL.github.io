setup_ops_fstate;

opvar Bf Cf CA CB;

CA.Q1 = Ca; CB.Q1 = Cb;
CA.P = zeros(ny,0); CB.P = zeros(ny,0); 
CA.R.R0 = zeros(0,np);CA.R.R1 = zeros(0,np);CA.R.R2 = zeros(0,np);
CB.R.R0 = zeros(0,np);CB.R.R1 = zeros(0,np);CB.R.R2 = zeros(0,np);
CA.I = [a b];
CA.var1 = s;
CA.var2 = theta;
CB.I = [a b];
CB.var1 = s;
CB.var2 = theta;

%Assemble B operator
Bf.Q2 = B1;
Bf.P = zeros(0,nw); 
Bf.R.R0 = zeros(np,0);Bf.R.R1 = zeros(np,0);Bf.R.R2 = zeros(np,0);
Bf.I = [a b];
Bf.var1 = s;
Bf.var2 = theta;

%Assemble C operator
Cf = C1*H3 + CA*H + CB*H2; 