np = n1+n2+n3;


T = [eye(n2) zeros(n2,n3) zeros(n2,n3);
     eye(n2) zeros(n2,n3) zeros(n2,n3);
     zeros(n3,n2) eye(n3) zeros(n3);
     zeros(n3,n2) eye(n3) (b-a)*eye(n3);
     zeros(n3,n2) zeros(n3) eye(n3);
     zeros(n3,n2) zeros(n3) eye(n3)];
Q = [zeros(n2,n1) zeros(n2) zeros(n2,n3);
     zeros(n2,n1) eye(n2) zeros(n2,n3);
     zeros(n3,n1) zeros(n3,n2) zeros(n3);
     zeros(n3,n1) zeros(n3,n2) (b-theta)*eye(n3);
     zeros(n3,n1) zeros(n3,n2) zeros(n3);
     zeros(n3,n1) zeros(n3,n2) eye(n3)];
K = [zeros(n1,n2) zeros(n1,n3) zeros(n1,n3);
     eye(n2) zeros(n2,n3) zeros(n2,n3);
     zeros(n3,n2) eye(n3) (s-a)*eye(n3)];
L0 = [eye(n1) zeros(n1,n2) zeros(n1,n3);
     zeros(n2,n1) zeros(n2) zeros(n2,n3);
     zeros(n3,n1) zeros(n3,n2) zeros(n3)];
L1 = [zeros(n1) zeros(n1,n2) zeros(n1,n3);
     zeros(n2,n1) eye(n2) zeros(n2,n3);
     zeros(n3,n1) zeros(n3,n2) (s-theta)*eye(n3)];
V = [zeros(n2,n2) zeros(n2,n3) zeros(n2,n3);
     zeros(n3,n2) zeros(n3,n3) eye(n3)];
F0 = [zeros(n2,n1) eye(n2) zeros(n2,n3);
      zeros(n3,n1) zeros(n3,n2) zeros(n3)];
F1 = [zeros(n2,n1) zeros(n2) zeros(n2,n3);
      zeros(n3,n1) zeros(n3,n2) eye(n3)];

opvar H H2 H3;
%--------------------------------------------------------------------------
disp('Converting all states to fundamental state');
% H maps [x1 x2s x3ss] to [x1 x2 x3] 
H.Q1 = zeros(0,np); H.Q2 = zeros(np,0);
H.R.R0 = L0;
H.R.R1 = L1 -K*inv(B*T)*B*Q; H.R.R2 = -K*inv(B*T)*B*Q;
H.I = [a b];
H.var1 = s;
H.var2 = theta;

% H2 maps [x1 x2s x3ss] to [x2s x3s]
H2.Q1 = zeros(0,np); H2.Q2 = zeros(n2+n3,0);
H2.R.R0 = F0; 
H2.R.R1 = F1 - V*inv(B*T)*B*Q; H2.R.R2 = - V*inv(B*T)*B*Q;
H2.I = [a b];
H2.var1 = s;
H2.var2 = theta;

% H3 maps [x1 x2s x3ss] to [x2(0) x2(L) x3(0) x3(L) x3s(0) x3s(L)]
H3.Q2 = zeros(0,0);
H3.R.R0 = zeros(0,np);H3.R.R1 = zeros(0,np);H3.R.R2 = zeros(0,np);
H3.P = zeros(2*n2+4*n3,0);
H3.Q1 = -T*inv(B*T)*B*Q+Q;
H3.I = [a b];
H3.var1 = s;
H3.var2 = theta;

A2p = H; A2p.R.R0 = [zeros(n1) zeros(n2) A2]; A2p.R.R1 = zeros(np); 
A2p.R.R2 = zeros(np);
%Assemble A operator, that is get Af from Ai
Af = (A0)*H + (A1)*H2 + A2p;
Af.I = [a b];
Af.var1 = s;
Af.var2 = theta;