% date: 6/13/2019
% hinf of the equation u_t = A0*u + A1*u_s+ A2*u_ss +B1w;
% u = u(s,t);
% boundary conditions B[u2(0) u2(L) u3(0) u3(L) u3_s(0) u3_s(L)]=0
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This program determines Hinf norm of a linear PDE which is defined
% in the format given below.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% System Definition:
% System Definition:
% \dot x(t,s)=A0(s)[x_1(t,s)] + A1(s)[x_2s(t,s)] + A2(s)[x_3ss(t,s)]+E(s)z(t)+B1(s)w(t) + B3 u(t)
%                  [x_2(t,s)]        [x_3s(t,s)]
%                  [x_3(t,s)]
% \dot z(t) =  Az(t)+ E1 [x_2(a) + int_a^b Ea(s) [x_1(t,s)]  ds + int_a^b Eb(s) [x_2s(t,s)] ds + B2w(t) + B4 u(t)
%                         x_2(b)                 [x_2(t,s)]                     [x_3s(t,s)]
%                         x_3(a)                 [x_3(t,s)]
%                         x_3(b)
%                         x_3s(a)
%                         x_3s(b)] 
% y(t) =  Cz(t) + C1 [x_2(a) + int_a^b Ca(s) [x_1(t,s)]  ds + int_a^b Cb(s) [x_2s(t,s)] ds + D1w(t) + D2 u(t)
%                     x_2(b)                 [x_2(t,s)]                     [x_3s(t,s)]
%                     x_3(a)                 [x_3(t,s)]
%                     x_3(b)
%                     x_3s(a)
%                     x_3s(b)] 
% % Boundary conditions are of the form 
% % B[x_2(a)       
% %   x_2(b)
% %   x_3(a)
% %   x_3(b)
% %   x_3s(a)
% %   x_3s(b)]=Bz z(t)

%
% Inputs:
% A      - matrix of dimension no x no
% A0(s)  -  matrix function of s of dimension n1+n2+n3 x n1+n2+n3 
% A1(s)  -  matrix function of s of dimension n1+n2+n3 x n2+n3
% A2(s)  -  matrix function of s of dimension n1+n2+n3 x n3
% E(s)      - matrix function in s of dimension np x no
% E1     -  matrix of dimension no x 2n2+4n3
% Ea(s)  -  matrix valued function of s of dimension no x n1+n2+n3
% Eb(s)  -  matrix valued function of s of dimension no x n2+n3
% B      -  matrix of dimension n2+2*n3 x n1+n2+n3 (must be full row rank)
% Bz     -  matrix of dimension n2+2*n3 x no
% B1(s)  -  matrix valued polynomial of s of dimension n1+n2+n3 x nw
% B2     -  matrix of dimension no x nw
% a,b    -  \R x \R - interval of the domain - s \in [a,b]
% C1     -  matrix of dimension ny x 2n2+4n3
% Ca(s)  -  matrix valued function of s of dimension ny x n1+n2+n3
% Cb(s)  -  matrix valued function of s of dimension ny x n2+n3
% D      -  matrix of dimension ny x nw
% eppos  -  for strict positivity
% epsneg (optional) - epsneg >0 for strictness of the negativity of derivative 
%
% here 
% no - dimension of z (cant be 0)
% n1 - dimension of x_1 (can be 0)
% n2 - dimension of x_2 (can be 0)
% n3 - dimension of x_3 (can be 0)
% ny - dimension of y(t)(cant be 0)
% nw - dimension of w(t)(cant be 0)

% To find a bound on Hinf norm, we solve the following optimization problem
% after rewriting the system in fundamental state form which is
% H\dot(xf)(t,s) = (Af xf)(t,s) + B1(s) w(t)
% y(t) = (C xf)(t,s) + D w(t)
% % % minimize gamma
% % %  P > 0
% % % [ -gamma*I    D'          (B* P H)
% % %   D           -gamma*I     C
% % %   (H* P B)        C*      (Af* P H + H* P Af)] <=0 
% where gamma is a bound on the Hinf norm and * represents operator
% adjoint

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% internal variables:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc; clear;
% setup pvars and other internal parameters
pvar s theta;
n_order1 = 1; 
n_order2 = 1;
eppos = 1e-2;
epneg = 1e-3; 

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%USER INPUT START%%
%%Time delay systems
% % x_t = -x(t)+x(t-tau)+d(t)
% nw = 1; nu =1;
% no = 1; n1=0; n2 =1; n3 =0;
% np = n1+n2+n3; ny = 1;
% tau = 3;
% 
% A=-1; A0 = zeros(np); A1 = 1/tau; A2 = zeros(n3);
% E = 0; E1 = -[1 0]; Ea = zeros(np,np); Eb = zeros(np,n2+n3);
% B2 = 1; B1 = 0; B3 = 0; B4 =1;
% C = 1; C1 = [0 0]; Ca = zeros(ny,np); Cb = zeros(ny,n2+n3);
% D1 = 0; D2 = 0;
%   
% B=[0 1];
% Bz = eye(no);
% a = 0; b =1;

% % x_t = -x(t-tau)
nw = 1; nu =1; ny =1;
no = 1; n1=0; n2 =1; n3 =0; np = n1+n2+n3;
A = 0; E = 0;
tau = pi/2 + 1e-2; %stable if tau<=pi/2
A0 = 0; A1 = 1/tau; A2 = zeros(n3);
E1 = -[1 0]; Ea = 0; Eb = 0;
B2 = 1; B1 = 0; B3 = 0; B4 =1;
C = 1; C1 = [0 0]; Ca = zeros(ny,np); Cb = zeros(ny,n2+n3);
D1 = 0; D2 = 0;
B=[0 1];
Bz = [1];
a = 0; b =1;

% %%USER INPUT END%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% setup an SOS program
varlist = [s; theta];
prog = sosprogram(varlist);

% domain of spatial variables
X = [a b];

% p-compact form of the interval
g1 = (X(2)-s)*(s-X(1));

% hinf norm variable which needs to be minimized
pvar gamma;
prog = sosdecvar(prog, gamma); %this sets gamma as decision var
% prog = sossetobj(prog, gamma); %this minimizes gamma, comment for feasibility test

% setup the variables for lyapunov function candidate
disp('Parameterizing Positive function');
[prog, Pv] = sospos_RL2RL(prog, [no ,np],X,s,theta,[n_order1, n_order2]);

% enforce strict positivity on the operator
Pv.P = Pv.P+eppos*eye(no);
Pv.R.R0 = Pv.R.R0+eppos*eye(np);  

% setup H,A,B,C,D operators for the system
setup_ops_hinf_odepde;

Zs = monomials(s,0:n_order1+2);
[prog,Z1] = sospolymatrixvar(prog,monomials(s,0),[nu no]);
[prog,Z2] = sospolymatrixvar(prog,Zs,[nu np]);
opvar Pz;

opvar Bf2; Bf2.Q2 = B3; Bf2.P = B4;
Bf2.dim = [no nu; np 0]; Bf2.I = [a,b]; Bf2.var1 = s; Bf2.var2 = theta;

Pz.P = Z1;
Pz.Q1 = Z2; Pz.dim = [nu no; 0 np]; Pz.I = [a,b]; Pz.var1 = s; Pz.var2 = theta;

%Assemble the big operator
% Pheq = [ -gamma*I  D'       B*PH
%          D         -gamma*I C
%          H*PB      C*       A*Ph+H*PA]
Pheq = [-gamma*eye(ny)            D1              (Cf*Pv+D2*Pz)*H';
        D1'                      -gamma*eye(nw)   (H*Bf)';
        H*(Cf*Pv+D2*Pz)'          H*Bf            (Af*Pv+Bf2*Pz)*H'+H*(Af*Pv+Bf2*Pz)']; 

disp('Parameterize the derivative inequality');


%getting multiplier and kernel for derivative lyapunov function
disp('Parameterizing the negative operators');
[prog, Pe] = sospos_RL2RL_noR0(prog, [nw+ny+no, np],X,s,theta, [n_order1+2, n_order2+2]);
[prog, Pf] = sospos_RL2RL_noR0_psatz(prog,[nw+ny+no, np],X,s,theta, [n_order1+2, n_order2+2]);

% derivative negativity
% constraints
disp('Setting up the equality constraints');
prog = sosopeq(prog,Pe+Pf+Pheq); %Pe+Pf+Pheq=0

% choosing a different solver if needed
% option.solver = 'mosek'; 

%solving the sos program
prog = sossolve(prog); 

disp(double(sosgetsol(prog,gamma))); % check the Hinf norm, if the solved successfully


% Conclusion:
if norm(prog.solinfo.info.feasratio-1)<=.1 && ~prog.solinfo.info.numerr
    disp('The System of equations was successfully solved.')
elseif norm(prog.solinfo.info.feasratio-1)<=.1 && prog.solinfo.info.numerr
    disp('The System  of equations was successfully solved. However, Double-check the precision.')
elseif prog.solinfo.info.pinf || prog.solinfo.info.dinf || norm(prog.solinfo.info.feasratio+1)<=.1
    disp('The System is  of equations not solved.')
else
    disp('Unable to definitively determine feasibility. Numerical errors dominating or at the limit of stability.')
end