% date: 7/24/2019
% Find the operator norm of a PI operator
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This program finds a bound on the operator norm of the PI operator
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The code searches for L2 operator norm of a PI operator A.
% || A || = sup || Ax ||/ || x ||
% This can be reformulated as 
% minimize gamma^2, s.t.
% <Ax,Ax> <= gamma^2 <x,x>

% User Inputs:
% A - operator in PI format with P, Q1, Q2, R.R0, R.R1, R.R2 components
% dim - dimensions of domain and codomain of the vector space [p m; q n];
%       A: R^m x L2^n --> R^p x L2^q
% a,b    -  \R x \R - interval of the domain - s \in [a,b]
% eppos  -  for strict positivity
% epsneg (optional) - epsneg >0 for strictness of the negativity of derivative 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% internal variables:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc; clear;
% setup pvars and other internal parameters
pvar s theta;
n_order1 = 1; 
n_order2 = 1;
eppos = 1e-2;
epneg = 1e-3; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%USER INPUT START%%

% Ex 1: Ax(s) = int(x(t),t, 0, s); volterra integral operator
% analytical bound 2/pi
opvar A;
a = 0; b = 1;
A.P = [];
A.Q1 = [];
A.Q2 = [];
A.R.R0 = 0;
A.R.R1 = s*theta-theta;
A.R.R2 = s*theta-s;
A.dim = [0 0; 1 1];
A.var1 = s;
A.var2 = theta;
A.I = [a,b];

% opvar A;
% a = 0; b = 1;
% A.P = [];
% A.Q1 = [];
% A.Q2 = [];
% A.R.R0 = 2*s^2-4*s^3;
% A.R.R1 = s-theta;
% A.R.R2 = 0;
% A.dim = [0 0; 1 1];
% A.var1 = s;
% A.var2 = theta;
% A.I = [a,b];

%%USER INPUT END%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
pvar gam;
opvar Gam;
X = A.I;
Gam.dim = A.dim; Gam.var1 = A.var1; Gam.var2 = A.var2; Gam.I = A.I;

if A.dim(1,2)~=0
Gam.P = gam;
end
Gam.R.R0 = gam;
prog = sosprogram([s;theta],gam);
prog = sossetobj(prog, gam);
[prog, Pe] = sospos_RL2RL(prog, A.dim(:,2),X,s,theta, [n_order1+2, n_order2+2]);
[prog, Pf] = sospos_RL2RL_psatz(prog, A.dim(:,2),X,s,theta, [n_order1+2, n_order2+2]);


prog = sosopeq(prog, A'*A-Gam+Pe+Pf);

prog = sossolve(prog);

disp('Operator norm from SDP');
disp(sqrt(double(sosgetsol(prog,gam))));
disp('Analytical bound for volterra integral operator');
disp(2/pi);