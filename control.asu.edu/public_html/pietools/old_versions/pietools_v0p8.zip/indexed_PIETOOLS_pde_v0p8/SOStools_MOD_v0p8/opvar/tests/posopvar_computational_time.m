pvar s theta;
N = 1:20;
prog = sosprogram([s,theta]);
opts.full = 1; opts.pure = 0; opts.psatz = 1;
for np=N
    tic;
    [prog,P] = sos_posopvar(prog,[0,np],[0,1],s,theta,[1,2],opts);
    t(np) = toc;
end

opts.full = 0; opts.pure = 0; opts.psatz = 1;
for np=N
    tic;
    [prog,P] = sos_posopvar(prog,[0,np],[0,1],s,theta,[1,2],opts);
    t2(np) = toc;
end

plot(N,t,N,t2);
legend('Unrestricted factors','Restricted factors: LL*');
title('Time needed for positive operator parameterization');
xlabel('Number of PDE states');
ylabel('Wall time');
savefig('Posop_runtime.jpg');
