function [Z] = getmonomials(P,varlist)
% This function provides the min and max degree of the monomials present in
% the components of a PI operator. The result return is a 2D array with
% entries described as below.
% For a PI operator with components P,Q1(s),Q2(s),R0(s),R1(s,t),R2(s,t), 
% the function returns
% the following table.
% T = [  min_P_s  minP_t  max_P_s  max_P_t;
%        min_Q1_s minQ1_t max_Q1_s max_Q1_t;
%        min_Q2_s minQ2_t max_Q2_s max_Q2_t;
%        min_R0_s minR0_t max_R0_s max_R0_t;
%        min_R1_s minR1_t max_R1_s max_R1_t;
%        min_R2_s minR2_t max_R2_s max_R2_t]
% where the variables naming follows boundtype_componentname_variable.
% INPUTS:
% P : An opvar variable
% fprint: flag to decide whether the output should be printed. If set to 1
% the degree bounds will be printed
% OUTPUTS:
% T : Array containing min and max degree of monomials in the components of P
% 
% NOTES:
% Needs to be updated to work with matrices or opvars
%
%
% For support, contact M. Peet, Arizona State University at mpeet@asu.edu
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% PIETools - sos_opvar
%
% Copyright (C)2019  M. Peet, S. Shivakumar
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 2 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% If you modify this code, document all changes carefully and include date
% authorship, and a brief description of modifications
%
% Initial coding MMP, SS  - 7_26_2019
%

if ~isa(P,'opvar')
    error('Input must be an opvar variable.');
end

fset = {'Q1','Q2'};
for i =fset
    if ~isempty(P.(i{:}).varname)
    idx=[];
    degmat = P.(i{:}).degmat;
    vlist = {};
    for j=1:length(varlist)
        idx = [idx find(ismember(P.(i{:}).varname,varlist{j}))];
        if ~isempty(find(ismember(P.(i{:}).varname,varlist{j})))
            vlist{end+1} = varlist{j};
        end
    end
    degmat = degmat(:,idx);
    degmat = unique(degmat,'rows');
    Z.(i{:}) = polynomial(speye(length(degmat)),degmat, vlist, [length(degmat),1]);
    else
    Z.(i{:}) = [1];
    end
end
fset = {'R0','R1','R2'};
for i =fset
    if ~isempty(P.R.(i{:}).varname)
    idx=[];
    degmat = P.R.(i{:}).degmat;
    vlist = {};
    for j=1:length(varlist)
        idx = [idx find(ismember(P.R.(i{:}).varname,varlist{j}))];
        if ~isempty(find(ismember(P.R.(i{:}).varname,varlist{j})))
            vlist{end+1} = varlist{j};
        end
    end
    degmat = degmat(:,idx);
    degmat = unique(degmat,'rows');
    Z.R.(i{:}) = polynomial(speye(length(degmat)),degmat, vlist, [length(degmat),1]);
    else
        Z.R.(i{:}) = [1];
    end
end
end