clc; clear;
% testing initilization
pvar s theta;
prog = sosprogram([s,theta]);

% testing posopvar
X = [0 1];

n1 = [1,2]; d1 = [1,1];
opts_psatz.psatz = 0;
opts_pure.pure = 0;
opts_LU.full = 1;
[prog, P ] = sos_posopvar(prog,n1,X,s,theta,d1,opts_LU);
[prog, P2] = sos_posopvar_RL2RL(prog,n1,X,s,theta,d1);

% prog = sossolve(prog);

a = P-P2;