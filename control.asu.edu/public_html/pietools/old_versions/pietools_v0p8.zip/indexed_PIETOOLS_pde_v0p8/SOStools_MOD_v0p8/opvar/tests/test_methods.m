clc; clear;
% this file consists of tests for initiliazing and access of opvar class
pvar s theta;
I = [0, 1];

% Testing initialization
opvar P;

% Testing dimension property access method
P.P = rand(2); 
P.dim
P.Q2 = rand(2);
P.Q1 = zeros(2,0);
P.R.R0 = zeros(2,0);
P.dim 

% testing degree access
n = [2,3;2,3]; d= [1,2,3];
prog = sosprogram([s,theta]);
[prog, P] = sos_opvar(prog,n,I,s,theta,d);
getdeg(P,1)
