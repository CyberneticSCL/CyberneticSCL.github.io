clc; clear;
% testing initilization
pvar s theta;
opvar P1 P2;
prog = sosprogram([s,theta]);

%% testing posopvar
X = [0 1];

prog = sosprogram([s;theta]);
n1 = [1,2]; d1 = [1,1];
%test positive operator functions %solve a random sosprogram and test for
%positivity of the operator
opts_psatz.psatz = 1;
opts_pure.pure = 1;
opts_LU.full = 0;
[prog, P ] = sos_posopvar(prog,n1,X,s,theta,d1);
[prog, P1 ] = sos_posopvar(prog,n1,X,s,theta,d1,opts_psatz);
[prog, P2 ] = sos_posopvar(prog,n1,X,s,theta,d1,opts_pure);
[prog, P3 ] = sos_posopvar(prog,n1,X,s,theta,d1,opts_LU);
%% scalar multiplication
tau = 5;
tau*P1
P1*tau
%%
set = {'P','Q1','Q2','R'};

[prog, Phor] = sos_opvar(prog,[n1;n1],X,s,theta,d1);

a= Phor;

% date 6/13/19
b= Phor'; %transpose ok 

c = a+a; %addition ok

d = a-a; % subtraction ok

e = a*b; %composition ok

at = [0 1 2; 5 6 3; 5 7 3];
f = at*P; %multiply a matrix to the operator ok
g = P*at;
pvar s;
A = [ 1 s s^2; 0 2 3; s^3 3 2];
h = (A)*P; %multiply polynomial to the operator - ok
i = P*A;
%% testing concatenation
Phor = [P P];
Pver = [P;P];
Pmat1 = rand(2,2);
[prog, Pa] = sos_opvar(prog,[2,0;0,2],X,s,theta,d1);
[prog, Pb] = sos_opvar(prog,[0,2;2,0],X,s,theta,d1);
Phor2 = [Pmat1 Pa];
Phor3 = [Pa Pmat1];
Pver2 = [Pmat1; Pb];
Pver3 = [Pb; Pmat1];