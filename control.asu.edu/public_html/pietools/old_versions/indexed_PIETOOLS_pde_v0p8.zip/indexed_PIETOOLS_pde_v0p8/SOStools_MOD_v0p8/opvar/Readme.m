% List of PIETOOLS functions and descriptions
%
% NOTES:
% For support, contact M. Peet, Arizona State University at mpeet@asu.edu
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% PIETools - README
%
% Copyright (C)2019  M. Peet, S. Shivakumar
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 2 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% If you modify this code, document all changes carefully and include date
% authorship, and a brief description of modifications
%
% Initial coding MMP, SS  - 7_26_2019
%
% Current Problems to resolve before release:
%
% 1: horzcat and vertcat should work with both matrices and operators
%    needs a bit more testing, error control
% 2: need to add sos_opvar for declaring non-positive operator variables
%         MP: done, needs checking
% 3: need to include all sos_posopvar subroutines into a single function
% with multiple options in an option structure
%         MP: done, needs checking
% 4: need to add ability to limit semisep operators to LU structure
%         MP: done, needs checking
% 5: Need to improve error checking and error messages.
% 6: Need to comment code and add headers and CC Copyright to all files
% 7: Need to test/implement alternative opvar composition code
% 7a: Consider use of composition code in sos_posopvar
% 8: eliminate redundant code (sections of code cut/paste from others) and
% replace with function calls
% 9: Improve sosmatvar
% 10: use sosmatvar everywhere so that we can improve this functionality
% 11: Need opvar structure to be clear in defining empty entries. These are
% written as, e.g. Pop.Q1=[] or do they need to be written as
% Pop.Q1=polynomial([])? Must handle both cases
% 12: Code is too slow for release. Must handle 20 states before release.
% 13: Need to swap the degrees in Zsth in posopvar code so that degree of s
% in Zs matches degree of th in Zsth
%         MP: done, needs checking
%
%
%