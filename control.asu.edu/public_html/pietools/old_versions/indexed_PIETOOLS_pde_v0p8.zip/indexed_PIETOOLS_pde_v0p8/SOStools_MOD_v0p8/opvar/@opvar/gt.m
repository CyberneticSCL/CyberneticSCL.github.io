function T = gt(a,b)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function performs addition of two operators P: R^p x L2^q to R^m x L2^n
% Date: 6/13/19
% Version: 1.0
% INPUTS
% P1, P2: operators with the matlab structure as below
% P.dim: an 2x2 array with entries [m,p]
%                                  [n,q]
% P.P: a mxp matrix
% P.Q1: a mxq matrix valued polynomial in s
% P.Q2: a nxp matrix valued polynomial in s
% P.R.R0: a nxq matrix valued poynomial in s
% P.R.R1: a nxq matrix valued poynomial in s, theta
% P.R.R2: a nxq matrix valued poynomial in s, theta
% P.var1, P.var2: polynomial variables s, theta
% P.I: domain
% 
% OUTPUTS
% Pplus: returns P1+P2
%
% NOTES:
% For support, contact M. Peet, Arizona State University at mpeet@asu.edu
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% PIETools - plus
%
% Copyright (C)2019  M. Peet, S. Shivakumar
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 2 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% If you modify this code, document all changes carefully and include date
% authorship, and a brief description of modifications
%
% Initial coding MMP, SS  - 10_1_2019
%

prog_var = properties('sosprogram');

if isa(a,'opvar') && isa(b,'opvar')
    T = evalin('caller',sosopineq(prog_var,a-b,opts));
elseif isa(a,'opvar') && isa(b,'double')
    opvar B;
    B.P = b*eye(a.dim(1,1));
    B.R0 = b*eye(a.dim(2,2));
    T = evalin('caller',sosopineq(prog_var,a-B,opts));
end
end
