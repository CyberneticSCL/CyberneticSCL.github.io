function [Pplus] = plus(P1,P2) %addition
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function performs addition of two operators P: R^p x L2^q to R^m x L2^n
% Date: 6/13/19
% Version: 1.0
% INPUTS
% P1, P2: operators with the matlab structure as below
% P.dim: an 2x2 array with entries [m,p]
%                                  [n,q]
% P.P: a mxp matrix
% P.Q1: a mxq matrix valued polynomial in s
% P.Q2: a nxp matrix valued polynomial in s
% P.R.R0: a nxq matrix valued poynomial in s
% P.R.R1: a nxq matrix valued poynomial in s, theta
% P.R.R2: a nxq matrix valued poynomial in s, theta
% P.var1, P.var2: polynomial variables s, theta
% P.I: domain
% 
% OUTPUTS
% Pplus: returns P1+P2
%
% NOTES:
% For support, contact M. Peet, Arizona State University at mpeet@asu.edu
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% PIETools - plus
%
% Copyright (C)2019  M. Peet, S. Shivakumar
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 2 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% If you modify this code, document all changes carefully and include date
% authorship, and a brief description of modifications
%
% Initial coding MMP, SS  - 7_26_2019
%



if isa(P1,'polynomial') % this is to add multiplier term to L2xL2,
% adding polynomial/matrix to operator is ambiguous in general and should
% be avoided
    warning('You are adding a polynomial to PI operator. Double-check if that is intended');
    Pplus = P2;
    Pplus.R.R0 = P1+Pplus.R.R0;
elseif isa(P2,'polynomial')
    warning('You are adding a polynomial to PI operator. Double-check if that is intended');
    Pplus = P1;
    Pplus.R.R0 = P2+Pplus.R.R0;
elseif isa(P1, 'double') %this is to add matrix term to RxR 
    warning('You are adding a matrix to PI operator. Make sure that is your intention');
    Pplus = P2;
    Pplus.P = P1+Pplus.P;
elseif isa(P2, 'double') 
    warning('You are adding a matrix to PI operator. Make sure that is your intention');
    Pplus = P1;
    Pplus.P = Pplus.P+P2;
else %both are PI operators
    if all(P1.dim~=P2.dim)
        warning('Operators dimensions do not match. Check the validity of the addition operation.');
    end
    
    %Create a holder variable for the resultant operator
    Pplus = P1;
    
    
    fset = {'P', 'Q1', 'Q2'};
    
    
    %note: Should try to handle addition of non-matching dimensions
    %better-sachin
    for i=fset
        if ~isempty(P1.(i{:})) && ~isempty(P2.(i{:}))
            Pplus.(i{:}) = P1.(i{:}) + P2.(i{:});
        elseif isempty(P1.(i{:}))
            Pplus.(i{:}) = P2.(i{:});
        elseif isempty(P2.(i{:}))
            Pplus.(i{:}) = P1.(i{:});
        else
            Pplus.(i{:}) = [];
        end
    end
    
    fset = {'R0','R1','R2'};
    for i=fset
        if ~isempty(P1.R.(i{:})) && ~isempty(P2.R.(i{:}))
            Pplus.R.(i{:}) = P1.R.(i{:}) + P2.R.(i{:});
        elseif isempty(P1.R.(i{:}))
            Pplus.R.(i{:}) = P2.R.(i{:});
        elseif isempty(P2.R.(i{:}))
            Pplus.R.(i{:}) = P1.R.(i{:});
        else
            Pplus.R.(i{:}) = [];
        end
    end
end
end