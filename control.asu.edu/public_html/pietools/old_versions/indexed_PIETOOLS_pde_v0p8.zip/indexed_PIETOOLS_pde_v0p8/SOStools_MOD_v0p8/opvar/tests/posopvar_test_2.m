%%
% This is to test if the sos_posopvar has an LU or UL decomposition for all
% positive definite operators such that decomposition is a PI operator
clc; clear;
pvar s theta;
opvar A;
a = 0; b = 1;
A.P = zeros(0); A.Q1 = zeros(0,1); A.Q2 = zeros(1,0);
A.R.R0 = polynomial(0); A.R.R1 = polynomial(s); A.R.R2 = polynomial(theta);
A.var1 = s;
A.var2 = theta;
A.I = [a,b];

X = A.I;

% d = {[1],[2,3]};
prog = sosprogram([s;theta]);

% [prog, Pe1] = sos_posopvar_2(prog, A.dim(:,2),X,s,theta, [n_order, n_order, n_order,10,1,1,10]);


B = A'*A;

d = degbalance(B); 
% deg{1}
% deg{2} = fliplr(deg{2});
% deg{3}= fliplr(deg{3});
deg = {[0],[5,8]}; %setting d{2}(1) =0 seems to be an issue
opts1.exclude = [0 1 1 0]; opts1.psatz = 0;
[prog, Pe1] = sos_posopvar_S2(prog, A.dim(:,2),X,s,theta, deg,opts1);
% deg{2} = fliplr(deg{2});
% deg{3}= fliplr(deg{3});
opts1.exclude = [0 1 0 1]; opts1.psatz = 0;
[prog, Pf1] = sos_posopvar_S2(prog, A.dim(:,2),X,s,theta, deg,opts1);


prog = sosopeq(prog, B-Pe1-Pf1);

prog = sossolve(prog);

Pb = sosgetsol_opvar(prog,Pe1);
% Pc = sosgetsol_opvar(prog,Pf1);
%%
Ai = getmonomials(Pe1, {'s','theta'});
Bi = getmonomials(B,{'s','theta'});

disp('P.R0');
Ai.R.R0
disp('B.R0');
Bi.R.R0
disp('P.R1');
Ai.R.R1
disp('B.R1');
Bi.R.R1
disp('P.R2');
Ai.R.R2
disp('B.R2');
Bi.R.R2