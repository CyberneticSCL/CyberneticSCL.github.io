function [Z] = monomialbalance(P)
% This function provides the minimal set of monomials, Z, required to balance PI operator
% P, i.e. P +/- Z'TZ =0.

% INPUTS:
% P : An opvar variable
% OUTPUTS:
% Z : Vector of monomials defined in the description
% 
%
%
% For support, contact M. Peet, Arizona State University at mpeet@asu.edu
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% PIETools - sos_opvar
%
% Copyright (C)2019  M. Peet, S. Shivakumar
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 2 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% If you modify this code, document all changes carefully and include date
% authorship, and a brief description of modifications
%
% Initial coding MMP, SS  - 8_27_2019
%


if ~isa(P,'opvar')
    error('Input must be an opvar variable.');
end

T = getdeg(P); % first find the highest order present in components of T
% insert error handling to check if components are polynomials in correct
% variables - sachin

s = P.var1; theta = P.var2;

R0degmat = 0:T(4,3);
monolist{'R0'} = polynomial(speye(length(R0degmat)),R0degmat,var1,[length(R0degmat),1]);


fset = {'R1','R2'};
for i=fset
if isa(P.R.(i{:}),'polynomial')
    idx1= find(strcmp(P.R.(i{:}).varname,P.var1.varname));
    idx2= find(strcmp(P.R.(i{:}).varname,P.var2.varname));
    deg = P.R.(i{:}).degmat(:,[idx1,idx2]);
    deg = unique(deg);
end
end

end
end