function [prog,Pop] = sos_posopvar(prog,n,I,var1,var2,d,options)
% sos_posopvar(prog,n,I,var1,var2,d,options) declares 
% the positive 4-PI operator. 
% P = T11
% Q(s) = T12 Z(s) + int( T13 Z(th,s) dth, s, L) + int( T14 Z(th,s) dth, 0, s)
% R1(s,th) = Z(s) T23 Z(s,th) + Z(th,s) T42 Z(th) + 
%            int(Z(b,s) T33 Z(b,th) db,s,L)+int(Z(b,s) T43 Z(b,th) db,th,s)
%           +int(Z(b,s) T44 Z(b,th) db,0,th)
% R2(s,th) = R1(th,s)'
% S(s) = Z(s) T22 Z(s)
% T = [ T_{11}  T_{12} T_{13} T_{14}]
%     [ T_{21}  T_{22} T_{23} T_{24}] >0
%     [ T_{31}  T_{32} T_{33} T_{34}]
%     [ T_{41}  T_{42} T_{43} T_{44}]
% 
% where Z(x)= Z_d1(x) \otimes I_n and Z_d(x) is the vector of monomials in
% variables x of degree d1 or less. Z(x,y) = Z_{d1}(x) \otimes Z_{d2}(y)
% \otimes I_n. If the application is stability of time-delay systems, d1
% will eventually be more or less the degree of the multiplier and d2 more
% or less the degree of the kernel function.
% 
%
% INPUTS 
%   prog: SOS program to modify.
%   n(1): dimension of real part
%   n(2): dimension of L2 part
%   d(1): degree of s in Z(s)
%   d(2): degree of th in Z(s,th), defaults to d(1) if length of d=2
%   d(3): degree of s in Z(s,th), defaults to d(2) if length of d=2
%   d(4): degree of s+th in Z(s,th), defaults to d(2)+d(3) if unspecified
%   var1: Single pvar corresponding to s in the description
%   var2: Single pvar corresponding to t in the description
%   I = [l u] interval of integration
%   options.psatz=1 if this is a psatz term. options.psatz=0 otherwise
%   options.full=1 if we do not use an LU decomposition (this will increase
%   the number of variables) options.full=0 otherwise T_i4=0
%   options.pure=1 if we require S(s)=0, options.pure=0 otherwise (Ti2=0)
% OUTPUT 
%   Pv: operator structure
% NOTES:
% For support, contact M. Peet, Arizona State University at mpeet@asu.edu
%
% We need to switch the degrees in the second set of monomials so that Zs->d1, Zsth->d2,d1 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% PIETools - sos_posopvar
%
% Copyright (C)2019  M. Peet, S. Shivakumar
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 2 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% If you modify this code, document all changes carefully and include date
% authorship, and a brief description of modifications
%
% Initial coding MMP, SS  - 7_26_2019
%

switch nargin
    case 5
        error(['Not enough inputs!'])
    case 6
        options.psatz=0;
        options.full=1;
        options.pure=0;
        options.diag=0;
    case 7
        if ~isfield(options,'psatz')
            options.psatz=0;
        end
        if ~isfield(options,'full')
            options.full=1;
        end
        if ~isfield(options,'pure')
            options.pure=0;
        end
        if ~isfield(options,'diag')
            options.diag=0;
        end
end
if length(n)~=2
    error('n must be a length 2 vector')
end
if length(d)<2 || length(d)>4
    error('d must be a vector of length 2, 3 or 4')
end
if length(I)~=2
    error('I must be a length 2 vector')
end
if I(1)>=I(2)
    error('I(1) must be less than I(2)')
end

n1=n(1);n2=n(2);
if length(d)==2
    d1=d(1);d2=d(1); d3 = d(2); d4 = d2+d3;
elseif length(d) ==3
    d1=d(1);d2=d(2); d3 = d(3); d4 = d2+d3;
elseif length(d) ==4
    d1=d(1);d2=d(2); d3 = d(3); d4 = d(4);
end
%dum=polynomial(1,1,{'ss'},[1 1]);

if ~isvalid(var1) || ~isvalid(var2)
    error(['vars must be a polynomial variable']);
end
if n1==0
    if n2==0
        error(['Error in posopvar: All dimensions are zero'])
    end
end


% Sorting
% ExcludeL is a length-4 binary vector of terms to exclude
excludeL=[0 0 0 0];
if n1==0
excludeL(1)=1;
end
if n2==0
    excludeL([2:4])=[1 1 1];
end
if options.full==0
    excludeL(4)=1;
end
if options.pure==1
    excludeL(2)=1;
end


sss=polynomial(1,1,{'sss'},[1 1]);


% this defines the multiplier to be used later
if options.psatz==1
    gs=(var1-I(1))*(I(2)-var1);
    gth=(var2-I(1))*(I(2)-var2);
    geta=(sss-I(1))*(I(2)-sss);
else
    gs=polynomial(1);
    gth=polynomial(1);
    geta=polynomial(1);
end


% Constructing Z1(s)
nZ1=d1+1;
Z1degmat = [0:d1]';
Z1coeff = speye(nZ1);
Z1varname = var1.varname;
Z1matdim = [nZ1 1];
Z1s=polynomial(Z1coeff,Z1degmat,Z1varname,Z1matdim);

% Constructing Z2(s,th)
% In this implementation, Z2 will have degree d2 in th and degree d3 in s
% if length of d=2, Z2 will have degree d1 in th and degree d2 in s

Z2degmat = [repmat([0:d3]',d2+1,1),vec(repmat(0:d2,d3+1,1))];
Z2degmat(sum(Z2degmat,2)>d4/2,:)= [];
nZ2=length(Z2degmat);
Z2coeff = speye(nZ2);
Z2varname = [var1.varname; var2.varname];
Z2matdim = [nZ2 1];
Z2sth=polynomial(Z2coeff,Z2degmat,Z2varname,Z2matdim);


% % There is another configuration for the degree d2. 
% % In this implementation, Z2 will have degree d1 in s and degree d2 in th
% 
% Z2degmat = [repmat([0:d1]',d2+1,1),vec(repmat(0:d2,d1+1,1))];
% nZthksi=length(Z2degmat);
% Z2coeff = speye(nZthksi);
% Z2varname = [var1.varname; var2.varname];
% Z2matdim = [nZthksi 1];
% Zsth=polynomial(Z2coeff,Z2degmat,Z2varname,Z2matdim);


nBZ1=n2*nZ1;
nBZ2=n2*nZ2;


bZ1s=[];
for i=1:n2
    bZ1s=blkdiag(bZ1s,Z1s);
end

bZ2sth=[];
for i=1:n2
    bZ2sth=blkdiag(bZ2sth,Z2sth);
end

bZ2ths=var_swap(bZ2sth,var1,var2);
bZ1th=subs(bZ1s,var1,var2);
bZ2etath=subs(bZ2sth,var1,sss);
bZ2etas=subs(bZ2ths,var2,sss);

% We now declare the positive matrix variable. 
% first compute the size of the matrix
dimL1=n1;
dimL2=(1-excludeL(2))*nBZ1;
dimL3=(1-excludeL(3))*nBZ2;
dimL4=(1-excludeL(4))*nBZ2;
dimLLL=dimL1+dimL2+dimL3+dimL4;
[prog,LLL]=sosposmatr(prog,dimLLL);


% Lets start by just assuming LLL has been partitioned
% In this case, things are more or less a repeat of the positive matrix
% variable case in sosposmatrvar.m with P replaced by LLL1 and Z with ZZZth
% Note, however that because this rearranges the order of the elements of
% ZZZth, we must alter all the manipulations or the result will be invalid.

ind{1}=1:n1; 
ind{2}=(dimL1+1):(dimL1+dimL2); 
ind{3}=(dimL1+dimL2+1):(dimL1+dimL2+dimL3);
ind{4}=(dimL1+dimL2+dimL3+1):dimLLL;

% includeL=[];
% for i=1:4
%     if excludeL(i)~=1
%         includeL=[includeL i];
%     end
% end
includeL = find(excludeL==0);
    
for i=includeL
    for j=includeL
        if i>=j         
            Q{i,j}=LLL(ind{i},ind{j});
            if i~=j
                Q{j,i}=Q{i,j}.';
            end
        end
    end
end

% This option is really only intended for time-delay systems, wherein we
% know these terms are zero and can be omitted
if options.diag==1 && options.pure~=1 % if the diagonal override is used, make $Q22$ block diagonal
    Q22temp=Q{2,2}; %this is of dimension nBZ1=n2*nZth=K*diag*nZth
    K=n2/diag; % this is the number of blocks
    for i=1:K
        irange=(diag*(i-1)*nZs+1):(i*diag*nZs);    % n2/
        Q22temp(irange,irange)=zeros(diag*nZs); % parts of Q22 which are not Zero
    end
    for i=1:K
        irange=(diag*(i-1)*nZs+1):(i*diag*nZs);    % n2/
        for j=1:K
            if i~=j
                jrange=(diag*(j-1)*nZs+1):(j*diag*nZs);    % n2/
                Q{2,2}(irange,jrange)=zeros(length(irange),length(jrange))
                % eliminate these terms so fewer variables appear in the polynomial manipulations
            end
        end
    end
    prog=sosmateq(prog,Q22temp); %constrain the off-diagonal terms to be zero
end

% Q11=LLL(ind1,ind1);
% Q12=LLL(ind1,ind2);
% Q13=LLL(ind1,ind3);
% Q14=LLL(ind1,ind4);
% Q22=LLL(ind2,ind2);
% Q23=LLL(ind2,ind3);
% Q24=LLL(ind2,ind4);
% Q33=LLL(ind3,ind3);
% Q34=LLL(ind3,ind4);
% Q44=LLL(ind4,ind4);
% Q21=Q12.';Q31=Q13.';Q41=Q14.';Q32=Q23.';Q42=Q24.'; Q43=Q34.';
%%%%%%%%%%%%%%%%%%%%%%%%%

% if excludeL(1)~=0
%     Pop.P=Q{1,1};
%     Q=int(gth*Q12*bZths,var2,var1,I(2))+int(gth*Q13*bZths,var2,I(1),var1);
% else 
%     Pop.P=[];
% end

P=polynomial(zeros(n1));
QT=polynomial(zeros(n1,n2));
R0=polynomial(zeros(n2));
R1=R0;
R2=R0;


if excludeL(1)==0
    P=P+Q{1,1}*int(gs,var1,I(1),I(2));
    if excludeL(2)==0
        QT=QT+gs*Q{1,2}*bZ1s;
    end
    if excludeL(3)==0
        QT=QT+int(gth*Q{1,3}*bZ2ths,var2,var1,I(2));
    end
    if excludeL(4)==0
        QT=QT+int(gth*Q{1,4}*bZ2ths,var2,I(1),var1);
    end
end
if excludeL(2)==0
    R0 = gs*bZ1s.'*Q{2,2}*bZ1s;
    if excludeL(3)==0
        R1=R1+gs*bZ1s.'*Q{2,3}*bZ2sth;
    end
    if excludeL(4)==0
        R1=R1+gth*bZ2ths.'*Q{4,2}*bZ1th;
    end
end

if excludeL(3)==0
        R1=R1+int(geta*bZ2etas.'*Q{3,3}*bZ2etath,sss,var1,I(2));
    if excludeL(4)==0
        R1=R1+int(geta*bZ2etas.'*Q{4,3}*bZ2etath,sss,var2,var1);
    end
end
if excludeL(4)==0
        R1=R1+int(geta*bZ2etas.'*Q{4,4}*bZ2etath,sss,I(1),var2);
end


R2 = var_swap(R1,var1,var2).';

opvar Pop;
Pop.P = P;
Pop.Q1 = QT;
Pop.Q2 = QT'; Pop.R.R0 = R0; Pop.R.R1 = R1; Pop.R.R2 = R2;

Pop.dim = [n1 n1; n2 n2];
Pop.I = I;
Pop.var1 = var1;
Pop.var2 = var2;


%pvar dumbeta;
% Zs = repmat(Zs,n2,1); Zsth = repmat(Zsth,n2,1);
% Zs1=[]; Zsth1=[];
% for i=1:length(Z1s)
%     Zs1 = [Zs1; Z1s(i)*eye(n2)];
% end
% for i=1:length(Z2sth)
%     Zsth1 = [Zsth1; Z2sth(i)*eye(n2)];
% end
% Z1s = Zs1; Z2sth= Zsth1;
% Zth = subs_p(Z1s,var1,var2);
% Zths = var_swap(Z2sth,var1,var2);
% Zbth = subs_p(Z2sth,var1,dumbeta);
% Zbs = subs_p(Zbth,var2,var1);
% Construct P

end