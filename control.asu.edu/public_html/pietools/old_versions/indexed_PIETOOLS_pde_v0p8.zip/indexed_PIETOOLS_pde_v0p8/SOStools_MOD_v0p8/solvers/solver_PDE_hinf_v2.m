% date: 6/13/2019
% hinf of the equation u_t = A0*u + A1*u_s+ A2*u_ss +B1w;
% u = u(s,t);
% boundary conditions B[u2(0) u2(L) u3(0) u3(L) u3_s(0) u3_s(L)]=0
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This program determines Hinf norm of a linear PDE which is defined
% in the format given below.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% System Definition:
% \dot x(t,s)=A0(s)[x_1(t,s)] + A1(s)[x_2s(t,s)] + A2(s)[x_3ss(t,s)]+B1(s)w(t)
%                  [x_2(t,s)]        [x_3s(t,s)]
%                  [x_3(t,s)]
% y(t) =  C1 [x_2(a) + int_a^b Ca(s) [x_1(t,s)]  ds + int_a^b Cb(s) [x_2s(t,s)] ds + Dw(t)
%             x_2(b)                 [x_2(t,s)]                     [x_3s(t,s)]
%             x_3(a)                 [x_3(t,s)]
%             x_3(b)
%             x_3s(a)
%             x_3s(b)] 

% % Boundary conditions are of the form 
% % B[x_2(a)       
% %   x_2(b)
% %   x_3(a)
% %   x_3(b)
% %   x_3s(a)
% %   x_3s(b)]=0

%
% Inputs:
% A0(s)  -  matrix function of s of dimension n1+n2+n3 x n1+n2+n3 
% A1(s)  -  matrix function of s of dimension n1+n2+n3 x n2+n3
% A2(s)  -  matrix function of s of dimension n1+n2+n3 x n3
% B      -  matrix of dimension n2+2*n3 x n1+n2+n3 (must be full row rank)
% B1(s)  -  matrix valued polynomial of s of dimension n1+n2+n3 x nw
% a,b    -  \R x \R - interval of the domain - s \in [a,b]
% C1     -  matrix of dimension ny x 2n2+4n3
% Ca(s)  -  matrix valued function of s of dimension ny x n1+n2+n3
% Cb(s)  -  matrix valued function of s of dimension ny x n2+n3
% D      -  matrix of dimension ny x nw
% eppos  -  for strict positivity
% epsneg (optional) - epsneg >0 for strictness of the negativity of derivative 
%
% here 
% n1 - dimension of x_1 (can be 0)
% n2 - dimension of x_2 (can be 0)
% n3 - dimension of x_3 (can be 0)
% ny - dimension of y(t)(cant be 0)
% nw - dimension of w(t)(cant be 0)

% To find a bound on Hinf norm, we solve the following optimization problem
% after rewriting the system in fundamental state form which is
% H\dot(xf)(t,s) = (Af xf)(t,s) + B1(s) w(t)
% y(t) = (C xf)(t,s) + D w(t)
% % % minimize gamma
% % %  P > 0
% % % [ -gamma*I    D'          (B* P H)
% % %   D           -gamma*I     C
% % %   (H* P B)        C*      (Af* P H + H* P Af)] <=0 
% where gamma is a bound on the Hinf norm and * represents operator
% adjoint

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% internal variables:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc; clear;
% setup pvars and other internal parameters
pvar s theta;
n_order = 2; 
eppos = 1e-2;
epneg = 1e-3; 

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%USER INPUT START%%
% % Always stable
% % standard heat equation 1D, with fixed boundaries gamma 0.0833
% % output y(t) = int(x(s),a,b) ds
n1=0;n2=0;n3=1; np = n1+n2+n3;
nw =1; ny=1;
a=0;b=1;
A0=0; A1=0; A2=1;
B1 = 1;
C1 =[0 0 0 0]; Ca = 1; Cb =0; D = 0;
on = eye(np); zer = zeros(np);
B = [on zer zer zer;
     zer on zer zer];
 
% % Stable for R<2.7; gamma = 1.6749
% % Coupled reaction equation
% % output y(t) = int(x1(t,s),a,b) ds
% R=2.7-1e-5; n1=0;n2=0;n3=2; np = n1+n2+n3;
% nw = 1; ny =1;
% A0 = [1 1.5;
%       5 0.2]; 
% A1= zeros(n2+n3);
% A2=(1/R)*[1 0; 0 1];
% a=0; b= 1;
% on = eye(np); zer = zeros(np);
% B = [on zer zer zer;
%      zer on zer zer];
% B1 = [1;0];
% C1 =zeros(ny,2*n2+4*n3); Ca = [1 0]; Cb =zeros(ny,n2+n3); D = zeros(ny,nw);

% % Stable for lamb<=pi^2, gamma = 8.2139
% % Heat equation with reaction term
% % output y(t) = int(x(t,s),a,b) ds
% n1=0;n2=0;n3=1;nw = 1; ny =1;np = n1+n2+n3;
% lamb = (1-1e-2)*pi^2; %lamb=2.0;
% A0=lamb; A1=0; A2=1;
% B1 = 1;
% a=0; b= 1;
% C1 =zeros(ny,2*n2+4*n3); Ca = 1; Cb =zeros(ny,n2+n3); D = zeros(ny,nw);
% B = [1 0 0 0;
%      0 1 0 0];

% stable for lambda<=2.467, gamma = 12.0312 for lamb = 2.4
% Heat equation with reaction term and neumann BC
n1=0;n2=0;n3=1;nw = 1; ny =1;np = n1+n2+n3;
lamb = 2.4; 
A0 = lamb; A1 = 0; A2 = 1;
B1 = 1;
a=0; b= 1;
C1 =[0 0 0 0]; Ca = 1; Cb =zeros(ny,n2+n3); D = zeros(ny,nw);
on = eye(np); zer = zeros(np);
B = [on zer zer zer;
     zer zer zer on];

% % Stable for lambda<=4.65, gamma =14.99 for lamb = 4.6
% n1=0;n2=0;n3=1;nw = 1; ny =1;np = n1+n2+n3;
% lamb = 4.6; 
% A0 = -0.5*s^3+1.3*s^2-1.5*s+0.7+lamb;
% A1 = 3*s^2-2*s; A2 = s^3-s^2+2;
% B1 = 1;
% a=0; b= 1;
% C1 =zeros(ny,2*n2+4*n3); Ca = 1; Cb =zeros(ny,n2+n3); D = zeros(ny,nw);
% on = eye(np); zer = zeros(np);
% B = [on zer zer zer;
%      zer zer zer on];

% % stable for R<=21, gamma =  4.23
% % output y(t) = int(x1(t,s),a,b) ds
% n1=0;n2=0;n3=3;nw = 1; ny =3;np = n1+n2+n3;
% R = (21-1e-3); 
% A0 = [0 0 0; s 0 0; s^2 -s^3 0]; A1 = zeros(np); 
% A2= (1/R)*eye(np);
% B1 = [1; 1; 1];
% a=0; b= 1;
% C1 =zeros(ny,2*n2+4*n3); Ca = eye(n3); Cb =zeros(ny,n2+n3); D = zeros(ny,nw);
% on = eye(np); zer = zeros(np);
% B = [on zer zer zer;
%      zer on zer zer];

% % tip damped wave equation, gamma = 2, 
% % output y(t) = int(x1(t,s),a,b) ds
% n1=0;n2=2;n3=0;nw = 1; ny =1;np = n1+n2+n3;
% k =0.5; A1 = [0 1; 1 0]; A0 = zeros(np); A2 = zeros(np,n3);
% B1 = [1; 0];
% a=0; b= 1;
% C1 = zeros(ny,2*n2+4*n3); Ca = [1 0]; Cb =zeros(ny,n2+n3); D = zeros(ny,nw);
% on = eye(n3); zer = zeros(n3);
% B = [0 1 0 0; 0 0 k 1];

% % pure transport equation 1D, gamma = 0.5?
% % output y(t) = int(x(t,s),a,b) ds
% n1=0;n2=1;n3=0;nw =1; ny=1;
% a=0;b=1;
% np=n1+n2+n3; A0 = zeros(np); A1=-ones(np,n2+n3); A2=zeros(np,n3);
% B1 = eye(nw); 
% a=0; b= 1;
% C1 = zeros(ny,2*n2+4*n3); Ca = [1]; Cb =zeros(ny,n2+n3);
% D = zeros(ny,nw);
% on = eye(np); zer = zeros(np);
% B = [on zer];

% % EB beam
% nw=1;ny = 1;
% n1 =0; n2 = 0; n3=2;
% c=10;
% np = n1+n2+n3; A0 = zeros(np); A1 = zeros(np,n2+n3); A2= [0 -c;1 0];
% a=0; b=1;
% B = [1 0 0 0 0 0 0 0; 
%      0 0 0 1 0 0 0 0;
%      0 0 0 0 1 0 0 0;
%      0 0 0 0 0 0 0 1];
% B1 = [1; 0];
% C1 = zeros(ny,2*n2+4*n3); Ca = [0 1]; Cb =[0 0];
% D = 0;

% %%USER INPUT END%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% setup an SOS program
varlist = [s; theta];
prog = sosprogram(varlist);

% domain of spatial variables
X = [a b];

% p-compact form of the interval
g1 = (X(2)-s)*(s-X(1));

% hinf norm variable which needs to be minimized
pvar gamma;
prog = sosdecvar(prog, gamma); %this sets gamma as decision var
prog = sossetobj(prog, gamma); %this minimizes gamma, comment for feasibility test

% setup the variables for lyapunov function candidate
disp('Parameterizing Positive function');
opts.full = 0;
[prog, Pv] = sos_posopvar(prog,[0 np],X,s,theta,[n_order,n_order/2],opts);

% enforce strict positivity on the operator
Pv.R.R0 = Pv.R.R0+eppos*eye(np);  

% setup H,A,B,C,D operators for the system
setup_ops_hinf_pde;


% Pheq = [ -gamma*I  D'       B*PH
%          D         -gamma*I C
%          H*PB      C*       A*Ph+H*PA]

Pheq = [-gamma*eye(nw)   D'              Bf'*Pv*H;
        D                -gamma*eye(ny)  Cf;
        H'*Pv*Bf         Cf'             H'*Pv*Af+Af'*Pv*H]; 


%getting multiplier and kernel for derivative lyapunov function
disp('Parameterizing the negative operators');
%use next two lines for stability test of system \dot{x} = Ax
% [prog, Pe] = sospos_L2L_ker(prog, np, n_order1+2, n_order2+2, s, theta, X);
% [prog, Pf] = sospos_L2L_ker_psatz(prog, np, n_order1+2, n_order2+2, s, theta, X);
%use next two lines to find a bound on L2 gain
opts1.full = 1; opts1.pure = 1; opts1.psatz = 0;
opts2.full = 1; opts2.pure = 1; opts2.psatz = 1;
[prog, Pe] = sos_posopvar(prog,[nw+ny np],X, s, theta, [2, 8],opts1);
[prog, Pf] = sos_posopvar(prog,[nw+ny np],X, s, theta, [2, 8],opts2);
% derivative negativity
% constraints
% Pe.P = Pe.P+epneg*eye(nw+ny);
% Pe.R.R0 = Pe.R.R0+epneg*eye(np);
% Pf.P = Pf.P+epneg*eye(nw+ny);
% Pf.R.R0 = Pf.R.R0+epneg*eye(np);
disp('Setting up the equality constraints');
prog = sosopeq(prog,Pe+Pf+Pheq); %Pe+Pf+Pheq=0

% choosing a different solver if needed
% option.solver = 'mosek'; 

%solving the sos program
prog = sossolve(prog); 

disp(double(sosgetsol(prog,gamma))); % check the Hinf norm, if the solved successfully


% Conclusion:
if norm(prog.solinfo.info.feasratio-1)<=.1 && ~prog.solinfo.info.numerr
    disp('The System of equations was successfully solved.')
elseif norm(prog.solinfo.info.feasratio-1)<=.1 && prog.solinfo.info.numerr
    disp('The System  of equations was successfully solved. However, Double-check the precision.')
elseif prog.solinfo.info.pinf || prog.solinfo.info.dinf || norm(prog.solinfo.info.feasratio+1)<=.1
    disp('The System is  of equations not solved.')
else
    disp('Unable to definitively determine feasibility. Numerical errors dominating or at the limit of stability.')
end