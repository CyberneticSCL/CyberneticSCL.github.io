np = n1+n2+n3;


T = [eye(n2) zeros(n2,n3) zeros(n2,n3);
     eye(n2) zeros(n2,n3) zeros(n2,n3);
     zeros(n3,n2) eye(n3) zeros(n3);
     zeros(n3,n2) eye(n3) (b-a)*eye(n3);
     zeros(n3,n2) zeros(n3) eye(n3);
     zeros(n3,n2) zeros(n3) eye(n3)];
Q = [zeros(n2,n1) zeros(n2) zeros(n2,n3);
     zeros(n2,n1) eye(n2) zeros(n2,n3);
     zeros(n3,n1) zeros(n3,n2) zeros(n3);
     zeros(n3,n1) zeros(n3,n2) (b-theta)*eye(n3);
     zeros(n3,n1) zeros(n3,n2) zeros(n3);
     zeros(n3,n1) zeros(n3,n2) eye(n3)];
K = [zeros(n1,n2) zeros(n1,n3) zeros(n1,n3);
     eye(n2) zeros(n2,n3) zeros(n2,n3);
     zeros(n3,n2) eye(n3) (s-a)*eye(n3)];
L0 = [eye(n1) zeros(n1,n2) zeros(n1,n3);
     zeros(n2,n1) zeros(n2) zeros(n2,n3);
     zeros(n3,n1) zeros(n3,n2) zeros(n3)];
L1 = [zeros(n1) zeros(n1,n2) zeros(n1,n3);
     zeros(n2,n1) eye(n2) zeros(n2,n3);
     zeros(n3,n1) zeros(n3,n2) (s-theta)*eye(n3)];
V = [zeros(n2,n2) zeros(n2,n3) zeros(n2,n3);
     zeros(n3,n2) zeros(n3,n3) eye(n3)];
F0 = [zeros(n2,n1) eye(n2) zeros(n2,n3);
      zeros(n3,n1) zeros(n3,n2) zeros(n3)];
F1 = [zeros(n2,n1) zeros(n2) zeros(n2,n3);
      zeros(n3,n1) zeros(n3,n2) eye(n3)];

opvar H H0 H2 H3;
%--------------------------------------------------------------------------
disp('Converting all states to fundamental state');
% H maps [z x1 x2s x3ss] to [z x1 x2 x3] 
H.P = eye(no); H.Q1 = zeros(no,np); H.Q2 = K*inv(B*T)*Bz;
H.R.R0 = L0;
H.R.R1 = L1 -K*inv(B*T)*B*Q; H.R.R2 = -K*inv(B*T)*B*Q;
H.dim = [no no; np np];
H.I = [a b];
H.var1 = s;
H.var2 = theta;

% H0 maps [z x1 x2s x3ss] to [x1 x2 x3] 
H0.Q2 = K*inv(B*T)*Bz;
H0.R.R0 = L0;
H0.R.R1 = L1 -K*inv(B*T)*B*Q; H0.R.R2 = -K*inv(B*T)*B*Q;
H0.dim = [0 no; np np];
H0.I = [a b];
H0.var1 = s;
H0.var2 = theta;

% H2 maps [z x1 x2s x3ss] to [x2s x3s]
H2.Q2 = V*inv(B*T)*Bz;
H2.R.R0 = F0; 
H2.R.R1 = F1 - V*inv(B*T)*B*Q; H2.R.R2 = - V*inv(B*T)*B*Q;
H2.dim = [0 no; n2+n3 np];
H2.I = [a b];
H2.var1 = s;
H2.var2 = theta;

% H3 maps [z x1 x2s x3ss] to [x2(0) x2(L) x3(0) x3(L) x3s(0) x3s(L)]
H3.P = T*inv(B*T)*Bz;
H3.Q1 = -T*inv(B*T)*B*Q+Q;
H3.dim = [2*n2+4*n3 no; 0 np];
H3.I = [a b];
H3.var1 = s;
H3.var2 = theta;


% convert operator E to fundamental state operator Ef
opvar EA EB;
EA.Q1 = Ea; EB.Q1 = Eb;
EA.dim = [no 0;0 np];
EA.I = [a b];
EA.var1 = s;
EA.var2 = theta;
EB.dim = [no 0;0 n2+n3];
EB.I = [a b];
EB.var1 = s;
EB.var2 = theta;

temp12 = E1*H3+EA*H0+EB*H2;
temp22 = A0*H0+A1*H2+[zeros(np,n1) zeros(np,n2) A2];
%Assemble A operator, that is get Af from A, Ai, Ef and E
opvar Af;
% Af = [A     E1*H3+EA*H0+EB*H2;
%       E     A0*H0+A1*H2+[zeros(np,n1) zeros(np,n2) A2]];
Af.P = A+temp12.P;
Af.Q1 = temp12.Q1;
Af.Q2 = E+temp22.Q2; 
Af.R = temp22.R;

Af.dim = [no no; np np];
Af.I = [a b];
Af.var1 = s;
Af.var2 = theta;