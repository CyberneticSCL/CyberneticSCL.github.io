setup_ops_fstate_odepde;

opvar Bf Cf Ef;
Bf.I = [a b]; Bf.dim = [no nw; np 0]; Bf.var1 = s; Bf.var2 = theta;
Cf.I = [a b]; Cf.dim = [ny no; 0 np]; Cf.var1 = s; Cf.var2 = theta;

%Bf
Bf.P = B2;
Bf.Q2 = B1;

%Ef
Ef = temp12;

%Cf
opvar CA CB;
CA.Q1 = Ca; CB.Q1 = Cb;
CA.dim = [ny 0;0 np];
CA.I = [a b];
CA.var1 = s;
CA.var2 = theta;
CB.dim = [ny 0;0 n2+n3];
CB.I = [a b];
CB.var1 = s;
CB.var2 = theta;

Cf = C1*H3+CA*H0+CB*H2;
Cf.P = Cf.P + C;
