% date: 8/29/2019
close all; clear all; path(pathdef); clc;
addpath(genpath('.')) % makes sure any local version  of SOSTOOLS_MOD in the current folder is at the head of the path
stability=0; 
stability_des=0; 
stability_dual=0; 
Hinf_gain=0; 
Hinf_gain_dual=0; 
Hinf_control=0; 
Hinf_estimator=0;
Hinf_control_boundary=0;
control_boundary=0;

sosineq_on=0;

pvar s theta;

% Solver file for coupled ODE-PDE systems
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This program determines stability, hinf-norm and designs hinf-optimal 
% observer of a linear coupled ODE-PDE which is defined in the format given below.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% System Definition:
% \dot [x0(t) ]  =A x0(t)+ E0 [x_2(a) + int(Ea(s) [x_1(t,s)] ds,a,b) + int(Eb(s) [x_2s(t,s)] ds,a,b)  + [B11   ]w(t) + [B12   ]u(t)
%                              x_2(b)             [x_2(t,s)]                     [x_3s(t,s)]            
%                              x_3(a)             [x_3(t,s)]
%                              x_3(b)
%                              x_3s(a)
%                              x_3s(b)]  


% \dot  [x(t,s)] = E(s) x0(t)+ A0(s) [x_1(t,s)] + A1(s) [x_2s(t,s)] + A2(s) [x_3ss(t,s)]+ [B21(s)]w(t)+ [B22(s)]u(t)
%                                    [x_2(t,s)]         [x_3s(t,s)]
%                                    [x_3(t,s)] 
% z(t) = C1 x0(t) + C10[x_2(a) + int(Ca1(s)[x_1(t,s)] ds,a,b) + int(Cb1(s)[x_2s(t,s)] ds,a,b) + [D11]w(t) + [D12]u(t)
%                       x_2(b)             [x_2(t,s)]                     [x_3s(t,s)]            
%                       x_3(a)             [x_3(t,s)]
%                       x_3(b)
%                       x_3s(a)
%                       x_3s(b)] 
%                        
% y(t) = C2 x0(t) + C20[x_2(a) + int(Ca2(s)[x_1(t,s)] ds,a,b) + int(Cb2(s)[x_2s(t,s)] ds,a,b) + [D21]w(t) + [D22]u(t)
%                       x_2(b)             [x_2(t,s)]                     [x_3s(t,s)]            
%                       x_3(a)             [x_3(t,s)]
%                       x_3(b)
%                       x_3s(a)
%                       x_3s(b)] 
%                                 
            
% % Boundary conditions are of the form 
% % B[x_2(a)       
% %   x_2(b)
% %   x_3(a)
% %   x_3(b)
% %   x_3s(a)
% %   x_3s(b)]= Bx0 x0(t)+ Bw w(t)+ Bu u(t)


% User Inputs:
% no     -  number of ODE states  
% n1     -  number of undifferentiated PDE states
% n2     -  number of single differentiated PDE states
% n3     -  number of double differentiated PDE states
% nu     -  number of inputs
% nw     -  number of disturbances
% ny     -  number of observed outputs
% nz     -  number of regulated outputs
% A0(s)  -  matrix function of s of dimension n1+n2+n3 x n1+n2+n3 
% A1(s)  -  matrix function of s of dimension n1+n2+n3 x n2+n3
% A2(s)  -  matrix function of s of dimension n1+n2+n3 x n3
% B      -  matrix of dimension n2+2*n3 x n1+n2+n3 (must be full row rank)
% Bx0     -  matrix of dimension n2+2*n3 x no (must be full row rank)
% Bw     -  matrix of dimension n2+2*n3 x nw (must be full row rank)
% Bu     -  matrix of dimension n2+2*n3 x nu (must be full row rank)
% B11    -  matrix of dimension no x nw 
% B12    -  matrix of dimension no x nu 
% B21(s) -  polynomial of dimension np x nw 
% B22(s) -  polynomial of dimension np x nu
% C1     -  matrix of dimension nz x no
% C10    -  matrix of dimension nz x 2n2+4n3 
% Ca1(s) -  polynomial of dimension nz x np
% Cb1(s) -  polynomial of dimension nz x n2+n3 
% D11    -  matrix of dimension nz x nw
% D12    -  matrix of dimension nz x nu
% C2     -  matrix of dimension ny x no
% C20    -  matrix of dimension ny x 2n2+4n3 
% Ca2(s) -  polynomial of dimension ny x np
% Cb2(s) -  polynomial of dimension ny x n2+n3 
% D21    -  matrix of dimension ny x nw 
% D22    -  matrix of dimension ny x nu 
% a,b    -  \R x \R - interval of the domain - s \in [a,b]
% eppos  -  for strict positivity
% epsneg (optional) - epsneg >0 for strictness of the negativity of derivative 




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% internal variables:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


eppos = 1e-2; %positivity of the ODE state
eppos2 = 1e-4; %positivity of the distributed state
epneg = 1e-3; 

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% NOTE: All cases were tested and found to work using the following optional 
% and degree choices(which are relatively high)
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%settings_PIETOOLS_heavy
settings_PIETOOLS_light
%settings_PIETOOLS_stripped
%settings_PIETOOLS_extreme
%settings_PIETOOLS_testing







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%USER INPUT START%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Stability tests%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% % % % %--------------------------------------------------------------------
% % % % % Hyperbolic Transport, Balance Laws, Conservation Equations
% % % % %--------------------------------------------------------------------
% % Example 14, transport equation
% stability=1;
% % stability_dual=1;
% no = 0; n1=0; n2=1; n3 =0;
% np = n1+n2+n3;
% a=0; b= 1;
% A0 = 0; A1 = -1; 
% on = eye(n2); ze = zeros(n2);
% B = [on ze];
% % % % %--------------------------------------------------------------------
% % Examples from Lamare
% stability=1
% stability_dual=0
% % First case has periodic BCs
% Gm1=[.5];
% Gm2=[.5];
% Gm3=[.5];
% Gm4=[.5];
% Lm=[1 0;0 1];
% Fm=[-10 -9; 10 6];

% % Example 5.1 - verified
% Gm1=[.2];
% Gm2=[-.3];
% Gm3=[.6];
% Gm4=[.1];
% Lm=[-3 0;0 1];
% Fm=[.2 -.3; .6 .1];
% 
% % Example 5.2 - verified
% Gm1=[.1];
% Gm2=[-.8];
% Gm3=[.6];
% Gm4=[-.4];
% Lm=[-1 0;0 1];
% Fm=[-.3 .1; .1 -.3];

% % Example 5.3 - verified
% Gm1=[-.2202];
% Gm2=[1.3955];
% Gm3=[-.0596];
% Gm4=[.2090];
% Lm=[-1 0;0 2];
% Fm=[-.1 .1; .5 -.8];

% % % Example 5.4 - verified
% Gm1=[.5];
% Gm2=[-.4];
% Gm3=[.2];
% Gm4=[.8];
% Lm=[-2 0;0 1];
% Fm=[-.6565 -.3743; -.113 -.6485];
% 
% n1=0;n2=2;n3=0;
% A0 = Fm; 
% A1= -Lm;
% A2=0*Fm;
% a=0; b= 1;
% ny1=size(Gm1,1);ny2=size(Gm3,1);
% on1 = eye(ny1);on2 = eye(ny2); zer12 = zeros(ny1,ny2);
% B = [-Gm1 zer12 on1 -Gm2;
%      -Gm3 on2 zer12' -Gm4];
%
% % % % %--------------------------------------------------------------------
% % Example from Diagne. Actually, I found no comparable results from this
% paper, but the setup is here to test if desired
% stability=1
% stability_dual=0
% % First case has periodic BCs
% K00=[.5];
% K01=[.5];
% K10=[.5];
% K11=[.5];
% Lm=[1 0;0 -1];
% Mm=[-10 -9; 10 6];

% n1=0;n2=2;n3=0;
% A0 = Mm; 
% A1= -Lm;
% A2=0*Fm;
% a=0; b= 1;
% ny1=size(K00,1);ny2=size(K10,1);
% on1 = eye(ny1);on2 = eye(ny2); zer12 = zeros(ny1,ny2);
% B = [ on1 -K01 -K00 zer12;
%     zer12' -K11 -K10  on2;];
% 
% % % % %--------------------------------------------------------------------
% % Example from Sabo 2020
% stability=1
% stability_dual=0
% % First case has periodic BCs
% 
% n1=0;n2=2;n3=0;
% %r1=.85;r2=1.1;sig1=2;sig2=1.5;pb=.7;qb=-.4; %not getting stability for
% %this example
% %r1=.8;r2=1.1;sig1=2.3;sig2=-3.5;pb=.5;qb=-.7; % Stable with stripped settings
% %r1=.5;r2=1.1;sig1=1;qb=1.2; sig2=-.1;pb=0; % Stable with stripped settings
% r1=.5;r2=1.1;sig1=1;qb=1.2; 
% %sig2=1;pb=-.7; 
% %sig2=.663;pb=0; % max sig2=.663 
% sig2=1.048;pb=-.4; % max sig2=1.049 
% %settings_PIETOOLS_testing
% %settings_PIETOOLS_heavy
% 
% A0 = [0 sig1; sig2 0]; 
% A1= [-1/r1 0; 0 1/r2];
% a=0; b= 1;
% B = [1 -qb 0 0;
%      0 0 -pb 1];
% % % % %--------------------------------------------------------------------
% % % % % Diffusion and Heat-Equation Type Systems
% % % % %--------------------------------------------------------------------
%--------------------------------------------------------------------
% % % Test D1 - Scalable Diffusion Equation on [-1,1]
% % % x(0)
% ne=1; lam=0
% A0=lam*eye(ne);
% A1=0*eye(ne);
% A2=1*eye(ne);
% a=-1;b=1;
% % x(a)=0, x(L)=0   - Stable for lam<1.2732
% B=[eye(ne) zeros(ne) zeros(ne) zeros(ne);
%     zeros(ne) eye(ne) zeros(ne) zeros(ne)];
% % % x(a)=0, x_s(a)=0   - Not Stable!
% % B=[eye(ne) zeros(ne) zeros(ne) zeros(ne);
% %     zeros(ne) zeros(ne) eye(ne) zeros(ne)];
% % 
% n1=0;n2=0;n3=ne;
% %--------------------------------------------------------------------
% % Test 1.5 - Scalable Diffusion Equation on [0,1] adapted from Ahmadi 2015
% % x(0)
% ne=1; lam=9.8696   %[9.8696 9.8697]
% A0=lam*eye(ne);
% A1=0*eye(ne);
% A2=1*eye(ne);
% a=0;b=1;
% %x(a)=0, x(L)=0   - Stable for lam<pi^2=9.8696
% B=[eye(ne) zeros(ne) zeros(ne) zeros(ne);
%     zeros(ne) eye(ne) zeros(ne) zeros(ne)];
% n1=0;n2=0;n3=ne;
% %--------------------------------------------------------------------
% % % Test 2 - Scalable Diffusion Equation Problem 1 from Gahlawat_2017
% % % x(0)
% ne=1; lam=2.467
% A0=lam*eye(ne);
% A1=0*eye(ne);
% A2=1*eye(ne);
% a=0;b=1;
% % x(a)=0, x_s(L)=0   - Unstable for \lam>2.467 
% B=[eye(ne) zeros(ne) zeros(ne) zeros(ne);
%     zeros(ne)  zeros(ne) zeros(ne) eye(ne)];
% n1=0;n2=0;n3=ne;
% % --------------------------------------------------------------------
% % Test 3 - Diffusion Equation Problem 2 from Gahlawat_2017
% % x(0)
% ne=1; lam=4.66
% A2=s^3-s^2+2;
% A1=3*s^2-2*s;
% A0=-.5*s^3+1.3*s^2-1.5*s+.7+lam;
% a=0;b=1;
% % x(a)=0, x_s(L)=0   - Unstable for \lam>4.66 
% B=[eye(ne) zeros(ne) zeros(ne) zeros(ne);
%     zeros(ne)  zeros(ne) zeros(ne) eye(ne)];
% n1=0;n2=0;n3=ne;
%--------------------------------------------------------------------
% % % Example 1
% stability=1
% % stability_des=1
% stability_dual=1
% n1=0;n2=0;n3=1; no =1;
% a=0;b=1;
% A0=0; A1=0; A2=1; A = 1; E =0;
% B = [1 0 0 0; 0 1 0 0]; Bx0 = [0;1];
 
% % % % %--------------------------------------------------------------------
% % Example 2, stable for R<2.7
% stability=1
% stability_dual=1
% R=2.7;
% n1=0;n2=0;n3=2;
% A0 = [1 1.5;
%       5 0.2]; 
% A1= zeros(n2+n3);
% A2=(1/R)*[1 0; 0 1];
% a=0; b= 1;
% on = eye(n3); zer = zeros(n3);
% B = [on zer zer zer;
%      zer on zer zer];

%--------------------------------------------------------------------

% % % Test 5.5 - from Ahmadi
% ne=2; R=2.93 % [2.93 2.94]
% a=0;b=1;
% A0=[1 1.5;
%     5 .2 ];
% A1=0*eye(ne);
% A2=inv(R)*eye(ne);
% % x(a)=0, x_s(L)=0   - Stable for R<2.7
% B=[eye(ne) zeros(ne) zeros(ne) zeros(ne);
%     zeros(ne) eye(ne) zeros(ne) zeros(ne) ];

% % % % %--------------------------------------------------------------------
% % % Example 6, stable for R<=21,
% stability=1
% %stability_dual=0
% n1=0;n2=0;n3=3;np = n1+n2+n3;
% R = (21+9); 
% A0 = [0 0 0; s 0 0; s^2 -s^3 0]; A1 = zeros(np); 
% A2= (1/R)*eye(np);
% a=0; b= 1;
% on = eye(np); zer = zeros(np);
% B = [on zer zer zer;
%      zer on zer zer];

% % % % % %--------------------------------------------------------------------
% % % % % % Beam Type Equations
% % % % % %--------------------------------------------------------------------
% %--------------------------------------------------------------------
% % % Test 7 - E-B beam equation
%   epneg=0
%  stability=1
% c=.01%.01;%c=EI/mu
% a=0;b=1;
% A0=[0 0; 0 0];
% A1=[0 0; 0 0];
% A2=[0 -c; 1 0];
% % x1(0)=0 x2(L)=0 x_1s(0)=0 x_2s(L)=0 
% B=[
%     1 0 0 0 0 0 0 0;
%     0 0 0 1 0 0 0 0;
%     0 0 0 0 1 0 0 0;
%     0 0 0 0 0 0 0 1];
% n1=0;n2=0;n3=2;
% % % % % %--------------------------------------------------------------------
% % % % % % % Test 9 - Timoschenko beam equation (hyperbolic) 
% % % % % % The states are u1=wt, u2=wx-phi, u3=phit, u4=phix
% % % % % % The BCs are u1(0)=0, u3(0)=0 u4(L)=0 u2(L)=0 ;
%   epneg=0
%  stability=1
% k=1;
% aa=1;II=1;
% g=1;
% E=1;%5-30kPa
% r=1;
% ne=2;c=.01;%c=EI/mu
% a=0;b=1;
% A0=[0 0 0 0; 
%     0 0 -k*aa*g 0;
%     0 1/r/II 0 0;
%     0 0 0 0];
% A1=[0 1/r/aa 0 0; 
%     k*aa*g 0 0 0;
%     0 0 0 1/r/II;
%     0 0 E*II 0];
% A2=zeros(4,0);
% % x1(0)=0 x2(L)=0 x_1s(0)=0 x_2s(L)=0 
% B=[
%     1 0 0 0 0 0 0 0;
%     0 0 1 0 0 0 0 0;
%     0 0 0 0 0 0 0 1;
%     0 0 0 0 0 1 0 0];
% n1=0;n2=4;n3=0;

% % % % % %--------------------------------------------------------------------
% % % % Timoschenko Beam equation Example (hyperbolic/diffusive) - unstable
% % % % The states are u1=wt, u2=wx, u3=phit,u4=phi
% % % % The BCs are u4(0)=0, u4x(L)=0, u3(0)=0, u1(0)=0, u2(L)-u4(L)=0;
%  epneg=0
% stability=1
% A0=[0 0 0 0;
%     0 0 0 0;
%     0 1 0 -1;
%     0 0 1 0];
% A1=[0 1 0 -1;
%     1 0 0 0;
%     0 0 0 0;
%     0 0 0 0];
% A2=[0;0;1;0];
% a=0; b=1;
% % B has dimension 5 x 10
% %  x1 x2 x3 x4 
% B=[1 0 0 0 0 0 0 0 0 0;
%    0 0 1 0 0 0 0 0 0 0;
%    0 0 0 0 0 0 1 0 0 0;
%    0 0 0 0 0 0 0 0 0 1;
%    0 0 0 0 1 0 0 -1 0 0];
% n1=0;n2=3;n3=1;
% 
% % % % % %--------------------------------------------------------------------
% % % % % Timoschenko Beam equation Example (hyperbolic/diffusive with damping)
% % % - stable (using old code) but not exponentially
% % % % % The states are u1=wt, u2=wx, u3=phit,u4=phi
% % % % % The BCs are u4(0)=0, u4x(L)=0, u3(0)=0, u1(0)=0, u2(L)-u4(L)=0;
% settings_PIETOOLS_testing
k=.8
eppos2 = 1e-2;
epneg=0
stability=1
A0=[0 0 0 0;
    0 0 0 0;
    0 1 -.1 -1;
    0 0 1 0];
A1=[0 1 0 -1;
    1 0 0 0;
    0 0 0 0;
    0 0 0 0];
A2=[0;0;1;0];
a=0; b=1;
% B has dimension 5 x 10
%  x1 x2 x3 x4 
B=[1 0 0 0 0 0 0 0 0 0;
   0 0 1 0 0 0 0 0 0 0;
   0 0 0 0 0 0 1 0 0 0;
   0 0 0 0 0 0 0 0 0 1;
   0 0 0 0 1 0 0 -1 0 0];
n1=0;n2=3;n3=1;


% % % % %--------------------------------------------------------------------
% % % % % Wave Equations
% % % % %--------------------------------------------------------------------
% % %--------------------------------------------------------------------
% % % % % Test 7.5 - Boundary-Damped Wave equation - nv
% % % % ne=2;a=2;mu=.01; u_t(L)=-k u_s(L)
%  stability=1
%  a=0;b=1; k=.9;
%  A0=[0 0; 1 0];
%  A1=[0 0; 0 0];
%  A2=[1; 0];
% % % x(0)=0 x(a)=K*x(L) x_s(a)=Kx_s(L)   
%  B=[0 0 1 0 0 0;
%      1 0 0 0 0 0;
%      0 1 0 0 0 k];
% n1=0;n2=1;n3=1;
% % %--------------------------------------------------------------------
% % % % % % Test 7.5b - Boundary-Damped Wave equation (Hyperbolic) - v
% % % % % ne=2;a=2;mu=.01; u_t(L)=-k u_s(L)
% stability=1
% epneg=.01;           % strictness of derivative negativity
%  a=0;b=1; k=1;
%  A0=[0 0; 0 0];
%  A1=[0 1; 1 0];
%  A2=zeros(2,0);
% % % x(0)=0 x(a)=K*x(L) x_s(a)=Kx_s(L)   
%  B=[0 1 0 0;
%     0 0 k 1];
% n1=0;n2=2;n3=0;

% % %--------------------------------------------------------------------
% % % % % Test 7.5c - Datko Boundary-Damped Wave equation - v
% % % % % ne=2;a=2;mu=.01; u_x(L)=-k u_t(L)
% % epneg=.01;           % strictness of derivative negativity
% stability=1
%  a=0;b=1; k=1;ad=1;
%  A0=[-2*ad -ad^2; 1 0];
%  A1=[0 0; 0 0];
%  A2=[1; 0];
% % % x(0)=0 x(a)=K*x(L) x_s(a)=Kx_s(L)  
%  B=[0 0 1 0 0 0;
%      1 0 0 0 0 0;
%      0 k 0 0 0 1];
% n1=0;n2=3;n3=0;
% % %  
% % 
% % % %--------------------------------------------------------------------
% % % % % % Test 7.5d - Datko Boundary-Damped Wave equation (Hyperbolic) -v
% % % % % % ne=2;a=2;mu=.01; u_x(L)=-k u_t(L)
% stability=1
%  a=0;b=1; k=1;ad=1;
%  A0=[-2*ad -ad^2 0; 1 0 0;0 0 0];
%  A1=[0 0 1; 0 0 0;1 0 0];
%  A2=zeros(3,0);
% % % x(0)=0 x(a)=K*x(L) x_s(a)=Kx_s(L)  - Stable for K<1? 
%  B=[1 0 0 0 0 0;
%      0 1 0 0 0 0;
%      0 0 0 k 0 1];
% n1=0;n2=3;n3=0;
% % %  
% % % % %--------------------------------------------------------------------
% % Example 7, tip damped wave equation,
% stability=1
% % stability_dual=1
% n1=0;n2=2;n3=0;np = n1+n2+n3;
% k =0.5; A1 = [0 1; 1 0]; A0 = zeros(np); A2 = zeros(np,n3);
% a=0; b= 1; 
% on = eye(n3); zer = zeros(n3);
% B = [1 0 0 0; 0 0 k 1];
% 
% % Example 8, EB beam
% stability=1
% stability_dual=1
% n1 =0; n2 = 0; n3=2;
% c=3;
% np = n1+n2+n3; A0 = zeros(np); A1 = zeros(np,n2+n3); A2= [0 -c;1 0];
% a=0; b=1;
% B = [1 0 0 0 0 0 0 0; 
%      0 0 0 1 0 0 0 0;
%      0 0 0 0 1 0 0 0;
%      0 0 0 0 0 0 0 1];

% % % % %--------------------------------------------------------------------
% % Example 11, Drill-string linear dynamics, not working
% stability = 1
% % stability_dual = 1
% a=0; b= 1;
% G = 79.3e5; J = 1.19e-5; I = 0.095; Ib = 1; beta= 0; cb = 3000;
% no = 2; n1=0; n2=0; n3 =2;
% np = n1+n2+n3;
% A = [0 1; 0 -cb/Ib]; E0 = [0 0 0 0 0 0 0 0; 0 0 0 0 0 0 -G*J/Ib 0];
% A0 = [0 1; 0 -beta/I];  A1 = zeros(2,2); A2 = [0 0; G*J/I 0];
% B = [ eye(2) zeros(2) zeros(2) zeros(2); zeros(2) eye(2) zeros(2) zeros(2)]; 
% Bx0 = [0 0; 0 0; 1 0; 0 1];

% % % % %--------------------------------------------------------------------
% % Example 12
% stability = 1
% % stability_dual = 1
% a=0; b= 1;
% G = 79.3e5; J = 1.19e-5; I = 0.095; Ib = 1; beta= 0; cb = 3000;
% no = 2; n1=0; n2=2; n3 =0;
% np = n1+n2+n3;
% A = [0 1; 0 -cb/Ib]; E0 = [ 0 0 0 0;0 0 0 -G*J/Ib];
% A0 = [0 0; 0 -beta/I]; A1 = [0 1; G*J/I 0];
% B = [eye(2) zeros(2)]; 
% Bx0 = [0 0; 0 0];

% % % % %--------------------------------------------------------------------
% % Example 13, damped wave equation
% stability=1;
% % stability_dual=1;
% no = 0; n1=0; n2=0; n3 =2;
% np = n1+n2+n3;
% a=0; b= 1;
% A0 = [-1 0; 1 0]; A2 = [0 1;0 0]; 
% on = eye(n3); ze = zeros(n3);
% B = [on ze ze ze; ze on ze ze];

% % % % %--------------------------------------------------------------------
% % % % % Time-Delay Systems
% % % % %--------------------------------------------------------------------
% % Example 9, x_t = -x(t-tau) %stable if tau<=pi/2
% stability=1
% stability_dual=1
% no = 1; n1=0; n2 =1; n3 =0; np = n1+n2+n3;
% A = 0; E = 0;
% tau = pi/2 - 1e-2; 
% A0 = 0; A1 = 1/tau; A2 = zeros(n3);
% E0 = -[1 0]; Ea = 0; Eb = 0;
% B=[0 1];
% Bx0 = [1];
% a = -1; b =0;

% % % % %--------------------------------------------------------------------
% % Example 10, x_t = -x(t)-x(t-tau)
% stability=1
% stability_dual=1
% no = 1; n1=0; n2 =1; n3 =0;
% np = n1+n2+n3;
% tau = 10;
% A=-1; A0 = zeros(np); A1 = 1/tau; A2 = zeros(np,n3);
% E = 0; E0 = -[1 0]; Ea = zeros(no,np); Eb = zeros(no,n2+n3);
% B=[0 1];
% Bx0 = eye(no);
% a = -1; b =0;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Hinf gain %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% % % % %--------------------------------------------------------------------
% % % % % Hyperbolic/Transport/Balance Type Systems
% % % % %--------------------------------------------------------------------
% % Example 8, pure transport equation 1D, gamma = 0.5
% % output y(t) = int(x(t,s),a,b) ds
% Hinf_gain=1
% Hinf_gain_dual=1
% n1=0;n2=1;n3=0;nw =1; nz=1;
% a=0;b=1;
% np=n1+n2+n3; A0 = zeros(np); A1=-ones(np,n2+n3); A2=zeros(np,n3);
% B21 = eye(nw); 
% a=0; b= 1;
% C10 = zeros(nz,2*n2+4*n3); Ca1 = [1]; Cb1 =zeros(nz,n2+n3);
% D11 = zeros(nz,nw);
% on = eye(np); zer = zeros(np);
% B = [on zer];


% % % % %--------------------------------------------------------------------
% % % % % Diffusive/Heat Equation Type Systems
% % % % %--------------------------------------------------------------------
% % % % %--------------------------------------------------------------------
% % Example 1, 0.0833  
% % output y(t) = int(x(s),a,b) ds

% Hinf_gain=1
% Hinf_gain_dual=1
% n1=0;n2=0;n3=1;
% nw =1; nz=1;
% a=0;b=1;
% 
% A0=0; A1=0; A2=1; B21= 1;
% C10 =[0 0 0 0]; Ca1 = 1; Cb1 =0; D11 = 0;  % maybe u_s(L) or u_s(0) are not bounded by u_s is L2? - sachin
% on = eye(n3); zer = zeros(n3);
% B = [on zer zer zer;
%      zer on zer zer];
 
% % % % %--------------------------------------------------------------------
% 
% % % Example 2, Stable for R<2.7; gamma = 1.6749
% % % output y(t) = int(x1(t,s),a,b) ds
% Hinf_gain=1
% Hinf_gain_dual=1
% R=2.7-1e-5; n1=0;n2=0;n3=2; np = n1+n2+n3;
% nw = 1; nz =1;
% A0 = [1 1.5;
%       5 0.2]; 
% A1= zeros(n2+n3);
% A2=(1/R)*[1 0; 0 1];
% a=0; b= 1;
% on = eye(np); zer = zeros(np);
% B = [on zer zer zer;
%      zer on zer zer];
% B21 = [1;0];
% C10 =zeros(nz,2*n2+4*n3); Ca1 = [1 0]; Cb1 =zeros(nz,n2+n3); D11 = zeros(nz,nw);

% % % % %--------------------------------------------------------------------
% % Example 3, Stable for lamb<=pi^2, gamma = 8.2139
% % output y(t) = int(x(t,s),a,b) ds
% Hinf_gain=1
% Hinf_gain_dual=1
% n1=0;n2=0;n3=1;nw = 1; nz =1;np = n1+n2+n3;
% lamb = (1-1e-2)*pi^2; %lamb=2.0;
% A0=lamb; A1=0; A2=1;
% B21 = 1;
% a=0; b= 1;
% C10 =zeros(nz,2*n2+4*n3); Ca1 = 1; Cb =zeros(nz,n2+n3); D11 = zeros(nz,nw);
% B = [1 0 0 0;
%      0 1 0 0];

% % % % %--------------------------------------------------------------------
% % Example 4, stable for lambda<=2.467, 
% % output y(t) = int(x(t,s),a,b) ds, gamma = 12.0312 for lamb = 2.4
% % output y(t) = x(L,t), gamma = 18.8723 for lamb = 2.4
% Hinf_gain=1
% % Hinf_gain_dual=1
% n1=0;n2=0;n3=1;nw = 1; nz =1;np = n1+n2+n3;
% lamb = 2.4; 
% A0 = lamb; A1 = 0; A2 = 1;
% B21 = 1;
% a=0; b= 1;
% C10 =[0 1 0 0]; Ca1 = 0; Cb1 =zeros(nz,n2+n3); D11 = zeros(nz,nw);
% on = eye(np); zer = zeros(np);
% B = [on zer zer zer;
%      zer zer zer on];

% % % % %--------------------------------------------------------------------
% % Example 5, Stable for lambda<=4.65, gamma =14.99 for lamb = 4.6
% % output y(t) = int(x(t,s),a,b) ds
% Hinf_gain=1
% Hinf_gain_dual=1
% n1=0;n2=0;n3=1;nw = 1; nz =1; np = n1+n2+n3;
% lamb = 4.6; 
% A0 = -0.5*s^3+1.3*s^2-1.5*s+0.7+lamb;
% A1 = 3*s^2-2*s; A2 = s^3-s^2+2;
% B21 = 1;
% a=0; b= 1;
% C10 =zeros(nz,2*n2+4*n3); Ca1 = 1; Cb1 =zeros(nz,n2+n3); D11 = zeros(nz,nw);
% on = eye(np); zer = zeros(np);
% B = [on zer zer zer;
%      zer zer zer on];

% % % % %--------------------------------------------------------------------
% % Example 6, stable for R<=21, gamma =  4.23
% % output y(t) = int(x1(t,s),a,b) ds
% Hinf_gain=1
% Hinf_gain_dual=1
% n1=0;n2=0;n3=3;nw = 1; nz =3;np = n1+n2+n3;
% R = (21-1e-3); 
% A0 = [0 0 0; s 0 0; s^2 -s^3 0]; A1 = zeros(np); 
% A2= (1/R)*eye(np);
% B21 = [1; 1; 1];
% a=0; b= 1;
% C10 =zeros(nz,2*n2+4*n3); Ca1 = eye(n3); Cb1 =zeros(nz,n2+n3); D11 = zeros(nz,nw);
% on = eye(np); zer = zeros(np);
% B = [on zer zer zer;
%      zer on zer zer];


% % % % %--------------------------------------------------------------------
% % % % % Beam-type Systems
% % % % %--------------------------------------------------------------------

% % % % %--------------------------------------------------------------------
% Example 9, euler-bernoulli beam
% output y(t) = 
% opts.pure = 0; override1 =1;
% Hinf_gain=1
% % Hinf_gain_dual=1
% n1 =0; n2 = 0; n3=2; nw =1; nz=1;
% c=1;
% np = n1+n2+n3; A0 = zeros(np); A1 = zeros(np,n2+n3); A2= [0 -c;1 0];
% a=0; b=1;
% B = [1 0 0 0 0 0 0 0; 
%      0 0 0 1 0 0 0 0;
%      0 0 0 0 1 0 0 0;
%      0 0 0 0 0 0 0 1];
% C10 = [0 0 0 0 0 0 0 0]; Ca1 = [0, 0]; Cb1 =zeros(nz,n2+n3);
% D11 = zeros(nz,nw);
% B21 = [1;0]; 

% % % % %--------------------------------------------------------------------
% Example 10, Timoshenko beam
% output y(t) = 
% opts.pure = 0; override1 =1;
% Hinf_gain=1
% Hinf_gain_dual=1
% % stability=1
% n1 =0; n2 = 4; n3=0; nw =1; nz=1;
% np = n1+n2+n3; 
% A0 = [0 0 0 0; 0 0 -1 0; 0 1 0 0; 0 0 0 0]; A1 = [0 1 0 0; 1 0 0 0; 0 0 0 1; 0 0 1 0];
% a=0; b=1;
% B = [1 0 0 0 0 0 0 0; 
%      0 0 1 0 0 0 0 0;
%      0 0 0 0 0 0 0 1;
%      0 0 0 0 0 1 0 0];
% C10 = [0 0 0 0 0 0 0 0]; Ca1 = [0,0,0,0]; Cb1 =zeros(nz,n2+n3);
% D11 = 1;
% B21 = [1;0;0;0]; 

% % % % %--------------------------------------------------------------------
% % % % % Wave-type Systems
% % % % %--------------------------------------------------------------------
% % % % %--------------------------------------------------------------------
% % Example 7, tip damped wave equation, gamma = 2, 
% % output y(t) = int(x1(t,s),a,b) ds
% Hinf_gain=1
% Hinf_gain_dual=1
% n1=0;n2=2;n3=0;nw = 1; nz =1;np = n1+n2+n3;
% k =0.5; A1 = [0 1; 1 0]; A0 = zeros(np); A2 = zeros(np,n3);
% B21 = [1; 0];
% a=0; b= 1;
% C10 = zeros(nz,2*n2+4*n3); Ca1 = [1 0]; Cb1 =zeros(nz,n2+n3); D11 = zeros(nz,nw);
% on = eye(n3); zer = zeros(n3);
% B = [0 1 0 0; 0 0 k 1];

% % % % %--------------------------------------------------------------------
% % Example 11 Drill-string
% Hinf_gain = 1
% a=0; b= 1;
% G = 79.3e5; J = 1.19e-5; I = 0.095; Ib = 1; beta= 0; cb = 3000;
% no = 2; n1=0; n2=0; n3 =2; nw =1; nz=1;
% np = n1+n2+n3;
% A = [0 1; 0 -cb/Ib]; E0 = [0 0 0 0 0 0 0 0; 0 0 0 0 0 0 -G*J/Ib 0];
% A0 = [0 1; 0 -beta/I];  A1 = zeros(2,2); A2 = [0 0; G*J/I 0];
% B = [ eye(2) zeros(2) zeros(2) zeros(2); zeros(2) eye(2) zeros(2) zeros(2)]; 
% Bx0 = [0 0; 0 0; 1 0; 0 1];
% C10 = [0 0 0 0 0 0 0 0]; Ca1 = [0,1]; Cb1 =zeros(nz,n2+n3);
% D11 = 0;
% B21 = [0;0]; B11 = (1/I)*[0;1];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Hinf optimal observer %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% % % % %--------------------------------------------------------------------
% % Example 1
% nw = 1; ny = 1; nz = 1; no = 0;
% n1=0; n2 =1; n3 =0; np = n1+n2+n3; 
% 
% Hinf_estimator=1
% A0 = zeros(np); A1 = 1; A2 = zeros(n3);
% C10 = [1 0]; Ca1 = zeros(nz,np); Cb1 = zeros(nz,n2+n3);
% C20 = [1 0]; Ca2 = zeros(ny,np); Cb2 = zeros(ny,n2+n3);
% B21 = 0; D12 = 0; D22 = 0;
%   
% B=[0 1];
% a = 0; b =1;
% 
% % % % %--------------------------------------------------------------------
% % Example 2
% Hinf_estimator=1
% nw = 1; ny = 1; nz = 2; no = 0;
% n1=0; n2 =0; n3 =2; np = n1+n2+n3; 
% lam = 5;
% A0 = lam*[1 0.3; 0.1 1]; A1 = zeros(np,n2+n3); A2 = eye(n3);
% Ca1 = [0 1]; Cb1 = zeros(ny,n2+n3);
% Ca2 = eye(n3); Cb2 = zeros(nz,n2+n3);
% B21 = [s-s^2;0]; 
% on = eye(n3); zer = zeros(n3);
% 
% B=[on zer zer zer;
%    zer on zer zer];
% a = 0; b =1;
% 

% % % % %--------------------------------------------------------------------
% % Example 3
% Hinf_estimator=1
% nw = 1; ny = 1; nz = 2; no = 0;
% n1=0; n2 =0; n3 =2; np = n1+n2+n3; 
% A0 = [0 1; 0 0]; A1 = zeros(np,n2+n3); A2 = [0 0; 1 0];
% Ca1 = [1 0;0 1]; Cb1 = zeros(nz,n2+n3);
% Ca2 = [0 1]; Cb2 = zeros(ny,n2+n3);
% B21 = [0;1]; %B22 = [0 ; 1];
% on = eye(n3); zer = zeros(n3);
% 
% B=[on zer zer zer;
%    zer on zer zer];
% a = 0; b =1;


% % % % %--------------------------------------------------------------------
% % Example 4
% Hinf_estimator=1; %opts.pure = 0;
% nw = 1; ny = 2; nz = 1; no = 0; %nu = 1;
% n1 =0; n2 = 0; n3=2;
% E=5e3;                   % Young module of elasticity at 25 deg C -unit Pa
% r=0.05/2;                        % fiber radius unit m
% I=pi*r^2;                 %cross section area unit m2
% rho=1.1e3;                %density kg/m3
% 
% c=E*I/rho; %c=50;
% np = n1+n2+n3; A0 = zeros(np); A1 = zeros(np,n2+n3); A2= [0 -c;1 0];
% a=0; b=1;
% B = [1 0 0 0 0 0 0 0; 
%      0 0 0 1 0 0 0 0;
%      0 0 0 0 1 0 0 0
%      0 0 0 0 0 0 0 1];
% Ca1 = [1 0]; Cb1 = zeros(nz,n2+n3); D11 = 1;
% Ca2 = eye(2);
% B21 = [1;0]; 
% B22 = [1 ; 0];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Hinf optimal controller %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% % % % %--------------------------------------------------------------------
% % Example 0
% Hinf_control=1
% % Hinf_estimator=1
% nw = 1; ny = 0; nz = 1; no = 1; nu = 1;
% n1=0; n2 =0; n3 =1; np = n1+n2+n3; 
% A0 = 0; A1 = 0; A2 = 1; A= 1; E = 0; C1 = 1;
% C10= [0 0 0 0]; Ca1 = [1]; Cb1 = zeros(nz,n2+n3); D12 = 1; D11=0;
% B21 = [1]; B22 = [s^2]; B11 =1; B12 = 1;
% on = eye(n3); zer = zeros(n3);
% B = [1 0 0 0; 0 1 0 0]; Bx = [0; 0];
% X = [0 1]; a = 0; b = 1;

% % % % %--------------------------------------------------------------------
% %Example
% Hinf_control=1
% % Hinf_estimator=1
% nw = 0; ny = 0; nz = 0; no = 0; nu = 1;
% n1=0;n2=0;n3=1;np = n1+n2+n3;
% lamb = 2.467+1; 
% A0 = lamb; A1 = 0; A2 = 1;
% a=0; b= 1;
% % C10= [0 0 0 0]; Ca1 = [1]; Cb1 = zeros(nz,n2+n3); D11 = 0;
% B22 = [1]; %B21 = [1];
% on = eye(np); zer = zeros(np);
% B = [on zer zer zer;
%      zer zer zer on];

% % % % %--------------------------------------------------------------------
% Example 1, stabilizing controller, set z=0, w=0
% Hinf_control=1
% lamb = 10;
% nw = 1; ny = 0; nz = 1; no = 0; nu = 1;
% n1=0; n2 =0; n3 =1; np = n1+n2+n3; 
% A0 = lamb; A1 = zeros(np,n2+n3); A2 = 1;
% Ca1 = [0]; Cb1 = zeros(nz,n2+n3); %D12 = 1;
% B21 = 0; B22 = 1;
% on = eye(n3); zer = zeros(n3);
% 
% B=[on zer zer zer;
%    zer on zer zer];
% a = 0; b =1;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Boundary controller %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % Example 1, Stable for lamb<=pi^2, gamma = 8.2139
% % output y(t) = int(x(t,s),a,b) ds
% control_boundary=1
% n1=0;n2=0;n3=1;np = n1+n2+n3; nu = 1;
% lamb = (1+1e-2)*pi^2; %lamb=2.0; lamb=0;
% A0=lamb; A1=0; A2=1;
% a=0; b= 1;
% B = [1 0 0 0;
%      0 1 0 0];
% Bu = [0;1];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Hinf Boundary controller %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % Example 1,
% % output y(t) = int(x(t,s),a,b) ds
% Hinf_control=1; no=1;
% n1=0;n2=0;n3=1;np = n1+n2+n3; nu = 1; nz = 1; nw = 1;
% lamb = (1-1e-2)*pi^2; %lamb=2.0; lamb=0;
% A0=lamb; A1=0; A2=1; E = 0; E0 = [0 0 0 0]; A = 0.5;
% B21 = 1; B12 = 1; B22 = 1; B11 = 1;
% % B12=1;
% a=0; b= 1;
% C10 =zeros(nz,2*n2+4*n3); Ca1 = 1; Cb =zeros(nz,n2+n3); D21 = 1; 
% B = [1 0 0 0;
%      0 1 0 0];
% Bx = [0;0]; 

% Example 2, does not work
% Hinf_control_boundary=1
% n1=0;n2=0;n3=1;np = n1+n2+n3; nu = 1; nz = 1; nw = 1;
% lamb = (1+1e-2)*pi^2; %lamb=2.0; lamb=0;
% A0=lamb; A1=0; A2=1;
% B21 = 0;
% a=0; b= 1;
% C10 =zeros(nz,2*n2+4*n3); Ca1 = 1; Cb =zeros(nz,n2+n3); D21 = 1; 
% B = [0 0 1 0;
%      0 1 0 0];
% Bu = [0;1];

% % % % %--------------------------------------------------------------------
% % Example 3,
% Hinf_control_boundary=1
% n1=0;n2=0;n3=1;np = n1+n2+n3; nu = 1; nz = 1; nw = 1;
% lamb = (1+1e-2)*pi^2; e=2.0; be=8;
% A0=lamb; A1=be; A2=e;
% B21 = 0;
% a=0; b= 1;
% C10 =zeros(nz,2*n2+4*n3); Ca1 = 1; Cb =zeros(nz,n2+n3); D21 = 1; 
% B = [1 0 0 0;
%      0 1 0 0];
% Bu = [0;1];
% %%USER INPUT END%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


setup_PIETOOLS_pde;
nx1=no;nx2=np;


if stability==1
    executive_PIETOOLS_stability;
end
if stability_des==1
    executive_PIETOOLS_stability_descriptor;
end

if stability_dual==1
    executive_PIETOOLS_stability_dual;
end
if Hinf_gain==1
  executive_PIETOOLS_Hinf_gain;
end
if Hinf_gain_dual==1
  executive_PIETOOLS_Hinf_gain_dual;
end
if Hinf_control==1
    executive_PIETOOLS_Hinf_control;
end
if Hinf_control_boundary==1
    executive_PIETOOLS_Hinf_control_boundary;
end
if control_boundary==1
    executive_PIETOOLS_control_boundary;
end
if Hinf_estimator==1
    executive_PIETOOLS_Hinf_estimator;
end


% Conclusion:
if exist(prog, 'var')
if norm(prog.solinfo.info.feasratio-1)<=.1 && ~prog.solinfo.info.numerr
    disp('The System of equations was successfully solved.')
elseif norm(prog.solinfo.info.feasratio-1)<=.1 && prog.solinfo.info.numerr
    disp('The System  of equations was successfully solved. However, Double-check the precision.')
elseif prog.solinfo.info.pinf || prog.solinfo.info.dinf || norm(prog.solinfo.info.feasratio+1)<=.1
    disp('The System is  of equations not solved.')
else
    disp('Unable to definitively determine feasibility. Numerical errors dominating or at the limit of stability.')
end
else
    disp('ODE-PDE converted to PIE. No problem solved because executive file was not selected');
end