
% DelayTOOLs Version 0.6
% Created by M. Peet
% 
% Version History
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Version 0.6 - 5/19/2013
% This update of DelayTOOLS adds simplified functionality for declaring
% separable and semi-separable kernel functions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Components:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% function b = int_p(a,x,x1,x2)
% Description: Adds the ability to integrate pvar variables to SOSTOOLS. 
%              Oddly, this function has been left out of the most recent 
%              versions.  
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% function b = subs(a,old,new)
% Description: This fixes a bug in the pvar implementation of the 
%               subsitute command. The orginal version will fail if the 
%               arguments sent to the function are matrix-valued. 
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% function [prog,P] = sosmatrvar(prog,Z,sizePQ)
% Description: This function adds the ability to declare a matrix-valued 
%                   polynomial variable in SOSTOOLS. The matrix will be of 
%                   size sizePQ(1) x sizePQ(2) with polynomial entries in 
%                   monomials Z. 
% 
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% function [prog,P]=sosposmatr_p(prog,n)
% Description: This function adds the ability to declare a positive (PSD) matrix 
%                   (non-polynomial) in SOSTOOLS. The matrix will be of 
%                   size n x n.
% 
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% function [prog,Q]=sosposmatrvar_p(prog,n,d,vars)
% Description: This function adds the ability to declare a positive matrix-valued 
%                   polynomial variable in SOSTOOLS. The matrix will be of 
%                   size n x n with of maximum polynomial degree d in   
%                   variables vars. Positive is in the sense of being a PSD matrix for all values of variables in vars.
% 
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% function [prog,P] = sossymmatrvar(prog,Z,sizeP);
% Description: This function adds the ability to declare a symmetric matrix-valued 
%                   polynomial variable in SOSTOOLS. The matrix will be of 
%                   size sizeP x sizeP and polynomial in monomials Z. 
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% script solver_ndelay_nd_pvar;
% 
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




