clear all; close all; echo off; 
total=tic;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% DelayTools/Linear v.04 - solver_delay_nd
%
% This program determines stablity of a linear differential equation with 
% delay, where \dot{x}(t)=A0x(t)+A{1}x(t-tau(1))+...+A{K}x(t-tau(K))  
% where A0, A{i}, and tau(i) are user inputs. 
%
% Inputs: A{i} - these can be arbitrary square matrices of arbitrary 
%         dimension. However,  the higher the higher the dimension of A{i},
%         the more time the program will take to run
%         
%         tau(i) - These can be an arbitrary sequence of positive increasing 
%         numbers.
%
%         orderth - This input controls the accuracy of the results. For
%         most problems, orderth=2 should be sufficient to obtain a
%         reasonable degree of accuracy. Note: orderth should be an even
%         integer.
% 
% Requirements: In order to operate, this program requires a working
%               version of SOStools. There are some known compatability 
%               issues with SOStools and Matlab version 7+ due to errors in 
%               the implementation of Maple v8. In addition, it
%               is highly recommended that the user have a compiled version
%               of cdd. Finally the following package of subprograms are
%               required which allows SOStools to handle matrix objects
%               directly:
%               SOStools Matrix Addon package:
%                   sosposmatr.m
%                   sosposmatr.m
%                   sosmatrvar.m
%                   sossymmatrvar.m
%                   sosposmatrvar.m
%  
% version .03   M. Peet, Stanford. mpeet@asu.edu
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DelayTools/Linear v.03 - solver_delay_nd
% Release Notes:
% v.03 - Compatibility with MatrixTOOLS v.03
%
% Coming soon - The big change with release v.04 will be the use of semiseparable
% kernel functions. These functions have properties in common with the
% Gaussian and seem to give an order of magnitude increase in Accuracy in
% most problems, expecially ones which were problematic using separable
% kernels. As yet, we have no joint positivity condition for semiseparable
% kernels. Thus the choice was between either joint positivity or
% semiseparable kernels. Since joint positivity demonstrated little or no
% improvement in performance, the choice was relatively simple.
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs
% B must have row rank equal to twice the dimension of x
% % % 

% % Boundary conditions are of the form 
% % B[x(a)       
% %   x(L)
% %   x_s(a)
% %   x_s(L)]
pvar s th eta zeta

% % Test 1 - Diffusion Equation on [-1,1]
% % x(0)
% ne=1; lam=2.5
% A0=lam*eye(ne);
% A1=0*eye(ne);
% A2=1*eye(ne);
% a=-1;L=1;
% % x(a)=0, x(L)=0   - Stable for lam<1.2732
% B=[eye(ne) zeros(ne) zeros(ne) zeros(ne);
%     zeros(ne) eye(ne) zeros(ne) zeros(ne)];
% % % x(a)=0, x_s(a)=0   - Not Stable!
% % B=[eye(ne) zeros(ne) zeros(ne) zeros(ne);
% %     zeros(ne) zeros(ne) eye(ne) zeros(ne)];
% 
% Test 1.5 - Diffusion Equation on [0,1] adapted from Ahmadi 2015
% x(0)
ne=2; lam=2.0   %[9.8696 9.8697]
A0=lam*eye(ne);
A1=0*eye(ne);
A2=1*eye(ne);
a=0;L=1;
% x(a)=0, x(L)=0   - Stable for lam<pi^2=9.8696
B=[eye(ne) zeros(ne) zeros(ne) zeros(ne);
    zeros(ne) eye(ne) zeros(ne) zeros(ne)];
% % x(a)=0, x_s(a)=0   - Not Stable!
% B=[eye(ne) zeros(ne) zeros(ne) zeros(ne);
%     zeros(ne) zeros(ne) eye(ne) zeros(ne)];


% % Test 2 - Diffusion Equation Problem 1 from Gahlawat_2017
% % x(0)
% ne=1; lam=2.467
% A0=lam*eye(ne);
% A1=0*eye(ne);
% A2=1*eye(ne);
% a=0;L=1;
% % x(a)=0, x_s(L)=0   - Unstable for \lam>2.467 
% B=[eye(ne) zeros(ne) zeros(ne) zeros(ne);
%     zeros(ne)  zeros(ne) zeros(ne) eye(ne)];
% % % x(a)=0, x_s(a)=0   - Not Stable!
% % B=[eye(ne) zeros(ne) zeros(ne) zeros(ne);
% %     zeros(ne) zeros(ne) eye(ne) zeros(ne)];
% 
% % Test 3 - Diffusion Equation Problem 2 from Gahlawat_2017
% % x(0)
% ne=1; lam=4.65
% A2=s^3-s^2+2;
% A1=3*s^2-2*s;
% A0=-.5*s^3+1.3*s^2-1.5*s+.7+lam;
% a=0;L=1;
% % x(a)=0, x_s(L)=0   - Unstable for \lam>4.66 
% B=[eye(ne) zeros(ne) zeros(ne) zeros(ne);
%     zeros(ne)  zeros(ne) zeros(ne) eye(ne)];
% % % x(a)=0, x_s(a)=0   - Not Stable!
% % B=[eye(ne) zeros(ne) zeros(ne) zeros(ne);
% %     zeros(ne) zeros(ne) eye(ne) zeros(ne)];


% % Test 4 - Diffusion Equation
% % x(0)
% ne=2; 
% A0=[0 .1; 0 -2];
% A1=0*eye(ne);
% A2=[1 0;0 0];
% a=0;L=1;
% % x(a)=0, x(L)=0   - Stable
% B=[eye(ne) zeros(ne) zeros(ne) zeros(ne);
%     zeros(ne) eye(ne) zeros(ne) zeros(ne)];
% % % x(a)=0, x_s(a)=0   - Not Stable!
% % B=[eye(ne) zeros(ne) zeros(ne) zeros(ne);
% %     zeros(ne) zeros(ne) eye(ne) zeros(ne)];

% % Test 5 - from Valmorbida
% ne=3; R=21 
% a=0;L=1;
% A0=[0 0 0;
%     s 0 0
%     s^2 -s^3 0];
% A1=0*eye(ne);
% A2=inv(R)*eye(ne);
% % x(a)=0, x_s(L)=0   - Stable for R<21 
% B=[eye(ne) zeros(ne) zeros(ne) zeros(ne);
%     zeros(ne) eye(ne) zeros(ne) zeros(ne) ];

% % Test 5.5 - from Ahmadi
% ne=2; R=2.93 % [2.93 2.94]
% a=0;L=1;
% A0=[1 1.5;
%     5 .2 ];
% A1=0*eye(ne);
% A2=inv(R)*eye(ne);
% % x(a)=0, x_s(L)=0   - Stable for R<2.7
% B=[eye(ne) zeros(ne) zeros(ne) zeros(ne);
%     zeros(ne) eye(ne) zeros(ne) zeros(ne) ];


% % Test 6 - Transport with Amplification at boundary
% ne=1; K=1.5
% a=0;L=1;
% A0=0;
% A1=eye(ne);
% A2=0;
% % x(a)=K*x(L) x_s(a)=Kx_s(L)  - Stable for K<1? 
% B=[eye(ne) -K*eye(ne) zeros(ne) zeros(ne);
%     zeros(ne) zeros(ne) eye(ne) -K*eye(ne) ];
% 
% % Test 7 - Wave equation
% ne=2;a=2;mu=.01;
% a=0;L=1;
% A0=[0 1; 0 -mu];
% %A0=[0 1; 0 -4];
% A1=0*eye(ne);
% A2=[0 0; a 0];
% % x(0)=0 x(a)=K*x(L) x_s(a)=Kx_s(L)  - Stable for K<1? 
% B=[eye(ne) zeros(ne) zeros(ne) zeros(ne);
% %    zeros(ne) eye(ne) zeros(ne)  zeros(ne) ];
%     zeros(ne) zeros(ne) eye(ne)  zeros(ne) ];
% %    zeros(ne) [0 1;0 1] zeros(ne)  mu*[1 0;0 1] ];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Enter degree of accuracy - must be an even integer orders=2 and ordernu=4
% typically yields stability regions accurate to 4 decimal places.
orders = 2;
ordernu=4;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% internal variables:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
epspos=.01;           % strictness of lyapunov positivity
epsneg=.001;           % strictness of derivative negativity
% control inputs to SeDuMi 
pars.alg=1;
pars.stepdif=1;
pars.eps=10^(-15);
pars.maxiter=100;
pars.cg.maxiter=200;
pars.cg.qprec=1;
pars.cg.stagtol=1e-22;
pars.cg.restol=5e-5;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% End user-defined area
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


n_dim=size(A0,2);

%%%%%%%%%%%%%%%%%%%%%%%%
% Construction of Generalized Boundary Conditions Matrices

B2=B*[eye(n_dim)       zeros(n_dim,n_dim);
    eye(n_dim)         (L-a)*eye(n_dim);
    zeros(n_dim,n_dim) eye(n_dim);
    zeros(n_dim,n_dim) eye(n_dim)];
B3=-inv(B2)*B*[zeros(n_dim,n_dim) zeros(n_dim,n_dim);
    eye(n_dim) zeros(n_dim,n_dim);
    zeros(n_dim,n_dim) zeros(n_dim,n_dim);
    zeros(n_dim,n_dim) eye(n_dim)];
Bt1=[zeros(n_dim,n_dim) eye(n_dim)]*B3;
B6=Bt1(:,1:n_dim);
B7=Bt1(:,(n_dim+1):2*n_dim);

Bt2=[eye(n_dim) (s-a)*eye(n_dim)]*B3;
B4=Bt2(:,1:n_dim);
B5=Bt2(:,(n_dim+1):2*n_dim);
B8=B4*(L-th)+B5;
B9=B6*(L-th)+B7;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% internal processing:


mastervartable=[s,th,eta,zeta];
prog = sosprogram(mastervartable);

II=[a L];            % interval [0,L]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% phase 1 - variables %%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% we will need to declare variables:
% M(s),N1(s,th),N_2(s,th)
%
disp('Overhead and Lyapunov Variables, elapsed time:')


tic
disp('creating joint positive operator variable')
[prog, M, N1, N2] = sosjointpos_mat_ker_semisep_vsym(prog,n_dim,orders/2,ordernu/2,s,th,II);

M=M+epspos*eye(n_dim);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% phase 2 - derivatives %%%%%%%%%%%%%%%%%%%%
%%%%%%% Step1 %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% the derivative matrices are spelled out in the paper, they are 
disp('constructing Derivatives, elapsed time:')
tic

% We first construct the terms corresponding to $\ip{x}{APx}$
% These terms are G and D
zzn=polynomial(zeros(n_dim));

tic   %2.65s   int_p is slower here than int...
E1=int((eta-s)*subs(N1,s,eta),eta,s,L)*subs(A2,s,th);
E2=((th-s)*subs(M,s,th)   ...
+ int((eta-s)*subs(N1,s,eta),eta,th,L)...
+ int((eta-s)*subs(N2,s,eta),eta,s,th)...
)*subs(A2,s,th);
T0= (A1+(s-th)*A0);                       % This term is A1(s)+(s-th)*A0(s)
T1 = subs(M*T0,s,eta);                  % This term is M(eta)*(A1(eta)+(eta-th)*A0(eta))
T2= subs(subs_p(N1,s,eta),th,zeta)*subs(T0,s,zeta); % This term is N1(eta,zeta)*(A1(zeta)+(zeta-th)A0(zeta))
T3= subs(subs_p(N2,s,zeta),th,eta)*subs(T0,s,eta); % This term is N2(zeta,eta)*(A1(eta)+(eta-th)A0(eta))
F1G10=T1+int_p(T2,zeta,th,eta);
T4=(eta-s)*F1G10+int((zeta-s)*T3,zeta,s,eta);
%F1G1=int_p((eta-s)*F1G10,eta,s,L)+int_p(int_p((zeta-s)*T3,zeta,s,eta),eta,s,L);
F1G1=int(T4,eta,s,L);
F2G2=int(T4,eta,th,L);
toc

H1=E1+F1G1;H2=E2+F2G2;
D1=H1+var_swap(H2.',s,th);
%D2=var_swap(D1.',s,th); % Not necessary due to symmetry

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Boundary Condition Transformation Terms %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
B8st=B8;
B9t=B9;
Ms=M;
N1st=N1;
N2st=N2;


B8ts=var_swap(B8st,s,th);
B8es=subs(B8ts,th,eta);
B8te=subs(B8ts,s,eta);
B8zs=subs(B8ts,th,zeta);
B8ze=subs(B8zs,s,eta);
B9e=subs(B9t,th,eta);

Mz=subs(Ms,s,zeta);
Me=subs(Ms,s,eta);
N1te=subs(subs(N1st,th,eta),s,th);
N1zt=subs(N1st,s,zeta);
N2te=subs(subs(N2st,th,eta),s,th);
N2zt=subs(N2st,s,zeta);

A0z=subs(A0,s,zeta);
A0t=subs(A0,s,th);
A1t=subs(A1,s,th);
A1z=subs(A1,s,zeta);
A2e=subs(A2,s,eta);

Y1se=B8es.'*Me+int(B8ts.'*N1te,th,eta,L)+int(B8ts.'*N2te,th,a,eta);
Y2z=Mz*A1z+int_p(N1zt*A1t,th,a,zeta)+int_p(N2zt*A1t,th,zeta,L);
Y3ze=Mz*A0z*B8ze+int_p(N1zt*A0t*B8te,th,a,zeta)+int_p(N2zt*A0t*B8te,th,zeta,L);

Y1sz=subs(Y1se,eta,zeta);

Qcse=Y1se*A2e;
Rcse=int(B8zs.'*Y2z,zeta,a,L)*B9e+int_p(Y1sz*A1z,zeta,eta,L)+int((zeta-s)*Y2z,zeta,s,L)*B9e;
Scse=int(B8zs.'*Y3ze,zeta,a,L)+int((zeta-eta)*Y1sz*A0z,zeta,eta,L)+int((zeta-s)*Y3ze,zeta,s,L);

CHst=subs(Qcse+Rcse+Scse,eta,th);
Cst=CHst+var_swap(CHst.',s,th);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Step2 %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Enforce negativity of D1+Cst
disp('enforcing negativity of derivative')



disp('creating joint positive operator variable')

[prog, N1eq, N2eq] = sosjointpos_mat_ker_semisep_vpure(prog,n_dim,(orders+4)/2,(ordernu+4)/2,s,th,II);
[prog, gN1eq, gN2eq] = sosjointpos_mat_ker_semisep_psatz_pure(prog,n_dim,(orders+4)/2,(ordernu+4)/2,s,th,II);

% Should we make this exact?
disp('running equalities, elapsed time:')

    [prog] = sosmateq(prog,D1+Cst+N1eq+gN1eq);
%    [prog] = sosmateq(prog,D1+Cst+N1eq); Use this option to omit secondary
%    Psatz terms. In this case, comment previous 2 lines. Accuracy will
%    decline, however.


disp('TOTAL POLYNOMIAL TIME:')
toc(total)
disp('Computing Solution')


disp('Computing Solution')
%prog = sossolve(prog);
prog = sossolve_p(prog,pars);
%% Conclusion:
if norm(prog.solinfo.info.feasratio-1)<=.1 && ~prog.solinfo.info.numerr
    disp('The Problem is Feasible.')
elseif norm(prog.solinfo.info.feasratio-1)<=.1 && prog.solinfo.info.numerr
    disp('The Problem is likely Feasible. However, Double-check the precision.')
elseif prog.solinfo.info.pinf || prog.solinfo.info.dinf || norm(prog.solinfo.info.feasratio+1)<=.1
    disp('The Problem is Probably not Feasible.')
else
    disp('Unable to definitively determine feasibility. Numerical errors dominating or at the limit of stability.')
end


