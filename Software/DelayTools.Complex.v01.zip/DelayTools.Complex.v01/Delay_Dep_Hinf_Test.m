clear all; echo on
syms f s z h si sr
ivartable=[];
ineq=[];
% Test for Delay-Dependent H_\infty Stability
% 
% NOTE: This script only tests absence of roots on the imaginary axis. To
% verify stability, for normal delay systems, stability at h=0 is needed.
% For neutral systems, additions checks are needed, see the relevant papers
% for details.
%
% In this matlab script, we are given a complex polynomial in complex 
% variables s and z=e^{-\tau s}, and we would like to determine whether the 
% polynomial has any zeros on the imaginary axis, i.e. for Re(s)=0 for any 
% \tau \in [0,hbar]. 
% A value of feas of 1.00 means the set is empty. A certificate can be 
% recovered by using the command sosgetsol.
%
% Inputs:
% The degree of the search. Raise for accuracy, lower for speed(default=6).
% Higher degrees are required for higher degree Pade approximations.
orderxy=10
% The order of the Pade approximation to e^{-\tau s}(min=3)
nq=4
% The bound on the delay
hbar=1.5;
%
% A0=[-2 0; 0 -.9];
% A1=[-1 0;-1 -1];
% g=expand(det(s*eye(2)-A0-A1*z))
%
%g=s^2+2*s^3;
g=s^2+4*s+4+.25*z; % DI stable
%g=s^3+s^2+2*s+1+z; % Not DI stable
%g=s^2+s+1+s*z      % Not DI stable 
%g=2*s+1+s*z+s*z^2        % DI stable - Neutral ex2.7
%g=s+z+z^2        % DI stable - Neutral ex2.7
%g=s^3+2*s^2+2*s+(2*s+1)*z
%g=s+z


delta=[NaN NaN 1.2329 1.0315 1.00363];

% approximate e^-iw by p_q(iw) where 
% p_q(s)=d_q(-s)/d_q(s)
% d_q(s)=sum_j=0^q (2q-1)!q!/(2q)!(q-j)!s^j 
dqd=0;
for k=0:nq
    dqd=dqd+factorial(2*nq-k)*factorial(nq)/factorial(2*nq)/factorial(k)/factorial(nq-k)*(delta(nq)*h*s)^k;
end
dqn=subs(dqd,s,-s);

[c,p]=coeffs(g,z);
n=length(p)-1;
gd=simplify(sum(subs(ones(1,n+1)*z^n./p,z,dqd).*c.*subs(p,z,dqn)))

[reg,img]=cpoly2rpoly(gd,[s], [sr si])
reg=subs(reg,sr,0);
img=subs(img,sr,0);

deg=max(double(maple('degree',img)),double(maple('degree',reg)));
%orderxy=ceil((orderxy+deg)/2)*2;

% according to Stengle, the set
% {x,y: Im(g(w,h))=0, Re(g(w,h))=0, h(hbar-h) \ge 0}=null
% iff
% there exist t \in \R[x,y], s_0 \in SOS : 
% -1= Im(g(w,h))*t_1(w,h) + Im(g(w,h))*t_2(w,h)+ s0(x,y)+h(hbar-h)*s1(w,h)

rvartable = [si h];

[prog]=sosprogram(rvartable);
Z=monomials([si,h],0:orderxy);
Zhalf=monomials(rvartable,0:ceil(orderxy/2));
if (orderxy-deg) >= 0
    Z=monomials(rvartable,0:(orderxy));
    [prog, t1]=sospolyvar(prog,Z);
    [prog, t2]=sospolyvar(prog,Z);
else
    t1=0;t2=0;
end
[prog, s1]=sossosvar(prog,Zhalf);

prog=sosineq(prog,-(.1 + img*t1 + reg*t2 + s1*h*(hbar-h)));
pars.alg=2;
pars.stepdif=1;
pars.eps=10^(-10);
pars.maxiter=100;
pars.cg.maxiter=200;
pars.cg.qprec=1;
pars.cg.stagtol=1e-22;
pars.cg.restol=5e-5;

% The current version of SOSTools, unfortunately does not support a pars
% argument.
%
%prog=sossolve(prog,pars);
prog=sossolve(prog);
