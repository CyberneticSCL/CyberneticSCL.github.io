function [ref,imf]=cpoly2rpoly(f,cvartable, rvartable)

% This function takes as input the complex-valued polynomial f, with
% complex variables cvartable and returns the real-valued functions real(f)
% and im(f) in variables re(cvartable) and im(cvartable).
% 
% Input: 
%   f - polynomial function containing the symbolic variables in
%       cvartable
%   cvartable - vector of declared complex symbolic variables contained in
%       f to be decomposed into real and imaginary parts
%   rvartable - a list of the declared real symbolic variables created and 
%       to be used in ref and imf
%
% Output:
%   ref - a polynomial function in variables rvartable, defined as
%       ref=real(f(cvartable(2j-1)->rvartable(j)+i*rvartable(j+1)))
%   imf - a polynomial function in variables rvartable defined as
%       imf=imaginary(f(cvartable(j)->rvartable(2j-1)+i*rvartable(j+1)))
%
% WARNING - this function will create a new variables with the name 
%       i_symbolic. Make sure this variable has not already been delcared!

syms i_symbolic

rvartable_re=[];
rvartable_im=[];

for j=1:length(cvartable)
    rvartable_re=[rvartable_re rvartable(2*j-1)];
    rvartable_im=[rvartable_im rvartable(2*j)];    
%     eval(['syms x',int2str(j),'_re x',int2str(j),'_im;'])
%     eval(['rvartable_re=[ rvartable_re x',int2str(j),'_re ]; ']) 
%     eval(['rvartable_im=[ rvartable_im x',int2str(j),'_im ]; ']) 
end

%[c,p]=coeffs(collect(simplify(subs(g,[s,z],[x+f*y, x2+f*y2])),f),f);
[c,p]=coeffs(collect(simplify(subs(f,cvartable,rvartable_re+i_symbolic*rvartable_im)),i_symbolic),i_symbolic);
ref=sum(real(subs(p,i_symbolic,i)).*c);
imf=sum(imag(subs(p,i_symbolic,i)).*c);


