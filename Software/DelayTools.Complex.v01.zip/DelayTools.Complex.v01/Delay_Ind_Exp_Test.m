clear all; echo on
syms s z 
% Test for Delay-Independent Exponential Stability
% 
% In this matlab script, we are given a complex polynomial in complex 
% variables s and z, and we would like to determine whether the polynomial 
% has any zeros for Re(s)>-ep and |z|\le 1+ ep. A value of feas of 1.00 means
% the set is empty. A certificate can be recovered by using the command
% sosgetsol.
%
% Inputs:
% The degree of the search. Raise for accuracy, lower for speed(default=4).
% Higher degrees are required for higher degree polynomials
orderxy=4
% The value of epsilon(default=.01)
ep=.01
% The polynomial, g(s,z)
g=2*s+1+s*z        % DI stable - Neutral
%g=s^2+2*s^3;
%g=s^2+4*s+4+.25*z; % DI stable
%g=s^3+s^2+2*s+1+z; % Not DI stable
%g=s^2+s+1+s*z      % Not DI stable 

deg=double(maple('degree',g));

% for j=1:length(cvartable)
%     eval(['syms x',int2str(j),'_re x',int2str(j),'_im;'])
%     eval(['rvartable_re=[ rvartable_re x',int2str(j),'_re ]; ']) 
%     eval(['rvartable_im=[ rvartable_im x',int2str(j),'_im ]; ']) 
%     eval(['global x',int2str(j),'_re x',int2str(j),'_im'])
% end
syms sr si zr zi
rvartable=[sr,si,zr,zi];

[reg , img]=cpoly2rpoly(g,[s,z], [sr,si,zr,zi])

% according to Stengle, the set
% {x,y: Im(g(x,y,x2,y2))=0, Re(g(x,y,x2,y2))=0, x \ge 0, 1-x2^2-y2^2 \ge 0}=null
% iff
% there exist t \in \R[x,y], s_i \in SOS : 
% -1= Im(g(x,y))*t_1(x,y) + Im(g(x,y))*t_2(x,y) + s0(x,y) + x s1(x,y) +
% (1-x2^2-y2^2)*s2 + x*(1-x2^2-y2^2)*s3
%
% constraints
% img=0
eq1=img;
% reg=0
eq2=reg;
% sr \ge -eps
ineq1=sr+ep;
% zr^2+zi^2 \le 1+eps
ineq2=1+ep-zr^2-zi^2;

[prog]=sosprogram(rvartable);
Zhalf=monomials(rvartable,0:ceil(orderxy/2));
if (orderxy-deg) >= 0
    Z=monomials(rvartable,0:(orderxy-deg));
    [prog, t1]=sospolyvar(prog,Z);
    [prog, t2]=sospolyvar(prog,Z);
else
    t1=0;t2=0;
end
%[prog, s0]=sossosvar(prog,Zhalf);
[prog, s1]=sossosvar(prog,monomials(rvartable,0:min(0,ceil((orderxy-1)/2) ) ));

if (orderxy-2) >= 0
    [prog, s2]=sossosvar(prog,monomials(rvartable,0:min(0,ceil((orderxy-2)/2) ) ) );
else
    s2=0;
end
if (orderxy-3) >= 0
    [prog, s3]=sossosvar(prog,monomials(rvartable,0:min(0,ceil((orderxy-3)/2) ) ) );
else
    s3=0;
end
% The SOS variable is declared implicitly using sosineq.
prog=sosineq(prog, -(.1+eq1*t1+eq2*t2+ineq1*s1+ineq2*s2+ineq1*ineq2*s3));

pars.alg=2;
pars.stepdif=1;
pars.eps=10^(-10);
pars.maxiter=100;
pars.cg.maxiter=200;
pars.cg.qprec=1;
pars.cg.stagtol=1e-22;
pars.cg.restol=5e-5;

% The current version of SOSTools, unfortunately does not support a pars
% argument.
%
%prog=sossolve(prog,pars);
prog=sossolve(prog);