clear all; echo on
syms s z
ivartable=[];
ineq=[];
% Test for Delay-Independent H_\infty Stability
% 
% Note: This script only tests absence of roots on the imaginary axis. To
% verify stability, for normal delay systems, stability at h=0 is needed.
% For neutral systems, additions checks are needed, see the relevant papers
% for details.
%
% In this matlab script, we are given a complex polynomial in complex 
% variables s and z, and we would like to determine whether the polynomial 
% has any zeros on the imaginary axis, i.e. for Re(s)=0 and |z| = 1 . 
% A value of feas of 1.00 means the set is empty. A certificate can be 
% recovered by using the command sosgetsol.
%
% Inputs:
% The degree of the search. Raise for accuracy, lower for speed(default=4).
% Higher degrees are required for higher degree polynomials
orderxy=4
% The value of epsilon(default=.01)
ep=.01
% Any independent variables 
syms a
ivartable = [a];
% indicate regions of interest for independent variables
%
amin=-1
amax=1
ineq{1}=-(a-amin)*(a-amax);
%
%
% The polynomial, g(s,z)
%g=s^2+2*s^3;
%g=s^2+4*s+4+.25*z; % DI stable 
%g=s^2+4*s+4+3.5*z; % DI stable
%g=s^3+s^2+2*s+1+z; % Not DI stable
%g=s^2+s+1+s*z;      % Not DI stable
%g=s^2+s+1+a*s*z;      % max DI stable a=+/-.999
%g=s^2+s+1+a*s^2*z  % max DI stable a=+/-.866
%g=2*s+1+s*z+s*z^2        % DI stable
%g=2*s+1+s*z        % DI stable - Neutral ex2.7
g=2*s+1+a*s*z        % DI stable - Neutral ex2.7 max a=+/-2.000
%g=s+z+z^2        
%
% Alternatively, the data can be input in state-space form. Consider 
% systems of the form xdot(t)+ E xdot(t-\tau)=Ax(t)+B x(t-\tau).
% The charachteristic equation is det(sI+E s e^{-\tau s} -A -B e^{t-\tau} )
% E=-a*[.1 .2; .3 .4]; % a \in [-1.86,1.86]
% A=-eye(2);
% B=[.4 .3;.2 .1];
% g=det(s*eye(length(E))+E.*(s*z)-A-B.*z);


deg=double(maple('degree',g));

syms sr si zr zi

[reg , img]=cpoly2rpoly(g,[s,z], [sr,si,zr,zi]);
reg=subs(reg,sr,0);
img=subs(img,sr,0);

rvartable=[si zr zi ivartable];

% constraints
% img=0
eq1=img;
% reg=0
eq2=reg;
% zr^2+zi^2 \le 1+eps
eq3=1-zr^2-zi^2;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% other inequalities can be included
%
amin=-1
amax=1
ineq{1}=-(a-amin)*(a-amax);
%
%

% according to Stengle, the set
% {x,y: Im(g(x,z1,z2))=0, Re(g(x,z1,z2))=0, 1-z1^2-z2^2 = 0}=null
% iff
% there exist t \in \R[x,y], s_0 \in SOS : 
% -1= Im(g(x,z1,z2))*t_1(x,z1,z2) + Im(g(x,z1,z2))*t_2(x,z1,z2)+ (1-z1^2-z2^2)*t_3 + s0(x,y)

[prog]=sosprogram(rvartable);
if (orderxy-deg) >= 0
    Z=monomials(rvartable,0:(orderxy-deg));
    [prog, t1]=sospolyvar(prog,Z);
    [prog, t2]=sospolyvar(prog,Z);
else
    t1=0;t2=0;
end
if (orderxy-2) >= 0
    [prog, t3]=sossosvar(prog,monomials(rvartable,0:(orderxy-2) ) );
else
    t3=0;
end


extras=0;
if ~isempty(ineq)
    for k=1:length(ineq)
        degk=double(maple('degree',ineq{k}));
        if degk <=orderxy
            [prog, spos{k}]=sossosvar(prog,monomials(rvartable,0:(ceil((orderxy-degk)/2))));
            extras=extras+ineq{k}*spos{k};
        end
    end
end
    

prog=sosineq(prog,-(1+eq1*t1+eq2*t2+ eq3*t3+extras));
pars.alg=2;
pars.stepdif=1;
pars.eps=10^(-10);
pars.maxiter=100;
pars.cg.maxiter=200;
pars.cg.qprec=1;
pars.cg.stagtol=1e-22;
pars.cg.restol=5e-5;

% The current version of SOSTools, unfortunately does not support a pars
% argument.
%
%prog=sossolve(prog,pars);
prog=sossolve(prog);
