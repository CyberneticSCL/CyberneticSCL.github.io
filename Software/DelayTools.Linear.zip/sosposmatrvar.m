function [prog,Q]=sosposmatrvar(prog,n,d,vars)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% MatrixTools - sosposmatrvar
%
% This program declares a symbolic positive scalar semidefinite matrix P of size nxn 
% inputs: 
% prog
% n - dimension of matrix
% d - degree of polynomial entries
% vars - variables in the expression
%
% creates a matrix variable of the form
% [Z   ]^T   [Z   ]
% [ Z  ]   Q [ Z  ]
% [  Z ]     [  Z ]
% [   Z]     [   Z], Q>0
%
% version .03   M. Peet, matthew.peet@inria.fr
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% MatrixTools - sosposmatrvar
% Release Notes:
% v.03 - compatability with sosposmatr
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


Z=monomials(vars,0:ceil(d/2));
Zbig=Z;
for i=2:n
    Zbig=blkdiag(Z,Zbig);
end
nZbig=size(Zbig,1);

[prog,P]=sosposmatr(prog,nZbig);
Q=Zbig.'*P*Zbig;

