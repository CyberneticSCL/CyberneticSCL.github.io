function [prog,P]=sosposmatr(prog,n)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MatrixTools v.03 - sosposmatr
% This program declares a symbolic positive scalar semidefinite matrix P of size nxn 
% inputs: 
% prog
% n - size of matrix variable
% th - some random symbolic variable used in prog(doesn't matter which)
%
% version .03   M. Peet, Stanford. matthew.peet@inria.fr
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% MatrixTools - sosposmatr
% Release Notes:
% v.03 - deleted the stupid requirement to pass in a random symbolic
% variable
%
% Other changes with this release are minor.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if isempty(prog.symvartable(1))
    disp('error: no symbolic variables have been declared')
    return
end

Z=monomials(prog.symvartable(1),[1:n]);
[prog,VAR] = sossosvar(prog,Z,'wscoeff');
sizett=prog.var.idx{length(prog.var.idx)}-prog.var.idx{length(prog.var.idx)-1};
begin_n=prog.var.idx{length(prog.var.idx)-1};
nTT=sqrt(sizett);
nn=begin_n;
for j=1:nTT
    for i=1:nTT
        P(i,j)=sym(['coeff_',int2str(nn)]);
        nn=nn+1;
    end
end
