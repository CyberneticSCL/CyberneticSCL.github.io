Setup and run instructions:

1) Run "Optimal_Battery_Programmer.exe" to initialize the setup wizard and proceed
by pressing "Next". The wizard installs the package and Matlab's Runtime Compiler.

2) After the installation is complete, make sure your user account has the premission
to read from and write to all the files in "/Optimal_Battery_Programmer/application/Output"
and "/Optimal_Battery_Programmer/application/load_data".

3) To run the package, run "/Optimal_Battery_Programmer/application/Optimal_Battery_Programmer.exe".
A dialoge window should open. Answer the questions by typing a value or name in the 
box below each question. 

4) If your answer to Question 1 is NOT "4", then leave the box below Question "2" 
empty. If your answer to Question 1 is "4", then type down the name of your ".csv"
file which contains the load data (e.g., E26load_7.csv). The datafile must have a
single column containing the load values in kW for every 30 minutes in the entire 
month. Example files can be found in the Folder: "/Optimal_Battery_Programmerapplication/load_data".

5) If your answer to Question 7 is NO, then the program will ignore your answer to
Question 8.

6) In Question 8, the format for the solar datafile is the same as the format of
the load data described in item 4.

