function [prog, M, N] = sosjointpos_mat_ker_ndelay_psatz(prog,n,d1,d2,var1,var2,I)
%
% SOSJOINTPOS_MAT_KER(prog,n,d1,d2,var1,var2,I) declares the multiplier $M(s)$ and
% kernel part $N(s,t)$ of a positive multiplier+integral operator. The
% multiplier and kernel have the form
%
% M(s) = g(s)Z(s)^T Q_1 Z(s)
% N(s,t) = g(s) Z(s)^T Q_{12} Z(s,t) + g(t)Z(t,s)^T Q_{21} Z(t) 
%                       + \int_{I(1)}^{I(2)} g(s) Z(ss,s)^T Q_{22} Z(ss,t) dss
% Q = [ Q_{11}  Q_{12} ]
%     [ Q_{21}  Q_{22} ] >0
%
% 
% where Z(x)= Z_d1(x) \otimes I_n and Z_d(x) is the vector of monomials in
% variables x of degree d1 or less. Z(x,y) = Z_{d1}(x) \otimes Z_{d2}(x)
% \otimes I_n. If the application is stability of time-delay systems, d1
% will eventually be more or less the degree of the multiplier and d2 more
% or less the degree of the kernel function.
% we recommend setting d2 = d1 to keep the polynomial degrees balanced.

% INPUTS 
%   prog: SOS program to modify.
%   n: dimension of the resulting matrix
%   d1: degree of the multiplier (sort of)
%   d2: degree of the kernel
%   var1: Single pvar corresponding to s in the description
%   var2: Single pvar corresponding to t in the description
%   I = {[l1 u1]},{[l2,u2]},... cell array of intervals of integration
%
% OUTPUT 
%   M{i}: A cell array of functions of var1 valid on the intervals i
%   N{i,j}: A cell array of kernels valid on the intervals I{i} in variable
%   var1 and intervals I{j} in variable var2
%
% NOTES:
% Distributed with DelayTOOLS
% Compatable with MULTIPOLY and SOSTOOLS as of June 2013
% For support, contact M. Peet, Arizona State University at mpeet@asu.edu

if ~isvalid(var1) || ~isvalid(var2)
  error(['vars must be a polynomial variable']);
end
if ~iscell(I)
    error(['I must be a cell array of intervals'])
end

ss=polynomial(1,1,{'ss'},[1 1]);

% The number of domains of integration
nints=length(I);
% First, define the g{i} nonnegative on the domain of integration I{i} in
% variable var1
for i=1:nints
    g{i}=(var1-I{i}(1))*(I{i}(2)-var1);
    g2{i}=subs(g{i},var1,var2);
    g3{i}=subs(g{i},var1,ss);
end

% I'm going to construct Z manually so I know where everything is
nZth=d1+1;
Z1degmat = [0:d1]';
Z1coeff = speye(nZth);
Z1varname = var1.varname;
Z1matdim = [nZth 1];
Z1th=polynomial(Z1coeff,Z1degmat,Z1varname,Z1matdim);


% There are two configurations for the degree d2. Probably the most logical one is 
% that for TDS applications, 2d1 ends up as the degree of the multiplier and
% 2d2 as the degree of the kernel. This is the following:
%Z2degmat = [repmat([0:d2]',d1+1,1),vec(repmat(0:d1,d2+1,1))];
Z2degmat = [repmat([0:d1]',d2+1,1),vec(repmat(0:d2,d1+1,1))];
nZthksi=length(Z2degmat);
Z2coeff = speye(nZthksi);
Z2varname = [var1.varname; var2.varname];
Z2matdim = [nZthksi 1];
Z2thksi=polynomial(Z2coeff,Z2degmat,Z2varname,Z2matdim);

% For other applications, however, we may want 2d2 to represent the
% internal variable of integration, in which case we use the following:
% 
% Z2degmat = [repmat([0:d2]',d1+1,1),vec(repmat(0:d1,d2+1,1))];
% % Z2degmat = [repmat([0:d2]',d1+1,1),vec(repmat(0:d1,d2+1,1))];
% nZthksi=length(Z2degmat);
% Z2coeff = speye(nZthksi);
% Z2varname = [var1.varname; var2.varname];
% Z2matdim = [nZthksi 1];
% ZZZthksi=polynomial(Z2coeff,Z2degmat,Z2varname,Z2matdim);


nBZ1=n*nZth;
nBZ2=n*nZthksi;


bZ1th=[];
for i=1:n
    bZ1th=blkdiag(bZ1th,Z1th);
end

bZ2thksi=[];
for i=1:n
    bZ2thksi=blkdiag(bZ2thksi,Z2thksi);
end


% First Sparsity Structure
sp1=sparse(nBZ1*nints,nBZ1*nints);
for i=1:nints
    sp1(((i-1)*nBZ1+1):i*nBZ1,((i-1)*nBZ1+1):i*nBZ1)=ones(nBZ1);
end

% Second Sparsity Structure
sp2=sparse(nBZ1*nints,nBZ2*nints^2);
for i=1:nints
    for j=1:nints
        irange=((i-1)*nBZ1+1):i*nBZ1; % standard range
        jrange=((j-1)*nBZ2+1+(i-1)*nBZ2*nints):(j*nBZ2+(i-1)*nBZ2*nints); % for every increase in i, we shift by an entire set of intervals
        sp2(irange,jrange)=ones(nBZ1,nBZ2);
    end
end

% Third Sparsity Structure

sp3=sparse(nBZ2*nints^2,nBZ2*nints^2);
%size(sp3)
for i=1:nints
    sp3(((i-1)*nBZ2*nints+1):i*nBZ2*nints,((i-1)*nBZ2*nints+1):i*nBZ2*nints)=ones(nBZ2*nints);
end
%size(sp3)
sp_pat=[sp1 sp2;sp2' sp3];
[prog,LLL]=sosposmatr_struct(prog,nBZ1*nints+nBZ2*nints^2,sp_pat);
%[prog,LLL]=sosposmatr(prog,nBZ1*nints+nBZ2*nints^2);

%LLL
% For now, we will construct the matrices inefficiently
for i=1:nints
    Ltemp=LLL(((i-1)*nBZ1+1):i*nBZ1,((i-1)*nBZ1+1):i*nBZ1);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    avarname=[Ltemp.varname; Z1varname];
    % For the next part, we just need the degmat part of the block-diagonal
    % monomial matrix
    
    bZdegmat=repmat(Z1degmat,n,1);
    
    [PIlist, PJlist]=find(Ltemp.coefficient); % This is the list of terms in P, but PIlist and Pjlist will be relatively short.
    [PIlist2,ttt]=unique(PIlist);
    PJlist2=PJlist(ttt,:);
    
    [Prowu,Pcolu] = ind2sub([n*nZth n*nZth],PJlist2); % this returns the matrix locations for every term in P
    adegmat = [Ltemp.degmat(PIlist2,:) bZdegmat(Prowu,:)+bZdegmat(Pcolu,:)];
    
    
    % but now we have to modify the coefficient matrix. We can group this by
    % blocks. For a 2x2 matrix, all the coefficients from block 1 will be [1 0 0 0], all the
    % coefficients from block 2 will be [0 1 0 0], all the coefficients from
    % block 3 will be [0 0 0 1],
    
    % Positions in Pjlist from 1:nZ get reassigned to 1, nZ+1:2nZ -> 2, etc
    [row,col] = ind2sub([n*nZth n*nZth],PJlist);
    newrow=ceil(row/nZth);
    newcol=ceil(col/nZth);
    newidx=sub2ind([n n],newrow, newcol);
    
    coeff=sparse(PIlist,newidx,1);
    amatdim=[n n];
    M{i}=g{i}*polynomial(coeff,adegmat,avarname,amatdim);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    clear Ltemp
    %    M{i}=bZ1th'*LLL(((i-1)*nBZ1+1):i*nBZ1,((i-1)*nBZ1+1):i*nBZ1)*bZ1th;
end
% Kernal Part I
% This is the Z(s)^T Q12 Z(s,t) term
LLL2=LLL(1:nints*nBZ1,nints*nBZ1+1:end);
for i=1:nints
    for j=1:nints
        irange=((i-1)*nBZ1+1):i*nBZ1; % standard range
        jrange=((j-1)*nBZ2+1+(i-1)*nBZ2*nints):(j*nBZ2+(i-1)*nBZ2*nints); % for every increase in i, we shift by an entire set of intervals
        Ltemp=LLL2(irange,jrange);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        avarname=[Ltemp.varname; Z2varname ];
        % For the next part, we just need the degmat part of the block-diagonal
        % monomial matrix
        if strcmp(var1.varname{1},Z2varname{1}); % var1 is in the first position
            bZdegmat1=repmat([Z1degmat zeros(nZth,1)],n,1);
        else
            bZdegmat1=repmat([zeros(nZth,1) Z1degmat],n,1);
        end
        bZdegmat2=repmat(Z2degmat,n,1);
        
        [PIlist, PJlist]=find(Ltemp.coefficient); % This is the list of terms in P, but PIlist and Pjlist will be relatively short.
        [Prowu,Pcolu] = ind2sub([n*nZth n*nZthksi],PJlist); % this returns the matrix locations for every term in P
        adegmat = [Ltemp.degmat(PIlist,:) bZdegmat1(Prowu,:)+bZdegmat2(Pcolu,:)];
        %
        % but now we have to modify the coefficient matrix. We can group this by
        % blocks. For a 2x2 matrix, all the coefficients from block 1 will be [1 0 0 0], all the
        % coefficients from block 2 will be [0 1 0 0], all the coefficients from
        % block 3 will be [0 0 0 1],
        
        % Positions in Pjlist from 1:nZ get reassigned to 1, nZ+1:2nZ -> 2, etc
        [row,col] = ind2sub([n*nZth n*nZthksi],PJlist);
        newrow=ceil(row/nZth);
        newcol=ceil(col/nZthksi);
        newidx=sub2ind([n n],newrow, newcol);%(newcol-1)*n+newrow;
        
        nPIlist=(1:length(PIlist))';
        coeff=sparse(nPIlist,newidx,1);
        amatdim=[n n];
        A{i,j}=polynomial(coeff,adegmat,avarname,amatdim);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        clear Ltemp
%       A{i,j}=bZ1th.'*LLL2(irange,jrange)*bZ2thksi;
    end
end
clear LLL2
% Kernal Part II
% This is the Z(t,s)^T Q21 Z(t) term
% for i=1:nints
%     for j=1:nints
%         B{i,j} = subs(subs(subs(A{j,i}.',var1,ss),var2,var1),ss,var2);
%     end
% end

LLL4=LLL(nints*nBZ1+1:end,1:nints*nBZ1);
for i=1:nints
    for j=1:nints
        irange=((i-1)*nBZ2+1+(j-1)*nBZ2*nints):(i*nBZ2+(j-1)*nBZ2*nints); % for every increase in i, we shift by an entire set of intervals
        jrange=((j-1)*nBZ1+1):j*nBZ1; % standard range
%        LLL2(irange,jrange)
        B{i,j}=var_swap(bZ2thksi,var1,var2).'*LLL4(irange,jrange)*subs(bZ1th,var1,var2);
%        A{1,1}(1,1)
    end
end

% Kernal Part III
% This is the int Z(om,s)^T Q22 Z(om,t) term
% bZ2omksi=subs(bZ2thksi,var1,ss);
% bZ2omth=subs(bZ2omksi,var2,var1);
LLL3=LLL(nints*nBZ1+1:end,nints*nBZ1+1:end);
for i=1:nints
    for j=1:nints
        for k=1:nints
            irange=((i-1)*nBZ2+1+(k-1)*nBZ2*nints):(i*nBZ2+(k-1)*nBZ2*nints);
            jrange=((j-1)*nBZ2+1+(k-1)*nBZ2*nints):(j*nBZ2+(k-1)*nBZ2*nints);
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            Ltemp=LLL3(irange,jrange);
            avarname=[Ltemp.varname; var1.varname; var2.varname; ss.varname{1}];
            %assignin('base',['LLL3',int2str(i),int2str(j),int2str(k)],Ltemp)
            if strcmp(var1.varname{1},Z2varname{1}) % th is in the first position
                bZdegmat1=repmat([Z2degmat(:,2) zeros(nZthksi,1)  Z2degmat(:,1)],n,1); %bZomth
                bZdegmat2=repmat([zeros(nZthksi,1) Z2degmat(:,2)  Z2degmat(:,1)],n,1); %bZomksi
            else
                bZdegmat1=repmat([Z2degmat(:,1) zeros(nZthksi,1)  Z2degmat(:,2)],n,1); %bZomth
                bZdegmat2=repmat([zeros(nZthksi,1) Z2degmat(:,1)  Z2degmat(:,2)],n,1); %bZomksi
            end
            
            [PIlist, PJlist]=find(Ltemp.coefficient); % This is the list of terms in P, but PIlist and Pjlist will be relatively short.
            [Prowu,Pcolu] = ind2sub([n*nZthksi n*nZthksi],PJlist); % this returns the matrix locations for every term in P
            adegmat = [Ltemp.degmat(PIlist,:) bZdegmat1(Prowu,:)+bZdegmat2(Pcolu,:)];
            % but now we have to modify the coefficient matrix. We can group this by
            % blocks. For a 2x2 matrix, all the coefficients from block 1 will be [1 0 0 0], all the
            % coefficients from block 2 will be [0 1 0 0], all the coefficients from
            % block 3 will be [0 0 0 1],
            
            newrow=ceil(Prowu/nZthksi);
            newcol=ceil(Pcolu/nZthksi);
            
            newidx=sub2ind([n n],newrow, newcol);%(newcol-1)*n+newrow;
            nPIlist=(1:length(PIlist))';
            coeff=sparse(nPIlist,newidx,1);
            amatdim=[n n];
%             size(coeff)
%             size(adegmat)
%             size(avarname)
%             Ltemp
            CA{i,j,k}=polynomial(coeff,adegmat,avarname,amatdim);
            clear Ltemp
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %CA{i,j,k}=bZ2omth.'*LLL3(irange,jrange)*bZ2omksi;
        end
    end
end
for i=1:nints
    for j=1:nints
        C{i,j}=polynomial(zeros(n,n));
        for k=1:nints
            C{i,j}=C{i,j}+int(g3{k}*CA{i,j,k},ss,I{k}(1),I{k}(2));
        end
        N{i,j}=g{i}*A{i,j}+g2{j}*B{i,j}+C{i,j};
%         N{i,j}=C{i,j};
       
    end
end
