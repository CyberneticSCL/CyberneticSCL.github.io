clear all; close all; echo off; 
total=tic;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% DelayTools/Linear v.04 - solver_delay_nd
%
% This program determines stablity of a linear differential equation with 
% delay, where \dot{x}(t)=A0x(t)+A{1}x(t-tau(1))+...+A{K}x(t-tau(K))  
% where A0, A{i}, and tau(i) are user inputs. 
%
% Inputs: A{i} - these can be arbitrary square matrices of arbitrary 
%         dimension. However,  the higher the higher the dimension of A{i},
%         the more time the program will take to run
%         
%         tau(i) - These can be an arbitrary sequence of positive increasing 
%         numbers.
%
%         orderth - This input controls the accuracy of the results. For
%         most problems, orderth=2 should be sufficient to obtain a
%         reasonable degree of accuracy. Note: orderth should be an even
%         integer.
% 
% Requirements: In order to operate, this program requires a working
%               version of SOStools. There are some known compatability 
%               issues with SOStools and Matlab version 7+ due to errors in 
%               the implementation of Maple v8. In addition, it
%               is highly recommended that the user have a compiled version
%               of cdd. Finally the following package of subprograms are
%               required which allows SOStools to handle matrix objects
%               directly:
%               SOStools Matrix Addon package:
%                   sosposmatr.m
%                   sosposmatr.m
%                   sosmatrvar.m
%                   sossymmatrvar.m
%                   sosposmatrvar.m
%  
% version .03   M. Peet, Stanford. mmpeet@stanford.edu
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DelayTools/Linear v.03 - solver_delay_nd
% Release Notes:
% v.03 - Compatibility with MatrixTOOLS v.03
%
% Coming soon - The big change with release v.04 will be the use of semiseparable
% kernel functions. These functions have properties in common with the
% Gaussian and seem to give an order of magnitude increase in Accuracy in
% most problems, expecially ones which were problematic using separable
% kernels. As yet, we have no joint positivity condition for semiseparable
% kernels. Thus the choice was between either joint positivity or
% semiseparable kernels. Since joint positivity demonstrated little or no
% improvement in performance, the choice was relatively simple.
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs
% 
% % % Verification of $H_\infty$ norm. A stable system with no measured outputs
% A0=[-1];
% A{1}=[-1];
% tau(1)=1;
% C2=[0]
% B=1;%B=[1;1];
% C1=1;
% gam=.8915; % H_\infty norm is accurate to 3 decimals
% D=[0];


% % % Standard 1D system
% A0=[0];
% A{1}=[-1];
% tau(1)=2;
% C2=[1]
% B=1;%B=[1;1];
% C1=1;
% gam=.001;
% D=[1];

% % % Verification of $H_\infty$ norm. A stable system with no measured outputs
% A0=[-1];
% A{1}=[-1];
% tau(1)=1;
% C2=[0]
% B=1;%B=[1;1];
% C1=1;
% gam=.8915;
% D=[0];

% % Example of unobservable system
% A0=[1 0; -1 0];
% A{1}=[1 0; 0 -1];
% tau(1)=1;
% C2=[0 10]
% B=[1;1];%B=[1;1];
% C1=eye(2);
% gam=1;

% % Construction of weakly observable system unobservable system
% nnn=4
% A0=zeros(nnn,nnn)+[zeros(1,nnn); .1*eye(nnn-1) zeros(nnn-1,1)];
% A{1}=-2*eye(nnn);
% tau(1)=1;
% C2=[zeros(1,nnn-1) 1];
% B=[1;zeros(nnn-1,1)];%B=[1;1];
% C1=eye(nnn);
% gam=10;

% % % Construction of easily observable system with large number of states
% nnn=10
% A0=eye(nnn);
% A{1}=-2*eye(nnn);
% tau(1)=1;
% C2=[zeros(1,nnn-1) 1];
% B=ones(nnn,1);%B=[1;1];
% C1=eye(nnn);
% gam=10;
% D=0;
% % 10 states at 232s


% %
% % % paper by Fattouh, Sename, Dion
% A0=[-10 10; 0 1];
% A{1}=[1 1; 1 1];
% tau(1)=.3;
% C2=[0 10]
% B=[1;1];%B=[1;1];
% C1=eye(2);
% D=0;
% gam=.004;

% % Example 2 from review paper by Sename (weakly, spectrally, but not
% % strongly observable) page 443,445,446,447
% A0=[-3 4; 2 0];
% A{1}=[0 0; 1 0];
% tau=.3;
% C2=[0 7]; %C 
% B=[1;1]; %E 
% % We set F=0. Likewise B=0 (no input)
% C1=eye(2);
% D=[0];
% gam=.001;

% % Example 2 from review paper by Sename (weakly, spectrally, but not
% % strongly observable) page 443,445,446,447 %%% MODIFIED
% A0=[-3 4; 2 0];
% A{1}=[0 0; 1 0];
% tau=.3;
% C2=[0 7]; %C 
% B=eye(2); %E 
% % We set F=0. Likewise B=0 (no input)
% C1=eye(2);
% D=[0 0];
% gam=.236;   % Best from Sename is .58 using eps=.001
% % %.236 using order [4 8], epspos=.01, espneg=.001 new wrapper
% % %.236 using order [2 4], epspos=.01, espneg=.001 new wrapper



% %Fridman 2001 example
% A0=[0 0; 0 1];
% A{1}=[-1 -1; 0 -.9];
% tau(1)=.999;
% C2=[0 1]
% B=[1;1];%B=[1;1];
% C1=[1 0];
% gam=.001;
% D=[1];
% 


%Fridman 2001 example modified
A0=[0 0; 0 1];
A{1}=[-1 -1; 0 -.9];
tau(1)=.999;
C2=[0 1];
B=eye(2);%B=[1;1];
C1=[1 0];
gam=2.39; 
%2.39 using order [2 4], epspos=.1, espneg=.01 old wrapper
%2.39 using order [2 4], epspos=.1, espneg=.01 new wrapper (keep new wrapper)
%2.38 using order [4 8], epspos=.1, espneg=.01 new wrapper
%2.33 using order [4 8], epspos=.01, espneg=.001 new wrapper
D=[0 0];
%D=[1];

% 
% % % Briat Thesis, also Javad 2007
% A0=[0 1; -2 -3];
% A{1}=[0 0.1; -.2 -.3];
% tau=2.8;
% C2=[0 1;.5 0]; %C 
% B=[-.2;-.2]; %E 
% C1=eye(2);
% gam=.005;
% D=[0;0];
%
% Enter degree of accuracy - must be an even integer
orderth = 2;
ordernu=4;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% internal variables:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
epspos=.01;           % strictness of lyapunov positivity
epsneg=.001;           % strictness of derivative negativity
% control inputs to SeDuMi 
pars.alg=2;
pars.stepdif=1;
pars.eps=10^(-10);
pars.maxiter=100;
pars.cg.maxiter=200;
pars.cg.qprec=1;
pars.cg.stagtol=1e-22;
pars.cg.restol=5e-5;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% internal processing:
tic
pvar th ksi

n_dim=size(A0,2);
z_dim=size(C1,1);
y_dim=size(C2,1);
w_dim=size(B,2);
n_delay=length(tau);
tauK=tau(n_delay);

mastervartable=[th,ksi];
prog = sosprogram(mastervartable);


II{1}=[-tau(1) 0];            % interval [-\tau,0]
for i=2:n_delay
    II{i}=[-tau(i) -tau(i-1)];%negative on interval [-tau_i,-\tau_i-1]
end
% This is the multiple delay case.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% phase 1 - variables %%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% we will need to declare variables:
% P, Q(th), S(th), R(th,ksi)
%
disp('Overhead and Lyapunov Variables, elapsed time:')

toc

tic
disp('creating joint positive operator variable')

[prog, P,Q,R,S] = sosjointpos_mat_ker_ndelay_parallel_R_L2_PQRS_MTNS(prog,n_dim,n_dim,orderth/2,ordernu/2,th,ksi,II,1);
P=P+epspos*eye(n_dim);
S=S+epspos*eye(n_dim);

% Add an upper bound on the variables


disp('creating Observer Variables')
[prog,Z1]=sosmatrvar(prog,monomials([th],0),[n_dim,y_dim]);
[prog,Z2]=sosmatrvar(prog,monomials([th],0),[n_dim,y_dim]);
[prog,Z3]=sosmatrvar(prog,monomials([th],0:orderth),[n_dim,y_dim]);
[prog,Z4]=sosmatrvar(prog,monomials([th],0:orderth),[n_dim,y_dim]);
[prog,Z5]=sosmatrvar(prog,monomials([th],0:orderth),[n_dim,y_dim]);
[prog,Z6]=sosmatrvar(prog,monomials([th],0:orderth),[n_dim,y_dim]);
[prog,Z7]=sosmatrvar(prog,monomials([th,ksi],0:orderth),[n_dim,y_dim]); % It is possible this term has too many monomials


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% phase 2 - derivatives %%%%%%%%%%%%%%%%%%%%
%%%%%%% Step1 %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% the derivative matrices are spelled out in the paper, they are 
disp('constructing Derivatives, elapsed time:')
tic

% We first construct the terms corresponding to $\ip{x}{APx}$
% These terms are G and D
zzn=polynomial(zeros(n_dim));

D00=zeros(w_dim,w_dim);
D01=zeros(w_dim,n_dim);
D02=zeros(w_dim,n_dim);
D03=zeros(w_dim,n_dim);
D11=P*A0+A0.'*P+subs(Q+Q.'+S,th,0);
D12=P*A{n_delay}-(subs(Q,th,-tau)); 
D22=-subs(S,th,-tau);

D13=subs(R,ksi,0).'+A0.'*Q-diff(Q,th);
    D23=A{n_delay}.'*Q-subs(R,ksi,-tau).';% flag (from paper version)
    D33=-diff(S,th);

    T1=[D00 D01 D02;
        D01.' D11 D12;        
        D02.' D12.' D22];
U1=[D03;
    D13;
    D23];
V1=D33;

W1=-(diff(R,ksi)+diff(var_swap(R.',th,ksi),th)); %flag (from paper version)


% Now we construct the terms corresponding to the observer
% decay rate

Z00=-gam/tau*eye(w_dim);
Z01=-B.'*P;
Z02=zeros(w_dim,n_dim);
Z03=-B.'*Q;
Z11=Z1*C2+C2.'*Z1.'+1/(gam*tau)*(C1.')*C1; %flag
Z12=Z2*C2;                                 %flag
Z13=Z3*C2+C2.'*Z4.';
Z22=zeros(n_dim,n_dim);
Z23=C2.'*Z5.';                             %flag
Z33=Z6*C2+C2.'*Z6.';                       %flag

T2=[Z00 Z01 Z02;
    Z01.' Z11+epsneg*eye(n_dim) Z12;
    Z02.' Z12.' Z22];
U2=[Z03;
    Z13;
    Z23];
V2=Z33+epsneg*eye(n_dim)/tau;
W2=Z7*C2+C2.'*var_swap(Z7.',th,ksi);       %flag


T=T1+T2;
U=U1+U2;

V=V1+V2;
W=W1+W2;


toc





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Step2 %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Enforce negativity of D 
disp('enforcing negativity of derivative')



disp('creating joint positive operator variable')

[prog, Teq,Ueq,Weq,Veq] = sosjointpos_mat_ker_ndelay_parallel_R_L2_PQRS_MTNS(prog,w_dim+2*n_dim,n_dim,orderth/2,ordernu/2,th,ksi,II,1);




% Should we make this exact?
disp('running equalities, elapsed time:')
tic

    [prog] = sosmateq(prog,Teq+T);
    [prog] = sosmateq(prog,Ueq+U);
    [prog] = sosmateq(prog,Veq+V);
    [prog] = sosmateq(prog,Weq+W);
toc
disp('TOTAL POLYNOMIAL TIME:')
toc(total)
disp('Computing Solution')


disp('Computing Solution')
%prog = sossolve(prog);
prog = sossolve_p(prog,pars);
%% Conclusion:
if norm(prog.solinfo.info.feasratio-1)<=.1 && ~prog.solinfo.info.numerr
    disp('The Observer Design is Feasible.')
elseif norm(prog.solinfo.info.feasratio-1)<=.1 && prog.solinfo.info.numerr
    disp('The Observer Design is likely Feasible. However, Double-check the precision.')
elseif prog.solinfo.info.pinf || prog.solinfo.info.dinf || norm(prog.solinfo.info.feasratio+1)<=.1
    disp('The Observer Design is Probably not Feasible.')
else
    disp('Unable to definitively determine feasibility. Numerical errors dominating or at the limit of stability.')
end


% Now extract the solution....

r=tau(n_delay);
NP = sosgetsolmat(prog,P,5);
NQ = sosgetsolmat(prog,Q,5);
NS = sosgetsolmat(prog,S,5);
NR = sosgetsolmat(prog,R,5);

NZ1 = sosgetsolmat(prog,Z1,5);
NZ2 = sosgetsolmat(prog,Z2,5);
NZ3 = sosgetsolmat(prog,Z3,5);
NZ4 = sosgetsolmat(prog,Z4,5);
NZ5 = sosgetsolmat(prog,Z5,5);
NZ6 = sosgetsolmat(prog,Z6,5);
NZ7 = sosgetsolmat(prog,Z7,5);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% We now have the variables and the next step is computing the inverse of
% P_{P,Q,S,R}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



% extract representation of NP12
[P_h,Q_h,R_h,S_h] = P_PQRS_Inverse_joint_sep_vtau(NP,NQ,NR,NS,[-tau,0]);



% Now that we have the inverse, we compose with the Z variables to find the
% observer gains.
% Note that currently Zi(th) and Z7(th,ksi)
% As opposed to the notes, we will define L_i(th) and L7(th,ksi)

L1=P_h*NZ1+int(Q_h*NZ4,th,-r,0);
L2=P_h*NZ2+int(Q_h*NZ5,th,-r,0);
L3=P_h*NZ3+Q_h*NZ6+subs(int(Q_h*NZ7,th,-r,0),ksi,th); 
L4=Q_h.'*NZ1+S_h*NZ4+int(R_h*subs(NZ4,th,ksi),ksi,-r,0);
L5=Q_h.'*NZ2+S_h*NZ5+int(R_h*subs(NZ5,th,ksi),ksi,-r,0);
L6=S_h*NZ6;
pvar sss
L7=Q_h.'*subs(NZ3,th,ksi)+S_h*NZ7+R_h*subs(NZ6,th,ksi)+int(subs(R_h,ksi,sss)*subs(NZ7,th,sss),sss,-tau,0);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% disturbance version
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% To simulate the estimator, we define a function which gives the RHS of \dot x and \dot
% \phi_i. \phi(s,t) is discretized in space using N*n_dim lumped states
tspan=20*tau;
N=20;
% where the states are determined by the values of s in xmesh 
 xmesh=linspace(-tau,0,N);
 dx=xmesh(2)-xmesh(1);
sim_option=3;% 1 for dde23, 2 for discretized with ode45, 3 for lsim version

 
% More precisely, for 2 states \phi(1:2) corresponds to x(t-tau) and
% \phi(N*n_dim-1,N*n_dim) corresponds to x(t)

% Note you cannot start the estimator before time tau=r, as there is
% insufficient history observed


% To increase efficiency, we only pass the values of Li at these mesh points



clear L1M L2M L3M L4M L5M L6M L7M
ii=0;
L1M=double(L1); 
L2M=double(L2);
for xi=xmesh
    ii=ii+1;
    L3M(:,:,ii)=double(subs_p(L3,th,xi));
    L4M(:,:,ii)=double(subs_p(L4,th,xi));
    L5M(:,:,ii)=double(subs_p(L5,th,xi));
    L6M(:,:,ii)=double(subs_p(L6,th,xi));
    jj=0;
    for xj=xmesh
        jj=jj+1;
        L7M(:,:,ii,jj)=double(subs_p(subs_p(L7,ksi,xj),th,xi));
    end
end



%%%%%%%%%%%%%%%% new simulator %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% We now construct the derivative matrices for the estimator and state (unless dde23 is used)

rangef=(n_dim*(N-1)+1):n_dim*N;
Apr=[-eye((N-1)*n_dim)/dx zeros((N-1)*n_dim,n_dim);
    A{1} zeros(n_dim,(N-2)*n_dim) A0]+[zeros((N-1)*n_dim,n_dim) eye((N-1)*n_dim)/dx ;
    zeros(n_dim,N*n_dim)];
Apr2=zeros(n_dim*N,y_dim*N);

rangef2=(y_dim*(N-1)+1):y_dim*N;
for i=1:N-1
    rangei=((i-1)*n_dim+1):(i*n_dim);
    rangei2=((i-1)*y_dim+1):(i*y_dim);
    Apr2(rangei,rangef2)=L4M(:,:,i);
    Apr2(rangei,1:y_dim)=L5M(:,:,i);
    Apr2(rangei,rangei2)=Apr2(rangei,rangei2)+L6M(:,:,i);
    for j=1:N
        rangej2=((j-1)*y_dim+1):(j*y_dim);
        Apr2(rangei,rangej2)=Apr2(rangei,rangej2)+dx*L7M(:,:,i,j);
    end 
end
% Last row of Apr2
Apr2(rangef,1:y_dim)=L2M;
Apr2(rangef,rangef2)=L1M+L3M(:,:,N)*dx;
for i=2:N-1
    rangei2=((i-1)*y_dim+1):(i*y_dim);
    Apr2(rangef,rangei2)=L3M(:,:,i)*dx;
end


%%% Here we enter our disturbance model as an anonymous function which
%%% is zero until time t=tau. Right now this only is implemented for a
%%% single disturbance channel
wfun=@(t) 10*(t>tau)*sinc((4*t-tau)) % disturbance function - zero until time tau (to allow for startup)

% Here we numerically calculate the L_2 norm of the disturbance
tmesh1=linspace(0,tspan,1000);
norm_w=0;
for tt=2:length(tmesh1)
    norm_w=norm_w+norm(wfun(tmesh1(tt)))^2*(tmesh1(tt)-tmesh1(tt-1));
end
l2w=sqrt(norm_w)


if sim_option==1
    
    if n_delay==1
        ddefun=@(t,y,Z) A0*y+A{1}*Z(:,1)+B*[wfun(t);-wfun(t)]
        x_sol=dde23(ddefun,tau,zeros(n_dim,1),[0,tspan])
    elseif n_delay==2
        ddefun=@(t,y,Z) A0*y+A{1}*Z(:,1)+A{2}*Z(:,2)+B*wfun(t)
        x_sol=dde23(ddefun,tau,zeros(n_dim,1),[0,tspan])
    else
        disp('Simulation currently only runs for 1 or 2 delays')
    end
    
    figure
    plot(x_sol.x,x_sol.y)
    
    e_dynamics = @(t,y) estimator_dynamics2(t,y,Apr,Apr2,C2,xmesh,x_sol) % This has now been optimized for speed
    ic=zeros(N*n_dim,1);
    options=odeset('MaxStep',dx/2,'InitialStep',dx/2);
    [t,y] = ode45(e_dynamics, [tau tspan], ic,options);
    
    
    error=deval(x_sol,t).'-y(:,((N-1)*n_dim+1):(N*n_dim));
    
    figure
    plot(t,error)
    
    
    norm_err=0;
    for tt=2:length(t)
        norm_err=norm_err+norm(error(tt,:))^2*(t(tt)-t(tt-1));
    end
    l2err=sqrt(norm_err)
    
    gamma_est=l2err/l2w
    
    clear xhatfull_1 xfull_1 xhatfull_2 xfull_2
    % Distributed error
    for tt=1:length(t)
        tmesh=t(tt)+xmesh;
        temp=deval(x_sol,tmesh);
        xfull_1(tt,:)=temp(1,:);
        xfull_2(tt,:)=temp(2,:);
        %x_state(tt,)=deval(x_sol,1)  % n_dim*N matrix whose i,j entry is the ith state at time t-xmesh(j)
    end
    % estimated histort of state 1 and 2
    idx=1:N; idxev=idx*2; idxodd=idxev-1;
    xhatfull_1=y(:,idxodd);xhatfull_2=y(:,idxev);
    
    errorfull_1=xhatfull_1-xfull_1;
    figure
    plot(t,errorfull_1)
    figure
    errorfull_2=xhatfull_2-xfull_2;
    plot(t,errorfull_2)
    
elseif sim_option==2
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %% discretized version
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    rangef=(n_dim*(N-1)+1):n_dim*N;
    %     Apr0=[-eye((N-1)*n_dim)/dx zeros((N-1)*n_dim,n_dim);
    %         A{1} zeros(n_dim,(N-2)*n_dim) A0]+[zeros((N-1)*n_dim,n_dim) eye((N-1)*n_dim)/dx ;
    %         zeros(n_dim,N*n_dim)];
    Bpr0=[zeros(n_dim*(N-1),w_dim); B];
    
    odefun=@(t,y) Apr*y+Bpr0*[wfun(t);wfun(t)]
    
    ic=zeros(N*n_dim,1);
    options=odeset('MaxStep',dx/2,'InitialStep',dx/2);
    x_sol0 = ode45(odefun, [0 tspan], ic,options);
    figure
    plot(x_sol0.x,x_sol0.y(rangef,:))
    
    e_dynamics = @(t,y) estimator_dynamics3(t,y,Apr,Apr2,C2,xmesh,x_sol0) % This has now been optimized for speed
    ic=zeros(N*n_dim,1);
    options=odeset('MaxStep',dx/2,'InitialStep',dx/2);
    [t,y] = ode45(e_dynamics, [tau tspan], ic,options);
    
    
    error=deval(x_sol0,t,rangef).'-y(:,((N-1)*n_dim+1):(N*n_dim));
    
    figure
    plot(t,error)
    
    
    norm_err=0;
    for tt=2:length(t)
        norm_err=norm_err+norm(error(tt,:))^2*(t(tt)-t(tt-1));
    end
    l2err=sqrt(norm_err)
    
    gamma_est=l2err/l2w
    
%     clear xhatfull_1 xfull_1 xhatfull_2 xfull_2
%     % Distributed error
%     for tt=1:length(t)
%         tmesh=t(tt)+xmesh;
%         temp=deval(x_sol,tmesh);
%         xfull_1(tt,:)=temp(1,:);
%         xfull_2(tt,:)=temp(2,:);
%         %x_state(tt,)=deval(x_sol,1)  % n_dim*N matrix whose i,j entry is the ith state at time t-xmesh(j)
%     end
%     % estimated history of state 1 and 2
%     idx=1:N; idxev=idx*2; idxodd=idxev-1;
%     xhatfull_1=y(:,idxodd);xhatfull_2=y(:,idxev);
%     
%     errorfull_1=xhatfull_1-xfull_1;
%     figure
%     plot(t,errorfull_1)
%     figure
%     errorfull_2=xhatfull_2-xfull_2;
%     plot(t,errorfull_2)
%     
elseif sim_option==3
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %% discretized unified version
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    CO=kron(eye(N),C2);
    Abig=double([Apr zeros(size(Apr));
        -Apr2*CO Apr+Apr2*CO]);
    Bbig=[zeros(n_dim*(N-1),w_dim); B ;zeros(n_dim*N,w_dim)];
    Cbig=[zeros(z_dim,n_dim*(N-1))  -C1  zeros(z_dim,n_dim*(N-1)) C1];
    sys=ss(Abig,Bbig,Cbig,0);
    
    nsamples=1000;
    t2=linspace(0,tspan,nsamples);
    u=repmat(sinc((t2-tau)).',1,w_dim);
%    u=repmat(sin((t2-tau)).',1,w_dim);
%     for t3=1:nsamples
%     u(t3,:)=wfun(t2(t3));
%     end
    [ys,ts,xs]=lsim(sys,u,t2);
    dt=t2(2)-t2(1);
    ntemp=0;
    ntemp2=0;

    for t3=1:nsamples-1
    ntemp=ntemp+u(t3,:)*u(t3,:).'*dt;
    ntemp2=ntemp2+ys(t3,:)*ys(t3,:).'*dt;
    end
    normu=sqrt(ntemp);
    normy=sqrt(ntemp2);
    gain_est=normy/normu
    plot(ts,xs(:,n_dim*N+1:2*N*n_dim))

    rangef1=n_dim*(N-1)+1:n_dim*N;
    rangef2=n_dim*(2*N-1)+1:2*n_dim*N;
    figure
    plot(ts,xs(:,rangef2)-xs(:,rangef1))
    hold on
    plot(ts,u)
    return

end



