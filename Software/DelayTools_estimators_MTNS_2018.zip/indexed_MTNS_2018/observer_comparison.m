% % Comparison with $H_infty$ optimal observers from other sources
% 
% A0=[-3 4; 2 0];
% A1=[0 0; 1 0];
% tau=.3;
% C2=[0 7]; %C 
% B=eye(2); %E modification for 2 channels 
% %B=[1;1]; %E 
% 
% % We set F=0. Likewise B=0 (no input)
% C1=eye(2);
% gam=.58;
% epsilon=.001;
% % for F+S [12], solve ARE
% % A0'P+PA0+2P(gam^2*A1*A1'+EE')P-2/epsilon*C'*(I-1/epsilon*FF')C+2/gam^2
% % A'XE + E'XA - (E'XB + S)R^{-1}  (B'XE + S') + Q = 0
% % Using bisection, the best gamma in this case is .298
% C=C2;
% %R=-eye(3);
% R=-eye(4)/2;
% %Br=sqrt(2)*[gam*A1 B];
% Br=[gam*A1 B];
% A=A0;
% Q=-2/epsilon*(C'*C)+2/gam^2*eye(2);
% [P,Lx,Gx] = care(A,Br,Q,R)
% L=1/epsilon*inv(P)*C'
% 
% A0'*P+P*A0+2*P*(gam^2*A1*A1'+B*B')*P-2/epsilon*C'*C+2/gam^2*eye(2)
% 

% % Fridman Example
A0=[0 0; 0 1];
A1=[-1 -1; 0 -.9];
tau(1)=.999;
C2=[0 1]
B=eye(2);%B=[1;1];
C1=[1 0];

gam=5000;
epsilon=.001;
% for F+S [12], solve ARE
% A0'P+PA0+2P(gam^2*A1*A1'+EE')P-2/epsilon*C'*(I-1/epsilon*FF')C+2/gam^2
% A'XE + E'XA - (E'XB + S)R^{-1}  (B'XE + S') + Q = 0
% Using bisection, the best gamma in this case is .298
C=C2;
%R=-eye(3);
R=-eye(4)/2;
%Br=sqrt(2)*[gam*A1 B];
Br=[gam*A1 B];
A=A0;
Q=-2/epsilon*(C'*C)+2/gam^2*eye(2);
[P,Lx,Gx] = care(A,Br,Q,R)
L=1/epsilon*inv(P)*C'

A0'*P+P*A0+2*P*(gam^2*A1*A1'+B*B')*P-2/epsilon*C'*C+2/gam^2*eye(2)

