function [ temp ] = int_fun2( sss )
global NS Z_r_th
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
pvar th
    temp=double(subs_p(Z_r_th,th,sss))*inv(double(subs_p(NS,th,sss)))*double(subs_p(Z_r_th,th,sss)).';
    
end

