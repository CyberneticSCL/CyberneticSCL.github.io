clear all; close all; echo off; 
total=tic;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% DelayTools/Linear v.05 - solver_ndelay_dual_joint_nd_vZ
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This program determines stablity of a linear differential equation with 
% multiple delays using a dual form of Lyapunov-Krasovskii functional.
% Here \dot{x}(t)=A0x(t)+A{1}x(t-tau(1))+...+A{K}x(t-tau(K))  
% where A0, A{i}, and tau(i) are user inputs. 
%
% Inputs: A{i} - these can be arbitrary square matrices of arbitrary 
%         dimension. 
%         
%         tau(i) - These can be an arbitrary sequence of positive increasing 
%         numbers.
%
%         orderth/ordernu - This input controls the accuracy of the results. For
%         most problems, orderth=ordernu=4 should be sufficient to obtain a
%         reasonable degree of accuracy. Note: orderth should be an even
%         integer.
% 
% Requirements: In order to operate, this program requires a working
%               version of SOStools. There are some known compatability 
%               issues with SOStools and Matlab version 7+ due to errors in 
%               the implementation of Maple v8. In addition, it
%               is highly recommended that the user have a compiled version
%               of cdd. Finally the following package of subprograms are
%               required which allows SOStools to handle matrix objects
%               directly:
%               SOStools Matrix Addon package:
%                   sosposmatr.m
%                   sosmateq.m
%                   sosjointpos_mat_ker_ndelay_PQRS_vZ
%                   sosjointpos_mat_ker_R_L2
%                   sosjointpos_mat_ker_R_L2_psatz
%
% version .03   M. Peet, Arizona State University. mpeet@asu.edu
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs
%
% Enter degree of accuracy - must be an even integer
orderth = 2;
ordernu = 4;  % it is recommended to use ordernu = 2*orderth in order to match degrees
override1=0; % if override1=1, the LF will not include psatz terms in the kernel - default=0
override2=0; % if override2=1, the derivative check will not include psatz terms in the kernel - default=0

%
% Enter system dynamics in terms of A0, A{1}, ..., A{K}

% % % % Problem A:
%  A0=0;%
%  A{1}=-1;%
%  tau(1) = 1.48; %1.5707
% % orderth 2 [1.558 1.559] time=.309
% % orderth 4 [1.5707] time=.516
% % orderth 6 [1.5707] time=.776
 
% % % Problem B:
% A0=[0 1; -2 .1];
% A{1}=[0 0;1 0];
% tau(1) = .100174 %[.10017, 1.71785]
% % orderth 2 [.10017 .10018 ] [1.693 1.694] time=.478
% % orderth 4 [.100173 .100174] [1.7176 1.7177] time= .879
% % orderth 6 [.100173 ] [1.71785] time=2.48

% % % Problem C:
% A0=-2;%
% A{1}=3;%
% A{2}=-1;%
% tau(1) = 1;%
% tau(2) = 2;%
% % orderth 2 [.829 .83] time=.603
% % orderth 4 [2.9999 3] time=1.5
% % orderth 6 [] time=3.809


% % % Problem D:
A0=[0 1; -1 .1];
A{1}=[0 0;-1 0];
A{2}=[0 0;1 0];
tau(2) = 1.353%1.372 is max [1.35,1.372]
tau(1) = tau(2)/2;
% % orderth 2 [1.354 1.355] time=1.75
% % orderth 4 [1.3722 1.3723] time=7.51
% % orderth 6 [1.3722 1.3723 ] time=27.2

% % % Problem E:
% Anom=[0 0 1 0;
%     0 0 0 1; 
%     -10 10 0 0;
%     5 -15 0 -.25];
% B=[0;0;1;0];C=[1 0 0 0];K=1;
% A0=Anom-B*K*C;
% A{1}=B*K*C;
% tau(1) = 3;
% % % % orderth 2 [no] time=2.23
% % % % orderth 4 yes time=7.45
% % % % orderth 6 yes time=21.6

% % % Problem F: This is scalability test which uses orderth=ordernu=2 and
% both overrides. For this case, in the 1-delay case, the max delay detectable is ~1.48<1.57

% delaymat=[1 2 3 5 10]
% dimmat=[1 2 3 5 20]
% for iii=1:1
%     for jjj=5:5
%         clear prog tau A A0 R R2 Q Q2 S S2 P P2 G 
% nndim=dimmat(jjj);nndelay=delaymat(iii);
% 
% A0=zeros(nndim);
% for j=1:nndelay
%   A{j}=-eye(nndim)/nndelay;
%   tau(j) = j/nndelay;
% end
% % % % %          n_dim
% % % % %          1      2      3      5      10
% % % % % n_dly 1  .366  .094   .158   .686   12.8
% % % % % n_dly 2  .112  .295   1.260  10.83  61.05
% % % % % n_dly 3  .177  1.311  6.86   96.85  5223
% % % % % n_dly 5  .895  13.05  124.7  2014   80950
% % % % % n_dly 10 13.09 59.5   5077 

%====================


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% internal variables:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%fact=1/tau;
fact=1;           % conditioning multiplier
eps1=.01;           % strictness of LF w/r to norm{x(0)} - must be strictly positive (but can be small)
eps11=0;          % strictness of LF w/r to norm{x_t}_{L2}
eps2=0;           % strictness of derivative negativity

% control inputs to SeDuMi 
pars.alg=2;
pars.stepdif=1;
pars.eps=10^(-10);
pars.maxiter=100;
pars.cg.maxiter=200;
pars.cg.qprec=1;
pars.cg.stagtol=1e-22;
pars.cg.restol=5e-5;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% internal processing:
pvar th ksi

n_dim=length(A0);
n_delay=length(tau);
tauK=tau(n_delay);

mastervartable=[th,ksi];
prog = sosprogram(mastervartable);

% This is the multiple delay case.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% phase 1 - variables %%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% we will need to declare variables:
% P, Q(th), S(th), R(th,ksi)
%

disp('creating joint positive operator variable')
tic


[prog,P,Q,R,S] = sosjointpos_mat_ker_ndelay_PQRS_vZ(prog,n_dim,n_dim,orderth/2,ordernu/2,th,ksi,tau,override1);
toc
P=P+eps1*eye(n_dim); % making the operator strictly positive

% There are two constraints that the variables must satisfy: 
% P=\tau_kQ_i(0)^T + \tau_k S_i(0)   for all i
% Q_i(s)=R_{j,i}(0,s)                for all i,j

for i=1:n_delay % the latter i define constraints
    S{i}=S{i}+eps11*eye(n_dim);
    prog = sosmateq(prog,P-(tauK*subs(Q{i}.',th,0)+tauK*subs(S{i},th,0)));   
    for j=1:n_delay % the latter j>1 define constraints
    prog = sosmateq(prog,Q{i}-subs(var_swap(R{j,i},th,ksi),ksi,0));
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% phase 2 - derivatives %%%%%%%%%%%%%%%%%%%%
%%%%%%% Step1 %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% the derivative matrices are spelled out in the paper, they are 
disp('constructing Derivatives, elapsed time:')
tic

% first do the constant terms. These are inside the integral.
D11=A0*P+P*A0.';
D12=[];
D22=[];
for i=1:n_delay
    D11=D11+tauK*A{i}*subs(Q{i}.',th,-tau(i))+tauK*subs(Q{i},th,-tau(i))*A{i}.'+subs(S{i},th,0);
    D12=[D12 tauK*A{i}*subs(S{i},th,-tau(i))]; 
    D22=blkdiag(D22,(subs(-S{i},th,-tau(i))));
end
D21=D12.';
D1=[D11 D12;D21 D22];


parfor i=1:n_delay
    D13{i}=A0*Q{i} + diff(Q{i},th);
    for j=1:n_delay
         D13{i}=D13{i}+A{j}*subs(var_swap(R{j,i},th,ksi),ksi,-tau(j));
    end
    D31{i}=D13{i}.';
    D23{i}=polynomial(zeros(n_delay*n_dim,n_dim));
    D33{i}=diff(S{i},th);
    V{i}=[D13{i};D23{i}];
end


parfor i=1:n_delay
    for j=1:n_delay
        G{i,j}=(diff(R{i,j},th)+diff(var_swap(R{j,i}.',th,ksi),ksi));
    end
end

toc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Step2 %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Enforce negativity of D 
disp('enforcing negativity of derivative')
%Now declare first spacing functions

%[prog, M, N] = sosjointpos_mat_ker_ndelay(prog,2*n_dim,orderth/2,ordernu/2,th,ksi,II);
disp('Calling for jointly positive Mat/Kernel, elapsed time:')
tic
[prog,P2,Q2,R2,S2] = sosjointpos_mat_ker_ndelay_PQRS_vZ(prog,(n_delay+1)*n_dim,n_dim,orderth/2,ordernu/2,th,ksi,tau,override2);
toc

disp('Constructing Equality Constraints:')

tic
prog = sosmateq(prog,D1+P2);
for i=1:n_delay
    prog = sosmateq(prog,Q2{i}+V{i});
    prog = sosmateq(prog,S2{i}+D33{i});
    for j=i:n_delay % the latter j>1 define constraints
            prog = sosmateq(prog,R2{i,j}+G{i,j});
    end
end
toc

toc
disp('TOTAL POLYNOMIAL TIME:')
toc(total)
disp('Computing Solution')


disp('Computing Solution')
prog = sossolve(prog);
%% Conclusion:
if norm(prog.solinfo.info.feasratio-1)<=.1 && ~prog.solinfo.info.numerr
    disp('The System is STABLE.')
elseif norm(prog.solinfo.info.feasratio-1)<=.1 && prog.solinfo.info.numerr
    disp('The System is likely STABLE. However, Double-check the precision.')
elseif prog.solinfo.info.pinf || prog.solinfo.info.dinf || norm(prog.solinfo.info.feasratio+1)<=.1
    disp('The System is probably NOT STABLE.')
else
    disp('Unable to definitively determine stability. Numerical errors dominating or at the limit of stability.')
end

% mat_results(iii,jjj)=prog.solinfo.info.timing(2);
% end 
% end


% % Simulate the system to verify
tspan=10*tau(n_delay)
if n_delay==1
    ddefun=@(t,y,Z) A0*y+A{1}*Z(:,1)
    sol=dde23(ddefun,tau(1),ones(n_dim,1),[0,tspan])
elseif n_delay==2
    ddefun=@(t,y,Z) A0*y+A{1}*Z(:,1)+A{2}*Z(:,2)
    sol=dde23(ddefun,tau,ones(n_dim,1),[0,tspan])
else
    disp('Simulation currently only runs for 1 or 2 delays')
end
plot(sol.x,sol.y)



