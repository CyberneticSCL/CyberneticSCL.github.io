
% DelayTOOLs Version 1.0
% Created by M. Peet
% 
% Version History
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Version 1.0 - 4/30/2018
% This update of DelayTOOLS adds new functionality and improved
% performance. Specifically, new tools are added for Dual stability, $Hinf$
% optimal estimator design, Hinf gain analysis, and Hinf controller
% synthesis. There is also a simplified version of the primal stability 
% analysis tool. 
%
% The new functionality is organized by solvers, as described below
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Stability Analysis of Linear Time-Delay Systems:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% solver_ndelay_dual_joint_nd_vZ
%
% Determines stability of a multiple-delay system using the Dual form of
% Lyapunov-Krasovskii condition.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% solver_ndelay_primal_joint_nd_vZ
%
% Determines stability of a multiple-delay system using the standard Z form of
% Lyapunov-Krasovskii condition.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Performance Analysis of Linear Time-Delay Systems:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% solver_ndelay_primal_Hinf_gain_vZ
%
% Determines stability of a multiple-delay system using the standard Z form of
% Lyapunov-Krasovskii condition.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Estimator Design:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% solver_1delay_nd_joint_Hinf_estimator_release
%
% Find the Hinf optimal estimator for a 1-delay system with several options
% for implementation.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%














