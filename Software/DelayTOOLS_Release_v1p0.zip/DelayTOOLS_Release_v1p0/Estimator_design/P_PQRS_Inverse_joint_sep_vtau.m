function [Ph,Qh,Rh,Sh] = P_PQRS_Inverse_joint_sep_vtau(NP,NQ,NR,NS,I)
%
% P_PQRS_Inverse_joint_sep(P,Q,R,S) computes the inverse operator of the
% operator
%
% P[ x1    ](s)=[ P*x1 +int_I(1)^I(2) Q(th)x_2(th)d th                    ]
%  [ x2(s) ]    [ tau*Q(s)^T*x1 +S(s)x_2(s) + int_I(1)^I(2) R(s,th)x_2(th)dth ]
%
% INPUTS 
%   prog: SOS program to modify.
%   n: dimension of the resulting matrix
%   I = [l1 u1] interval of integration
%
% OUTPUT 
%   Ph,Qh,Rh,Sh: polynomials of dimensions compatible with P,Q,R,S
%
% the inverse operator has the form
% P^-1[ x1    ](s)=[ Ph*x1 +1/tau int_I(1)^I(2) Qh(th)x_2(th)d th                    ]
%     [ x2(s) ]    [ Qh(s)^T*x1 +1/tau Sh(s)x_2(s) + 1/tau int_I(1)^I(2) Rh(s,th)x_2(th)dth ]
%
% NOTES:
% Distributed with DelayTOOLS
% Compatable with MULTIPOLY and SOSTOOLS as of June 2013
% For support, contact M. Peet, Arizona State University at mpeet@asu.edu
% Last update:
% 1/27/18 - MMP

l=I(1);u=I(2);
tau=u-l;

n_dim=size(NP,1);
m_dim=size(NS,1);

% if ~iscell(I)
%     error(['I must be a cell array of intervals'])
% end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The first step is to construct the separable representation of the
% Polynomials Q and R
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% For ZQ and NR, we need to convert to the forms
% NQ=H Z(s) and NR= Z(s)^T Gam Z(theta) as per paper
% or for us this is Q=HZ(theta) and NR= Z(theta)^T Gam Z(ksi)
% however, we need to be consistent about our Z

dQ=NQ.degmat;
dmQ=max(max(dQ));
dR=NR.degmat;
dmR=max(max(dR));
dm=max([dmQ dmR]);
ZCth=polynomial(eye(dm+1),[0:dm]',NQ.Varname(1),[dm+1 1]); % common vector of monomials
bigZCth=[];
for i=1:m_dim
    bigZCth=blkdiag(bigZCth,ZCth);
end

% Now use bigZCth to find H!
nZ=length(ZCth);
for i=1:n_dim
    for j=1:m_dim
        [CQij,Ztemp,etemp] = poly2basis(NQ(i,j),ZCth); % examine each element of NQ
        bigC(i,(nZ*(j-1)+1):(nZ*j))=CQij.';
    end
end
H=bigC;


% H*bigZCth-NQ  uncomment to verify the representation (should be 0)

% Now we deal with NR

for i=1:m_dim
    for j=1:m_dim % address the decomposition of each element separately and place in the larger matrix Q
        dmij=NR(i,j).degmat;
        cfij=NR(i,j).coeff;
        CN=zeros(dm+1,dm+1);
        for k=1:length(cfij) % take each coefficient and put it in its proper place in CN, which is then assembled into CbigN
            CN(full(dmij(k,1))+1,full(dmij(k,2))+1)=cfij(k);
        end
        Gam(((dm+1)*(i-1)+1):((dm+1)*i),((dm+1)*(j-1)+1):((dm+1)*j))=CN;
    end
end
%bigZCksi=subs(bigZCth,th,ksi);
%bigZCksi.'*Gam*bigZCth-NR % this should be zero

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now that we have the right representation, we can construct the inverse
% using Keqin's formula.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% The first step is to find a polynomial approximation to S^{-1}

N=100; orderapp=6; % specifies the degree of the polynomial approximation and the number of data points to fit at.
% It is recommended to use at least a 4th order approximation

interval = tau/N; % specifies the degree of the polynomial approximation and the number of data points to fit at.
% It is recommended to use at least a 4th order approximation
ii=0;
pvar th ss ksi

for ss=[l:interval:u]
    ii=ii+1;
    NShtemp(:,:,ii)=inv(double(subs_p(NS,th,ss))); % Calculates the value of the inverse of S at every point in the interval
end

% The following fits a polynomial to every element of S^{-1}
for i=1:m_dim
    for j=1:m_dim
        Data1=squeeze(NShtemp(i,j,:))';
        [temp,S,mu]=polyfit([l:interval:u],Data1,orderapp); % uses matlab internal polynomial representation
        syms th2   %Converts to a symbolic variable representation
        Sinv_temp=s2p(poly2sym(temp,th2)); % this approach works, but seems fragile. 
        pvar th2   % Converts to a pvar representation
        Sinv(i,j)=subs(Sinv_temp,th2,th);
        clear Data1 temp Sinv_temp
    end
end

% This is the polynomial that is returned. It is not used to calculate the
% following integral, however.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Now we compute the matrix K (does not use the approximate S^{-1})
% This is an anonymous function which is the integrand 
int_fun = @(sss) double(subs_p(bigZCth,th,sss))*inv(double(subs_p(NS,th,sss)))*double(subs_p(bigZCth,th,sss)).';
% Uses Matlab internal numerical integration routine.
K=integral(int_fun,l,u,'ArrayValued',true);

% Now ready to compute the matrices to return

Sh=Sinv;

Z_h_th=bigZCth*Sinv; % This inherits its degree from S^{-1}

P_inv=inv(double(NP));

ndtemp=size(K,1);

T=inv(eye(ndtemp)+K*Gam-K*H.'*P_inv*H); % Scalar Matrix
H_h=-P_inv*H*T; % Scalar Matrix

Ph=(eye(n_dim) + P_inv*H*T*K*H.')*P_inv;
Qh = H_h*Z_h_th; % Same degree as S^{-1}

Gam_h=(T.'*H.'*P_inv*H-Gam)*inv(eye(ndtemp)+K*Gam); % % Scalar Matrix

Z_h_ksi=subs(Z_h_th,th,ksi);   
Rh = Z_h_th.'*Gam_h*Z_h_ksi;  % Twice the degree of S^{-1}



