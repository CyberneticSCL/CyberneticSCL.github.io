function [prog, MR, NR] = sosjointpos_mat_ker_ndelay_parallel_R_L2_MTNS(prog,n1,n2,d1,d2,var1,var2,I,override)
%
% SOSJOINTPOS_MAT_KER(prog,n,d1,d2,var1,var2,I) declares the multiplier $M(s)$ and
% kernel part $N(s,t)$ of a positive multiplier+integral operator. The
% multiplier and kernel have the form
%
% M(s) = Z(s)^T Q_1 Z(s)
% N(s,t) = Z(s)^T Q_{12} Z(s,t) + Z(t,s)^T Q_{21} Z(t) + \int_{I(1)}^{I(2)}
% Z(ss,s)^T Q_{22} Z(ss,t) dss
% Q = [ Q_{11}  Q_{12} ]
%     [ Q_{21}  Q_{22} ] >0
%
% 
% where Z(x)= Z_d1(x) \otimes I_n and Z_d(x) is the vector of monomials in
% variables x of degree d1 or less. Z(x,y) = Z_{d1}(x) \otimes Z_{d2}(x)
% \otimes I_n. If the application is stability of time-delay systems, d1
% will eventually be more or less the degree of the multiplier and d2 more
% or less the degree of the kernel function.
% we recommend setting d2 = d1 to keep the polynomial degrees balanced.

% INPUTS 
%   prog: SOS program to modify.
%   n: dimension of the resulting matrix
%   d1: degree of the multiplier (sort of)
%   d2: degree of the kernel
%   var1: Single pvar corresponding to s in the description
%   var2: Single pvar corresponding to t in the description
%   I = {[l1 u1]},{[l2,u2]},... cell array of intervals of integration
%
% OUTPUT 
%   M{i}: A cell array of functions of var1 valid on the intervals i
%   N{i,j}: A cell array of kernels valid on the intervals I{i} in variable
%   var1 and intervals I{j} in variable var2
%
% NOTES:
% Distributed with DelayTOOLS
% Compatable with MULTIPOLY and SOSTOOLS as of June 2013
% For support, contact M. Peet, Arizona State University at mpeet@asu.edu

if ~isvalid(var1) || ~isvalid(var2)
  error(['vars must be a polynomial variable']);
end
if ~iscell(I)
    error(['I must be a cell array of intervals'])
end

switch nargin
    case 7
    error(['Not enough inputs!'])       
    case 8
        override=0;
end

nints=length(I);

% this is the non-psatz piecewise-continuous multiplier/integral positive
% on L_2^(n1+n2)

[prog, M1, N1] = sosjointpos_mat_ker_ndelay_parallel_MTNS(prog,n1,n2,d1,d2,var1,var2,I);
% n1
% n2
% size(M1{1})
% size(N1{1,1})
% this logic determines if the full PSatz operator (override=0) will be used or just the
% multiplier part (override=1)

% In either case, The operator is positive for the intervals I{i}

if d1>=1 && d2>=1 && override~=1
%    [prog, M2, N2] = sosjointpos_mat_ker_ndelay_psatz(prog,n1+n2,d1-1,d2-1,var1,var2,I);
elseif d1>=1 && d2>=1 && override==1
    
    for i=1:nints
        g{i}=(var1-I{i}(1))*(I{i}(2)-var1);
        [prog,temp{i}] = sosposmatrvar(prog,n1+n2,2*d1-2,[var1]);
        M2{i}=g{i}*temp{i};
        for j=1:nints
            N2{i,j}=0*N1{i,j};
        end
    end
else
    for i=1:nints
        for j=1:nints
            M2{i}=0*M1{i};
            N2{i,j}=0*N1{i,j};
        end
    end
end
    for i=1:nints
        for j=1:nints
            NR{i,j}=N1{i,j}+N2{i,j};
        end
    end


% Here we combine the non-Psatz and Psatz operators and label the
% components of N, some of which will be moved into M, only N22 will be
% returned directly as NR
clear temp
total_length=(I{1}(2)-I{nints}(1));
parfor i=1:nints
    M{i}=M1{i}+M2{i};
    Mp12{i}=M{i}(1:n1,(n1+1):(n1+n2));
    Mp21{i}=M{i}((n1+1):(n1+n2),1:n1);
    Mp22{i}=M{i}((n1+1):(n1+n2),(n1+1):(n1+n2));
    temp{i}=int(M{i}(1:n1,1:n1),var1,I{i}(1),I{i}(2));
end
zz11=polynomial(zeros(n1,n1));
Mp11i=zz11;
for i=1:nints
    Mp11i=Mp11i+temp{i}; % We want the 11 element to be a constant
 end

 parfor i=1:nints
     size(Mp11i)
     size(Mp12{i})
    MR{i}=[Mp11i/total_length Mp12{i};Mp21{i} Mp22{i}]; % dividing by I{1}(2)-I{nints}(1) which is the total length of the domain
 end


