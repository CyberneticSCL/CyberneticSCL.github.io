function [prog, P,Q,R,S] = sosjointpos_mat_ker_ndelay_parallel_R_L2_PQRS_MTNS(prog,n1,n2,d1,d2,var1,var2,I,override)
%
% sosjointpos_mat_ker_ndelay_parallel_R_L2_PQRS_wrapper(prog,n1,n2,d1,d2,var1,var2,I,override) 
% calls sosjointpos_mat_ker_ndelay_parallel_R_L2 and then extracts PQRS
% which form the operators

% (P_{PQRS}x)(s) = [P*x1 + int_{I{1}} Q(th)x2(th)dt;
%                   tau Q(s)^T*x1 + tau S(s) +tau \int_{I{1}}R(s,th)x2(th)dth ]
%
% such that if
%
% (P_{M,N}x)(s)=M(s)x(s) + [0;                         ]
%                           \int_{I{1}} N(s,th)x2(th)dth]
%
% Then \ip{x}{P_{PQRS}x}_{L2}=\ip{x}{P_{M,N}x}_{L2}

% INPUTS 
%   prog: SOS program to modify.
%   n: dimension of the resulting matrix
%   d1: degree of the multiplier (sort of)
%   d2: degree of the kernel
%   var1: Single pvar corresponding to s in the description
%   var2: Single pvar corresponding to t in the description
%   I = {[l1 u1]},{[l2,u2]},... cell array of intervals of integration
%
% OUTPUT 
%   M{i}: A cell array of functions of var1 valid on the intervals i
%   N{i,j}: A cell array of kernels valid on the intervals I{i} in variable
%   var1 and intervals I{j} in variable var2
%
% NOTES:
% Distributed with DelayTOOLS
% Compatable with MULTIPOLY and SOSTOOLS as of June 2013
% For support, contact M. Peet, Arizona State University at mpeet@asu.edu


[prog, MR, NR] = sosjointpos_mat_ker_ndelay_parallel_R_L2_MTNS(prog,n1,n2,d1,d2,var1,var2,I,override);

tau=I{1}(2)-I{1}(1);
P=MR{1}(1:n1,1:n1);
Q=MR{1}(1:n1,(n1+1):(n1+n2))/tau; % Divide  
S=MR{1}((n1+1):(n1+n2),(n1+1):(n1+n2))/tau;
R=NR{1,1}/tau; % convert from cell format
