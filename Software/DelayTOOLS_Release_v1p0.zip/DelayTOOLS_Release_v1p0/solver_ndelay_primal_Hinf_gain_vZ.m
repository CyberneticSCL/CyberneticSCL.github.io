clear all; close all; echo off; 
total=tic;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% DelayTools/Linear v1.0 - solver_ndelay_primal_Hinf_gain_vZ
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This program determines stablity of a linear differential equation with 
% multiple delays using the primal form of Lyapunov-Krasovskii functional.
% Here 
% \dot{x}(t)=A0x(t)+A{1}x(t-tau(1))+...+A{K}x(t-tau(K)) + Bw(t)
% y(t)=C0x(t)+C{1}x(t-tau(1))+...+C{K}x(t-tau(K)) + Dw(t)
% where A0, A{i}, C0, C{i}, B, D and tau(i) are user inputs. 
%
% Inputs: A{i} - these can be arbitrary square matrices of identical 
%         dimension n_dim. 
%         B - matrix of dimension n_dim x n_ins
%         C{i} - these can be arbitrary matrices of  
%         dimension nouts x n_dim. 
%         D -  matrix of dimension n_outs x n_ins
%
%         tau(i) - These can be an arbitrary sequence of positive increasing 
%         numbers.
%
%         orderth/ordernu - This input controls the accuracy of the results. For
%         most problems, orderth=ordernu=4 should be sufficient to obtain a
%         reasonable degree of accuracy. Note: orderth should be an even
%         integer.
% 
% Requirements: In order to operate, this program requires a working
%               version of SOStools. There are some known compatability 
%               issues with SOStools and Matlab version 7+ due to errors in 
%               the implementation of Maple v8. In addition, it
%               is highly recommended that the user have a compiled version
%               of cdd. Finally the following package of subprograms are
%               required which allows SOStools to handle matrix objects
%               directly:
%               SOStools Matrix Addon package:
%                   sosposmatr.m
%                   sosmateq.m
%                   sosjointpos_mat_ker_ndelay_PQRS_vZ
%                   sosjointpos_mat_ker_R_L2
%                   sosjointpos_mat_ker_R_L2_psatz
%
% version .03   M. Peet, Arizona State University. mpeet@asu.edu
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs
%
% Enter degree of accuracy - must be an even integer
orderth = 4;
ordernu = 8;  % it is recommended to use ordernu = 2*orderth in order to match degrees
override1=0; % if override1=1, the LF will not include psatz terms in the kernel - default=0
override2=0; % if override2=1, the derivative check will not include psatz terms in the kernel - default=0

%
% Enter system dynamics in terms of A0, A{1}, ..., A{K}

% % % % % % % % Problem A:
% A0=.1;%
% A{1}=-1;%
% C0=1;
% C{1}=0;
% D=0;
% B=1;
% tau(1) = .3; %1.5707
% gam=1.2

%[MAG,PHASE] = bode(pp)
%bode(pp); 
 %max=56.5; hinfgain=10^(max/20)
 
 
%  A0=-.1*eye(2);
%  A{1}=-eye(2);
% tau=.1;
% C0=[1 0];
% C{1}=[0 0];
% B=[1;0];
% D=[0];
% gam=.9%.89001; % 1.29@.3, 6.1@1.3 
% % % s=tf('s')
% % % pp=1/(s-A0-A{1}*exp(-tau*s))
% % % bode(pp); 
% %  max=15.6; hinfgain=10^(-1/20)
 
% orderth 2 [1.568 1.569] time=.434
% orderth 4 [1.5707] time=.460
% orderth 6 [1.5707] time=
 
% % % % Problem B:
% A0=[0 1; -2 .1];
% A{1}=[0 0;1 0];
% C0=[1 0]
% C{1}=[0 0]
% B=[1;0]
% D=[0];
% tau(1) = 1 %[.10017, 1.71785]
% gam=5
% % orderth 2 [.100167 .100168 ] [1.709 1.710] time=.469
% % orderth 4 [.100173 .100174] [1.71785 1.71786] time= .997
% % orderth 6 [] time=

% % % % Problem C:
% A0=-2;%
% A{1}=2.6;% % search variable max is 3
% A{2}=-1;%
% C0=[1]
% C{1}=[0]
% C{2}=[0]
% B=[1]
% D=[0];
% tau(1) = 1;%
% tau(2) = 2;%
% gam=2.4
% % % orderth 2 [3 3.1] time=.471
% % % orderth 4 [3 3.1] time=
% % % orderth 6 [] time=


% % % Problem D:
A0=[0 1; -1 .1];
A{1}=[0 0;-1 0];
A{2}=[0 0;1 0];
 C0=[1 0];
 C{1}=[0 0];
 C{2}=[0 0];
 B=[1;0];
 D=[0];
 gam=8.4

tau(2) = 1.2%1.372 is max [1.35,1.372]
tau(1) = tau(2)/2;
% % orderth 2 [1.36 1.361] time=1.64
% % orderth 4 [1.3723 1.3724] time=7.51
% % orderth 6 [ ] time=

% % % Problem E:
% Anom=[0 0 1 0;
%     0 0 0 1; 
%     -10 10 0 0;
%     5 -15 0 -.25];
% B=[0;0;1;0];C=[1 0 0 0];K=1;
% A0=Anom-B*K*C;
% A{1}=B*K*C;
% tau(1) = 3;
% % % % orderth 2 [no] time=.72
% % % % orderth 4 yes time=7.05
% % % % orderth 6 yes time=

% % % Problem F: This is scalability test which uses orderth=ordernu=2 and
% both overrides. For this case, in the 1-delay case, the max delay detectable is ~1.48<1.57

% delaymat=[1 2 3 5 10]
% dimmat=[1 2 3 5 20]
% for iii=1:1
%     for jjj=5:5
%         clear prog tau A A0 R R2 Q Q2 S S2 P P2 G 
% nndim=dimmat(jjj);nndelay=delaymat(iii);
% 
% A0=zeros(nndim);
% for j=1:nndelay
%   A{j}=-eye(nndim)/nndelay;
%   tau(j) = j/nndelay;
% end

% % % %          n_dim
% % % %          1      2      3      5      10
% % % % n_dly 1  .366  .094   .158   .686  12.8
% % % % n_dly 2  .112  .295   1.260  10.83  61.05
% % % % n_dly 3  .177  1.311  6.86   96.85  5223
% % % % n_dly 5  .895  13.05  124.7
% % % % n_dly 10 13.09  

%====================
% estimate Hinf norm using Pade
n_dim=size(A0,1);
s=tf('s');
den=s*eye(n_dim)-A0;
num=C0;
ndelay=length(tau);
for i=1:ndelay
den=den-A{i}*exp(-tau(i)*s);
num=num+C{i}*exp(-tau(i)*s);
end
pp=num*inv(den)*B+D;
sysapp=pade(pp,10);
disp('Estimated Hinf norm is')
norm(sysapp,inf)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% internal variables:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%fact=1/tau;
fact=1;           % conditioning multiplier
eps1=.001;           % strictness of LF w/r to norm{x(0)} - must be strictly positive (but can be small)
eps11=0;          % strictness of LF w/r to norm{x_t}_{L2}
eps2=0;           % strictness of derivative negativity

% control inputs to SeDuMi 
pars.alg=2;
pars.stepdif=1;
pars.eps=10^(-10);
pars.maxiter=100;
pars.cg.maxiter=200;
pars.cg.qprec=1;
pars.cg.stagtol=1e-22;
pars.cg.restol=5e-5;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% internal processing:
pvar th ksi

n_dim=length(A0);
n_ins=size(B,2);
n_outs=size(C0,1);
n_delay=length(tau);
tauK=tau(n_delay);

mastervartable=[th,ksi];
prog = sosprogram(mastervartable);


% This is the multiple delay case.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% phase 1 - variables %%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% we will need to declare variables:
% P, Q(th), S(th), R(th,ksi)
%


disp('creating joint positive operator variable')
tic


[prog,P,Q,R,S] = sosjointpos_mat_ker_ndelay_PQRS_vZ(prog,n_dim,n_dim,orderth/2,ordernu/2,th,ksi,tau,override1);

toc
P=P+eps1*eye(n_dim); % making the operator strictly positive



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% phase 2 - derivatives %%%%%%%%%%%%%%%%%%%%
%%%%%%% Step1 %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% the derivative matrices are spelled out in the paper, they are 
disp('constructing Derivatives, elapsed time:')
tic

% first do the constant terms. These are inside the integral.

% This first term is the standard {PA}+{A^TP} part
D11=P*A0+A0.'*P;
D12=[];
D22=[];
for i=1:n_delay
    D11=D11+subs(Q{i}.'+Q{i}+S{i},th,0);
    D12=[D12 P*A{i}-subs(Q{i},th,-tau(i))]; 
    D22=blkdiag(D22,(subs(-S{i},th,-tau(i))));
end
D21=D12.';

zii=polynomial(zeros(n_ins,n_ins));
zin=polynomial(zeros(n_ins,n_dim));
zink=polynomial(zeros(n_ins,n_dim*n_delay));
znn=polynomial(zeros(n_dim,n_dim));
znnk=polynomial(zeros(n_dim,n_dim*n_delay));

D1=[zii    zin  zink;
    zin.'  D11  D12;
    zink.' D21  D22];

D1temp=polynomial(zeros(n_ins+n_dim*(n_delay+1)));
D1temp(1:n_ins,1:n_ins)=-gam/tauK*eye(n_ins);
D1temp((n_ins+1):(n_ins+n_dim),1:n_ins)=P*B;
D1temp(1:n_ins,(n_ins+1):(n_ins+n_dim))=B.'*P;

D2h=[D C0];
for i=1:n_delay
    D2h=[D2h C{i}];
end
D2temp=1/gam/tauK*D2h.'*D2h;

Df=D1+D1temp+D2temp;

for i=1:n_delay
    E{i}=A0.'*Q{i} - diff(Q{i},th);
    for j=1:n_delay
         E{i}=E{i}+subs(R{i,j}.',ksi,0)/tauK;
    end
    for j=1:n_delay
         E{i}=[E{i}; A{j}.'*Q{i}-subs(R{i,j}.',ksi,-tau(j))/tauK];
    end
    E{i}=[zin;E{i}];
    D33{i}=diff(-S{i},th);
    E1temp{i}=[B.'*Q{i}; znn; znnk.'];
%    D31{i}=D13{i}.';
    Ef{i}=E{i}+E1temp{i};
end


parfor i=1:n_delay
    for j=1:n_delay
        G{i,j}=-(diff(R{i,j},th)+diff(var_swap(R{j,i}.',th,ksi),ksi));
    end
end

toc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Step2 %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% m
% Enforce negativity of D 
disp('enforcing negativity of derivative')
%Now declare first spacing functions

%[prog, M, N] = sosjointpos_mat_ker_ndelay(prog,2*n_dim,orderth/2,ordernu/2,th,ksi,II);
disp('Calling for jointly positive Mat/Kernel, elapsed time:')
tic
[prog,P2,Q2,R2,S2] = sosjointpos_mat_ker_ndelay_PQRS_vZ(prog,n_ins+(n_delay+1)*n_dim,n_dim,orderth/2,ordernu/2,th,ksi,tau,override2);


toc

disp('Constructing Equality Constraints:')

tic
prog = sosmateq(prog,Df+P2);
for i=1:n_delay
    prog = sosmateq(prog,Q2{i}+Ef{i});
    prog = sosmateq(prog,S2{i}+D33{i});
    for j=i:n_delay % the latter j>=i define unique constraints
            prog = sosmateq(prog,R2{i,j}+G{i,j});
    end
end
toc

toc
disp('TOTAL POLYNOMIAL TIME:')
toc(total)
disp('Computing Solution')


disp('Computing Solution')
prog = sossolve(prog);
%% Conclusion:
if norm(prog.solinfo.info.feasratio-1)<=.1 && ~prog.solinfo.info.numerr
    disp('The System is STABLE.')
elseif norm(prog.solinfo.info.feasratio-1)<=.1 && prog.solinfo.info.numerr
    disp('The System is likely STABLE. However, Double-check the precision.')
elseif prog.solinfo.info.pinf || prog.solinfo.info.dinf || norm(prog.solinfo.info.feasratio+1)<=.1
    disp('The System is probably NOT STABLE.')
else
    disp('Unable to definitively determine stability. Numerical errors dominating or at the limit of stability.')
end

% mat_results(iii,jjj)=prog.solinfo.info.timing(2);
% 
% end 
% end


% Simulate the system to verify
tspan=10*tau(n_delay)
if n_delay==1
    ddefun=@(t,y,Z) A0*y+A{1}*Z(:,1)
    sol=dde23(ddefun,tau(1),ones(n_dim,1),[0,tspan])
elseif n_delay==2
    ddefun=@(t,y,Z) A0*y+A{1}*Z(:,1)+A{2}*Z(:,2)
    sol=dde23(ddefun,tau,ones(n_dim,1),[0,tspan])
else
    disp('Simulation currently only runs for 1 or 2 delays')
end
plot(sol.x,sol.y)
