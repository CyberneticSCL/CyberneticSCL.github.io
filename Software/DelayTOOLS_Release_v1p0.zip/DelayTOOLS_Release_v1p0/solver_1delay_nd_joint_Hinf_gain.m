clear all; close all; echo off; 
total=tic;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% DelayTools/Linear v.04 - solver_1delay_nd_Hinf_gain
%
% This program determines stablity of a linear differential equation with 
% delay, where \dot{x}(t)=A0x(t)+A{1}x(t-tau(1))+...+A{K}x(t-tau(K))  
% where A0, A{i}, and tau(i) are user inputs. 
%
% Inputs: A{i} - these can be arbitrary square matrices of arbitrary 
%         dimension. However,  the higher the higher the dimension of A{i},
%         the more time the program will take to run
%         
%         tau(i) - These can be an arbitrary sequence of positive increasing 
%         numbers.
%
%         orderth - This input controls the accuracy of the results. For
%         most problems, orderth=2 should be sufficient to obtain a
%         reasonable degree of accuracy. Note: orderth should be an even
%         integer.
% 
% Requirements: In order to operate, this program requires a working
%               version of SOStools. There are some known compatability 
%               issues with SOStools and Matlab version 7+ due to errors in 
%               the implementation of Maple v8. In addition, it
%               is highly recommended that the user have a compiled version
%               of cdd. Finally the following package of subprograms are
%               required which allows SOStools to handle matrix objects
%               directly:
%               SOStools Matrix Addon package:
%                   sosposmatr.m
%                   sosposmatr.m
%                   sosmatrvar.m
%                   sossymmatrvar.m
%                   sosposmatrvar.m
%
% version .03   M. Peet, Stanford. mmpeet@stanford.edu
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DelayTools/Linear v.03 - solver_delay_nd
% Release Notes:
% v.03 - Compatibility with MatrixTOOLS v.03
%
% Coming soon - The big change with release v.04 will be the use of semiseparable
% kernel functions. These functions have properties in common with the
% Gaussian and seem to give an order of magnitude increase in Accuracy in
% most problems, expecially ones which were problematic using separable
% kernels. As yet, we have no joint positivity condition for semiseparable
% kernels. Thus the choice was between either joint positivity or
% semiseparable kernels. Since joint positivity demonstrated little or no
% improvement in performance, the choice was relatively simple.
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs
%
% % paper by Fattouh, Sename, Dion
% A0=[-10 10; 0 1];
% A{1}=[1 1; 1 1];
% tau(1)=.3;
% C=[0 10]

% Example 2 from review paper by Sename (weakly, not strongly observable)
%  A0=[-.2 0; .2 .1];
%  A{1}=[0 0;-1 0];
% tau=.3;
% C=[0 7]
% B=[1;0]
% D=[0];
% gam=10;

 A0=[-1];
 A{1}=[-1];
tau=1;
C=[1]
B=[1]
D=[0];
gam=.892%.89001; % 1.29@.3, 6.1@1.3 
% s=tf('s')
% pp=1/(s-A0-A{1}*exp(-tau*s))
% bode(pp); 
 max=15.6; hinfgain=10^(-1/20)

% Enter system dynamics in terms of A0, A{1}, ..., A{K}
% A0=[0 1; 0 -.1];
% A{1}=[0; .1]*[-3.75 -11.5];
% C=[1 0]
%====================
% Gu 2delay example 1
% A0=[-2 0; 0 -.9];
% A{1}=[-1 0;-1 -1]*.05;
% A{2}=[-1 0;-1 -1]*.95;
% tau(2) = 6.%8.5
% tau(1) = tau(2)/2;
%====================
% Gu 2delay example 2
% A0=[0 1; -1 .1];
% A{1}=[0 0;-1 0];
% A{2}=[0 0;1 0];
% tau(2) = 1.373%1.372 is max
% tau(1) = tau(2)/2;
%  A0=0;%[-1 0; 0 0];
%  A{1}=-1;%[0 0;0 -1];
%  A{2}=-2;%[0 0;0 -1];
%  tau(1) = .4%.57079;
% % tau(2) = .6191; d=2
%  tau(2) = .619;
%====================
%====================
% Seuret Example
% A0=[.2 0; .2 .1];
% A{1}=[0 0;-1 0];

%  A0=-1*eye(2);%[-1 0; 0 0];
%  A{1}=-1*eye(2);%[0 0;0 -1];
%  A{2}=-2*eye(2);%[0 0;0 -1];
%  tau(1) = .4%.57079;
%  tau(2) = 10; %d=2 

%    A0=-2;%[-1 0; 0 0];
%  A{1}=3.000;%[0 0;0 -1];
%  A{2}=-1;%[0 0;0 -1];
%  tau(1) = 1%.57079;
%  tau(2) = 2; %d=2 
%  
%  A0=[0];
%  A{1}=[-.5];
% A{2}=[-.5];
% tau(1) = 7;
% tau(2) = 7.1;
%  A0=[0];
%  A{1}=[-1];
% A{2}=[0];
% tau(1) = 1.3;
% tau(2) = 8;


% Enter degree of accuracy - must be an even integer
orderth = 4;
ordernu=8;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% internal variables:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%fact=1/tau;
fact=1;           % conditioning multiplier
eps1=.001;           % strictness of lyapunov positivity
eps2=0;           % strictness of derivative negativity

% control inputs to SeDuMi 
pars.alg=2;
pars.stepdif=1;
pars.eps=10^(-10);
pars.maxiter=100;
pars.cg.maxiter=200;
pars.cg.qprec=1;
pars.cg.stagtol=1e-22;
pars.cg.restol=5e-5;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% internal processing:
tic
pvar th ksi

n_dim=length(A0);
m_dim=size(C,1);
q_dim=size(B,2);
n_delay=length(tau);
tauK=tau(n_delay);

mastervartable=[th,ksi];
prog = sosprogram(mastervartable);

% % local positivity regions:
% g{1}=th*(th+tau(1));            %negative on interval [-\tau,0]
% for i=2:n_delay
%     g{i}=(th+tau(i))*(th+tau(i-1));%negative on interval [-tau_i,-\tau_i-1]
% end
% II{1}=[-tau(1) 0];            %negative on interval [-\tau,0]
% for i=2:n_delay
%     II{i}=[-tau(i) -tau(i-1)];%negative on interval [-tau_i,-\tau_i-1]
% end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% phase 1 - variables %%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% we will need to declare variables:
% P, Q(th), S(th), R(th,ksi)
%
disp('Overhead and Lyapunov Variables, elapsed time:')

toc

tic
disp('creating joint positive operator variable')
II{1}=[-tau 0];
%[prog, bigP, Nw] = sosjointpos_mat_ker_ndelay_parallel_R_L2(prog,n_dim,n_dim,orderth/2,ordernu/2,th,ksi,II,1);
[prog, bigP, Nw] = sosjointpos_mat_ker_ndelay_parallel_R_L2_test_10_17(prog,n_dim,n_dim,orderth/2,ordernu/2,th,ksi,II,1) 

% Convert to PQRS representation
%
%P(xt/xth)(s)=[ P xt+int Q xth dth;               ]
%            [ tau*Q^T xt + S*xth +int R xth dth ]
%ip{xt/xth}{P(xt/xth)} = int [xt ][ P         tau*Q  ] [ xt  ]
%                            [xth][ tau Q^T   S      ] [ xth ]


P=bigP{1}(1:n_dim,1:n_dim)+eps1*eye(n_dim);
    Q=bigP{1}(1:n_dim,(n_dim+1):(2*n_dim))/tau; % Divide  
%   Q' =bigP{1}((n_dim+1):(2*n_dim),1:n_dim);%P12{i}.';
    S=bigP{1}((n_dim+1):(2*n_dim),(n_dim+1):(2*n_dim));
R=Nw{1,1}; % convert from cell format

toc




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% phase 2 - derivatives %%%%%%%%%%%%%%%%%%%%
%%%%%%% Step1 %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% the derivative matrices are spelled out in the paper, they are 
disp('constructing Derivatives, elapsed time:')
tic


zzn=polynomial(zeros(n_dim));


D00=-gam*eye(q_dim)+1/gam*D.'*D;
D01=(P*B).'+1/gam*D.'*C;
D03=polynomial(zeros(q_dim,n_dim));
D04=B.'*Q*tau;

D11=P*A0+A0.'*P+subs(Q+Q.'+S,th,0)+1/gam*C.'*C;
D13=P*A{1}-(subs(Q,th,-tau)); 
D33=-subs(S,th,-tau);


D14=tau*(subs(R.',ksi,0)+A0.'*Q-diff(Q,th));
D34=tau*(A{1}.'*Q-subs(R.',ksi,-tau));
D44=-diff(S,th);

    DD=[D00      D01   D03   D04
        D01.'    D11   D13   D14;
        D03.'    D13.' D33   D34;
        D04.'    D14.' D34.' D44];

        G=-(diff(R,th)+diff(R,ksi));


toc

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Step2 %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Enforce negativity of D 
disp('enforcing negativity of derivative')
%Now declare first spacing functions

%[prog, M, N] = sosjointpos_mat_ker_ndelay(prog,2*n_dim,orderth/2,ordernu/2,th,ksi,II);
disp('Calling for jointly positive Mat/Kernel, elapsed time:')
% 
% 


disp('creating joint positive operator variable')
%[prog, HH, R22] = sosjointpos_mat_ker_ndelay_parallel_R_L2(prog,q_dim+(n_delay+1)*n_dim,n_dim,orderth/2,ordernu/2,th,ksi,II,1);
[prog, HH, R22] = sosjointpos_mat_ker_ndelay_parallel_R_L2_test_10_17(prog,q_dim+(n_delay+1)*n_dim,n_dim,orderth/2,ordernu/2,th,ksi,II,1) 

R2=R22{1,1}; %Convert from cell format 
H=HH{1};



% Should we make this exact?
toc
disp('running equalities, elapsed time:')
tic


    [prog] = sosmateq(prog,HH{1}+DD);
    [prog] = sosmateq(prog,R2+G);

                
                toc
disp('TOTAL POLYNOMIAL TIME:')
toc(total)
disp('Computing Solution')


disp('Computing Solution')
prog = sossolve(prog);
%% Conclusion:
if norm(prog.solinfo.info.feasratio-1)<=.1 && ~prog.solinfo.info.numerr
    disp('The System is STABLE.')
elseif norm(prog.solinfo.info.feasratio-1)<=.1 && prog.solinfo.info.numerr
    disp('The System is likely STABLE. However, Double-check the precision.')
elseif prog.solinfo.info.pinf || prog.solinfo.info.dinf || norm(prog.solinfo.info.feasratio+1)<=.1
    disp('The System is probably NOT STABLE.')
else
    disp('Unable to definitively determine stability. Numerical errors dominating or at the limit of stability.')
end



% Now extract the solution....

% r=tau(n_delay)
% NP = sosgetsolmat(prog,P11,5);
% % Note that in Keqin's formula, he uses a Q'=Q/tau, where Q is
% % the value used in this code. So in deriving the inverse, I will divide by
% % tau to get Q'.
% NQ = sosgetsolmat(prog,P12{1},5)/r;
% NS = sosgetsolmat(prog,P22{1},5);
% NR = sosgetsolmat(prog,Nw{1,1},5);


