%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PIESIM_Poly2Mat_cheb.m     PIETOOLS 2025
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Constructs A - discrete matrix representation of a polymonial operator
% Discretizes FULL OPERATOR
% Inputs:
% N   - polynomial order of Chebyshev discretization polynomial
% Rop -  polynomial matrix operator size (n0+n1+n2) x no
% p - scalar - a "degree of smoothness" vector
%
% Outputs:
% A - matrix of size n0(N+1) n1N n2(N-1) x no that represents a Chebyshev
% discretizaiton of the polynomial matrix operator. Represents a block of
% the total time-propagator matrix operator for the PIE solution
% A_2PDEstate - matrix of size n0n1n2(N+1)^3 x no that represents a Chebyshev
% discretizaiton of the polynomial matrix operator. Represents a block of
% the total matrix operator for reconstruction of the primary solution
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% If you modify this code, document all changes carefully and include date
% authorship, and a brief description of modifications
%
% Initial coding YP  - 6_30_2022
% YP -  added support for an arbitary variable name - 04_16_2024
% DJ, 12/16/2024: Make sure variable to substitute matches that of Rop;

function [A, A_2PDEstate]=PIESIM_Poly2Mat_cheb(N, Rop, p)

ns=length(p);
no=size(Rop,2);

if isa(Rop,'polynomial')
    deg=Rop.maxdeg;
else
    deg=1;
end

chebgrid=cos(pi*(0:deg+1)/(deg+1));

for m=1:ns
        
Alocal(1:N+1,1:no)=0;

for k=1:no
    if (isempty(Rop))
        Rop_local=0;
    else
        Rop_local=Rop(m,k);
    end
    if isa(Rop_local,'polynomial') && ~isdouble(Rop_local)
        if numel(Rop_local.varname)>1                                       % DJ, 12/16/2024
            error("The input polynomial depends on multiple variables; discretization not supported...")
        else
            var = polynomial(Rop_local.varname);
            Reval=subs(Rop_local,var,chebgrid);
        end        
    else
        Reval=Rop_local*ones(1,deg+2);
    end

    acheb=fcht(double(Reval));

for j=1:length(acheb)
    Alocal(j,k)=acheb(j);
end

end % k loop

rsize=N-p(m)+1;
A_cell_2PDEstate{m,1}=Alocal(1:N+1,1:no);
A_cell{m,1}=Alocal(1:rsize,1:no);

end % m loop


A_2PDEstate=cell2mat(A_cell_2PDEstate);
A=cell2mat(A_cell);
