% This script updates the MATLAB path to include all PIETOOLS directories
% and subdirectories. Save your path after running to keep directories on
% path for future sessions. Don't move this file!
current_folder = pwd; 
addpath(genpath(current_folder));