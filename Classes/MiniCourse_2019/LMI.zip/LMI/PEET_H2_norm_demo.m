% Demo from M. Peet for lecture 11 in MAE 598
% PEET_H2_norm_demo --- An LMI for calculating the H2-norm of a A,B,C,D
% system
%
% INPUT: The system matrices A,B,C may be modified
%
% This file is part of LMI DEMOs - An LMI Demonstration Toolbox.
%
% Copyright (C) 2017  M. Peet (1)
% (1) Arizona State University, Tempe, AZ 85287, USA.
%
% Send feedback to: mpeet@asu.edu
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 2 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
%
% 05/01/17 - MP -- Initial Coding



OPTIONS = sdpsettings('solver','sedumi');

% example from Scherer+Gahinet
A=[0 0 1 0;0 0 0 1;-.101 -.1681 -.04564 -.01075;.06082 -2.1407 -.05578 -.1273];
B=[0 0 0;0 0 0;.1179 .1441 .1478;.1441 1.7057 -.7557];
C=[1 0 0 0;0 1 0 0];
sys_ex=ss(A,B,C,0);
norm(sys_ex)
% measure numbers of inputs and outputs 

eta=.0001;    % degree of strict positivity   
ns=size(A,1);   % number of states
nd=size(B,2);  % number of external inputs
no=size(C,1);  % number of regulated outputs
% Calculate H2 Norm

XX=sdpvar(ns);
gamma2=sdpvar(1);
F2=[XX>=eta*eye(ns)]
F2=[F2;A*XX+XX*A'+B*B'<=0]
F2=[F2;trace(C*XX*C')<=gamma2]
optimize(F2,gamma2,OPTIONS)
disp('H2 norm calculated using 1st LMI method')
sqrt(value(gamma2))

% Calculate H2 Norm
XX=sdpvar(ns);
Q=sdpvar(no);
gamma2=sdpvar(1);
F2=[XX>=eta*eye(ns)]
F2=[F2;[A'*XX+XX*A  XX*B; 
        B'*XX         -eye(nd)]<=0]
F2=[F2;[XX C';C Q]>=0]
F2=[F2;trace(Q)<=gamma2]
optimize(F2,gamma2)
disp('H2 norm calculated using 2nd LMI method')
sqrt(value(gamma2))




