% PEET_regulator_tracking_framework --- 
% Takes a nominal A,B,C,D system and formulates the 
% A,B1,B2,C1,C2,D11,D12,D21,D22 system for optimal control in the tracking 
% or regulator frameworks.
%
% INPUT: The system matrices A,B,C,D may be modified.
%
% This file is part of LMI DEMOs - An LMI Demonstration Toolbox.
%
% Copyright (C) 2017  M. Peet (1)
% (1) Arizona State University, Tempe, AZ 85287, USA.
%
% Send feedback to: mpeet@asu.edu
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 2 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
%
% 05/01/17 - MP -- Initial Coding
clear all

 A =[
     -1     1     0     1     0     1;
    -1     -2    -1     0     0     1;
     1     0     -2    -1     1     1;
    -1     1    -1     -2     0     0;
    -1    -1     1     1    -3    -1;
     0    -1     0     0    -1     -2];
B =[
     0 -1 -1; 
     0 0 0;
    -1 1 1;
    -1 0 0;
     0 0 1;
    -1 1 1];

C =[
     0     1     0    -1    -1    -1;
     0 0 0 -1 0 0;
     1 0 0 0 -1 0];
D=[0 0 0;
   0 0 0;
   0 0 0];

G1nom=ss(A,B,C,D);
disp('The open-loop nominal system Hinf norm')
norm(G1nom,inf) %1.7958

% Regulator
eps = .00100000001
ns=size(A,1);II=eye(ns);
nc=size(B,2); % number of actuator inputs
nm=size(C,1); % number of measured outputs
nd=nc+nm;     % number of disturbances
nr=nm+nc;     % number of regulated outputs



B1=[B zeros(ns,nm)];
B2=[B];
C1=[C; zeros(nc,ns)];
C2=[C];
D11=zeros(nr,nd);
D12=[D; eye(nc)];
D21=[D, eye(nm)];
D22=D;

G1=ss(A,B1,C1,D11);
disp('The open-loop regulator system Hinf norm')
norm(G1,inf) %1.7958
disp('The open-loop regulator system H2 norm')
norm(G1) %1.7958

% Tracking
eps = .00100000001;
ns=size(A,1);
nc=size(B,2); % number of actuator inputs to the plant
no=size(C,1); % number of outputs from the plant
nt=no;        % number of signals to track
nm=nt+no;     % number of measured outputs
nd=nt+nc+no;     % number of disturbances
nr=nt+nc;     % number of regulated outputs

B1=[zeros(ns,nt) B zeros(ns,no)];  % B1 is ns x nd
B2=[B];                            % B2 is ns x na
C1=[C; zeros(nc,ns)];              % C1 is nr x ns
C2=[zeros(nt,ns); C];              % C2 is nm x ns
D11=[-eye(nt) D zeros(nt,no);      % D11 is nr x nd
    zeros(nc,nd)];
D12=[D; eye(nc)];                  % D12 is nr x na
D21=[eye(nt) zeros(nt,nc) zeros(nt,no);% D21 is nm x nd 
    zeros(no,nt) D eye(no)];        
D22=[zeros(nt,nc); D];             % D22 is nm x na
G1t=ss(A,B1,C1,D11);
disp('The open-loop tracking system Hinf norm')
norm(G1t,inf) %2.0554
disp('The open-loop tracking system H2 norm')
norm(G1t)

